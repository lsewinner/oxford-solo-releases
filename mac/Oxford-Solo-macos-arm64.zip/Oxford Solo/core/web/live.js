// Oxford Solo 网页版：连本机内核（./solo serve），数据和操作都是真的。所有文案来自 i18n 文案表。
(() => {
'use strict';
const I = window.SoloI18n;
const t = I.t;
const $ = (s, el = document) => el.querySelector(s);
const $$ = (s, el = document) => [...el.querySelectorAll(s)];
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const usd = n => '$' + (n > 0 && n < 0.01 ? Number(n).toFixed(4) : Number(n || 0).toFixed(2));
I.setMoney(usd);
const store = {
  get(k, d) { try { const v = localStorage.getItem('oxsolo-live:' + k); return v == null ? d : JSON.parse(v); } catch (e) { return d; } },
  set(k, v) { try { localStorage.setItem('oxsolo-live:' + k, JSON.stringify(v)); } catch (e) { /* 存不了就算了 */ } }
};
const reduced = matchMedia('(prefers-reduced-motion: reduce)').matches;
const RISKS = ['external', 'pay', 'public'];
const UCLASS = { queued: 'q', running: 'run', checking: 'chk', done: 'ok', awaiting: 'wait', failed: 'bad', skipped: 'decl' };
const TOOL_KEY = { mail: 'tool.mail', contacts: 'tool.contacts', calendar: 'tool.calendar', notes: 'tool.notes' };
/* 模板页：第一版只有"独立咨询顾问"上线，其余三个展示结构（文案键 t.<模板>.*） */
const TEMPLATES = [
  { key: 'consultant', depts: [['d1', ['inbox', 'follow', 'meet']], ['d2', ['lead', 'social']], ['d3', ['research', 'proposal']], ['d4', ['invoice', 'expense']]] },
  { key: 'creator', depts: [['d1', ['topic', 'edit']], ['d2', ['xhs', 'douyin']], ['d3', ['brand']], ['d5', ['books']]] },
  { key: 'ecommerce', depts: [['d1', ['ticket', 'review']], ['d2', ['listing', 'price']], ['d3', ['ads']], ['d4', ['recon']]] },
  { key: 'developer', depts: [['d1', ['bug', 'review']], ['d2', ['support', 'release']], ['d3', ['social', 'seo']], ['d4', ['billing']]] }
];

let S = null;
let view = 'overview';
let connected = false;
const answers = {};

async function post(url, body = {}) {
  let r;
  try { r = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) }); }
  catch (e) { throw new Error(t('err.network')); }
  const j = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(j.code ? t('err.' + j.code, j.params) : (j.error || String(r.status)));
  return j;
}
let toastT;
function toast(msg) { const el = $('#toast'); el.textContent = msg; el.classList.add('show'); clearTimeout(toastT); toastT = setTimeout(() => el.classList.remove('show'), 2800); }

const run = () => (S && S.run) || null;
const units = () => (run() && run().units) || [];
const passed = u => u.state === 'done' || u.state === 'awaiting';
const busy = () => !!(S && S.running);
const status = () => (run() ? run().status : 'idle');
const botIndex = id => Math.max(0, S.bots.findIndex(b => b.id === id));
const botColor = id => `var(--d${botIndex(id) % 6 + 1})`;
const botName = id => t('bot.' + id);
const toolsText = b => [...new Set(b.tools.map(x => TOOL_KEY[x.split('_')[0]]).filter(Boolean))].map(k => t(k)).join(' · ');
const clock = s0 => { const s = Math.floor(s0); return String(Math.floor(s / 60)).padStart(2, '0') + ':' + String(s % 60).padStart(2, '0'); };
const summary = a => (a.summaryMsg ? I.msg(a.summaryMsg) : a.summary);

/* ---------------- 顶栏 ---------------- */
function renderHeader() {
  const st = status();
  $('#live').dataset.s = !connected ? 'idle' : st === 'error' ? 'paused' : st;
  $('#liveText').textContent = connected ? t('status.' + st) : t('status.offline');
  const b = $('#deskBadge'), n = S.approvals.pending.length, prev = +b.textContent;
  b.textContent = n; b.hidden = n === 0;
  if (n > prev) { b.classList.remove('bump'); void b.offsetWidth; b.classList.add('bump'); }
  $('#modeChip').textContent = S.hasKey ? t('ov.mode.live', { model: S.model }) : t('ov.mode.mock');
  const mt = $('#mockToggle'), liveCo = S.workspace === 'company';
  $('#resetBtn').hidden = liveCo;
  if (liveCo) { mt.checked = false; mt.disabled = true; mt.dataset.livelocked = '1'; mt.parentElement.classList.add('locked'); mt.parentElement.title = t('err.mockLive'); }
  else if (mt.dataset.livelocked) { delete mt.dataset.livelocked; mt.disabled = false; mt.parentElement.classList.remove('locked'); mt.parentElement.title = ''; }
  if (liveCo) { /* 上面已经处理 */ }
  else if (!S.hasKey) { mt.checked = true; mt.disabled = true; mt.dataset.autolocked = '1'; mt.parentElement.classList.add('locked'); mt.parentElement.title = t('ov.mode.locked'); }
  else if (mt.dataset.autolocked) { mt.checked = false; mt.disabled = false; delete mt.dataset.autolocked; mt.parentElement.classList.remove('locked'); mt.parentElement.title = ''; }
  $('#runBtn').disabled = busy(); $('#runBtn').textContent = t(busy() ? 'cmd.running' : 'cmd.run');
  const rb = $('#resetBtn'); rb.disabled = busy(); if (!resetArmed) rb.textContent = t('cmd.resetSample');
  $('#coName').textContent = S.owner.company;
  renderConnBtn(); renderMailBtn(); renderAcctBtn();
  if (mdlg.open) renderMailAccts();
  if (adlg.open) renderAcct();
  const cmd = $('#cmd'); if (!cmd.dataset.touched) cmd.value = t('cmd.default');
}

/* ---------------- 总览 ---------------- */
function statCell(cls, label, val, extra = '') { return `<div class="stat ${cls}"><b>${val}</b><span>${esc(label)}</span>${extra}</div>`; }
function renderStats() {
  const r = run(), us = units();
  const spent = r ? r.spentUsd : 0, budget = r ? r.budgetUsd : S.memory.budgetUsd;
  const pct = Math.min(100, budget ? spent / budget * 100 : 0);
  const html =
    statCell('', t('stat.bots'), S.bots.length) +
    statCell('', t('stat.units'), us.length) +
    statCell('ok', t('stat.ok'), us.filter(passed).length) +
    statCell('bad', t('stat.bad'), us.reduce((s, u) => s + u.feedback.length, 0)) +
    `<button type="button" class="stat wait" id="statWait" title="${esc(t('stat.waitTitle'))}"><b>${S.approvals.pending.length}</b><span>${esc(t('stat.wait'))}</span></button>` +
    statCell('', t('stat.rules'), S.memory.rules.filter(x => x.on).length) +
    statCell('', t('stat.spent', { budget: usd(budget) }), usd(spent), `<i class="meter"><u class="${pct >= 90 ? 'hi' : ''}" style="width:${pct}%"></u></i>`) +
    statCell('', t('stat.sent'), S.counts.sent);
  const box = $('#stats');
  if (box.dataset.sig !== html) { box.innerHTML = html; box.dataset.sig = html; }
}
function renderInputs() {
  const c = S.counts, r = run();
  const rows = [
    [t('in.instr'), t(r ? 'in.instrGiven' : 'in.instrNone')],
    [t('in.inbox'), c.emails == null ? t('mail.loading') : t('in.inboxN', { n: c.emails })],
    [t('in.calendar'), c.events == null ? '…' : t('in.calendarN', { n: c.events })],
    [t('in.contacts'), t('in.contactsN', { n: c.contacts })],
    ['MEMORY.md', t('in.memoryN', { n: S.memory.rules.filter(x => x.on).length })]
  ];
  const html = rows.map(([k, v]) => `<li><b>${esc(k)}</b><span>${esc(v)}</span></li>`).join('');
  const ul = $('#inputs'); if (ul.dataset.sig !== html) { ul.innerHTML = html; ul.dataset.sig = html; }
  ul.title = t('in.unreadTitle', { n: c.unread });
}
function renderOrch() {
  const r = run(), st = status();
  const text = !r ? t('orch.idle')
    : st === 'planning' ? t(r.criteria.length ? 'orch.splitting' : 'orch.readingLive')
    : st === 'running' ? t('orch.supervising')
    : st === 'waiting' ? t('orch.waiting', { n: S.approvals.pending.length })
    : st === 'error' ? t('orch.error')
    : t('orch.done');
  $('#orchStatus').textContent = text;
  $('#orch').toggleAttribute('data-busy', busy());
}
function renderCrit() {
  const list = run() ? run().criteria : [];
  const html = list.map(x => `<li>${esc(x)}</li>`).join('');
  const ol = $('#crit'); if (ol.dataset.sig !== html) { ol.innerHTML = html; ol.dataset.sig = html; }
  $('#critEmpty').hidden = list.length > 0; $('#critFoot').hidden = list.length === 0;
}
// 「同时执行」：这次运行里最多有几个 bot 同时在干活（每个单元一个 bot）
const PAR = { sig: '', n: 0 };
function renderSplit() {
  const us = units();
  $('#kvUnits').textContent = us.length;
  const sig = us.length + '|' + (us[0] ? us[0].id + us[0].title : '');
  if (sig !== PAR.sig) { PAR.sig = sig; PAR.n = 0; }
  PAR.n = Math.max(PAR.n, us.filter(u => u.state === 'running' || u.state === 'checking').length);
  $('#kvPar').textContent = PAR.n;
}
function buildDepts() {
  const box = $('#depts');
  const sig = I.lang + '|' + S.bots.map(b => b.id).join(',');
  if (box.dataset.sig === sig) return;
  $('#botsLabel').textContent = t('mesh.deptsLabelLive', { dept: t('dept.' + S.department), b: S.bots.length });
  box.innerHTML = `<div class="dept" style="--dc:var(--d1)"><div class="dept-h">${esc(t('dept.' + S.department))}</div>${
    S.bots.map(b => `<div class="bot" id="bot-${b.id}" style="--dc:${botColor(b.id)}" title="${esc(t('bot.' + b.id + '.role'))}"><span class="code">${b.code}</span><span class="bname">${esc(botName(b.id))}</span><span class="bstate"></span><span class="bmeta">${esc(toolsText(b))} · <span class="bc"></span></span></div>`).join('')
  }</div>`;
  box.dataset.sig = sig;
}
function paintBots() {
  for (const b of S.bots) {
    const el = document.getElementById('bot-' + b.id); if (!el) continue;
    // 每个单元一个 bot，同一类可能有几十个同时在干活
    const live = units().filter(u => u.bot === b.id && (u.state === 'running' || u.state === 'checking'));
    const cur = live[0];
    el.classList.toggle('busy', !!cur);
    el.querySelector('.bstate').textContent = live.length > 1 ? t('bot.workingN', { n: live.length })
      : cur ? (cur.state === 'checking' ? t('bot.checking') : `${cur.kind} ${cur.ref || ''}`.trim()) : t('bot.idle');
    el.querySelector('.bc').textContent = t('bot.passedN', { n: units().filter(u => u.bot === b.id && passed(u)).length });
  }
}
function renderUnits() {
  const box = $('#units'), r = run();
  if (!r || !r.units.length) {
    const key = 'empty-' + (busy() ? 'busy' : 'idle') + I.lang;
    if (box.dataset.run !== key) {
      box.innerHTML = busy()
        ? `<div class="empty"><b>${esc(t('units.splittingTitle'))}</b>${esc(t('units.splitting'))}</div>`
        : `<div class="empty"><b>${esc(t('units.emptyTitle'))}</b>${esc(t('units.emptyLive'))}</div>`;
      box.dataset.run = key;
    }
    return;
  }
  if (box.dataset.run !== r.runId) { box.innerHTML = ''; box.dataset.run = r.runId; }
  r.units.forEach((u, i) => {
    let el = document.getElementById('u-' + u.id);
    if (!el) {
      el = document.createElement('span');
      el.id = 'u-' + u.id; el.title = u.title;
      el.style.setProperty('--dc', botColor(u.bot));
      if (!reduced) { el.dataset.in = '1'; el.style.animationDelay = (i * 18) + 'ms'; }
      box.append(el);
    }
    const cls = 'u ' + UCLASS[u.state] + (el.dataset.in ? ' in' : '');
    if (el.className !== cls) el.className = cls;
    const label = `${esc(u.kind)}${u.ref ? ` <small>${esc(u.ref)}</small>` : ''}${u.attempts > 1 ? `<sup>×${u.attempts}</sup>` : ''}`;
    if (el.dataset.l !== label) { el.innerHTML = label; el.dataset.l = label; }
  });
}
let logKey = null, logN = 0;
function logItem(l, animate) {
  const li = document.createElement('li');
  if (animate) li.className = 'in';
  const sub = l.sub ? '<br>' + l.sub.map((x, n) => `${n + 1}. ${esc(x)}`).join('<br>') : '';
  li.innerHTML = `<time>${clock(l.t)}</time><span class="who w-${l.kind}">${esc(I.msg(l.who))}</span><span class="msg">${esc(I.msg(l.msg))}${sub}</span>`;
  return li;
}
function renderLog(force) {
  const r = run(), ol = $('#log');
  const key = r ? r.runId + '|' + r.startedAt : 'none';
  if (force || key !== logKey || (r && r.log.length < logN)) { ol.innerHTML = ''; logKey = key; logN = 0; }
  if (!r) { $('#logCount').textContent = t('log.count', { n: 0 }); return; }
  for (let i = logN; i < r.log.length; i++) ol.prepend(logItem(r.log[i], !reduced && logN > 0));
  logN = r.log.length;
  $('#logCount').textContent = t('log.count', { n: logN });
}
function renderBanners() {
  const r = run();
  $('#budgetBanner').hidden = !(r && r.stoppedByBudget);
  $('#budgetText').textContent = t('banner.budgetLive');
  $('#errBanner').hidden = !(r && r.status === 'error');
  $('#errText').textContent = r && r.error ? t('banner.error', { msg: r.error }) : '';
}
function renderOverview() {
  renderStats(); renderInputs(); renderOrch(); renderCrit(); renderSplit();
  buildDepts(); paintBots(); renderUnits(); renderLog(); renderBanners();
}

/* ---------------- 决策台 ---------------- */
/** 真实邮箱里的事：回复从收到原邮件的邮箱发，新邮件/日程用指定的或主邮箱 */
function viaAccount(a) {
  if (!a.source || a.source === 'local' || !S.mail || !S.mail.accounts.length) return '';
  const accts = S.mail.accounts, i = a.input;
  if (typeof i.from === 'string' && i.from) return i.from;
  if (typeof i.calendar === 'string' && i.calendar) return i.calendar;
  const m = typeof i.replyTo === 'string' && i.replyTo.match(/^([a-z]\d+)-/);
  const hit = m && accts.find(x => x.id === m[1]);
  return hit ? hit.email : (accts.find(x => x.primary) || accts[0]).email;
}
function deskCard(a) {
  const b = S.bots.find(x => x.id === a.bot);
  const ask = a.tool === 'desk_ask';
  const body = !ask && typeof a.input.body === 'string' ? a.input.body : null;
  const askHtml = ask ? `<pre class="appr-body">${esc(a.input.context || '')}</pre><p class="appr-t">${esc(t('desk.recommend', { text: a.input.recommendation || '' }))}</p>` : '';
  const people = Array.isArray(a.input.attendees) ? `<p class="appr-why">${esc(t('desk.attendees', { list: I.list(a.input.attendees) }))}</p>` : '';
  const via = viaAccount(a);
  const viaLine = via ? `<p class="appr-why">${esc(t(a.tool === 'calendar_book' ? 'desk.onCalendar' : 'desk.from', { email: via }))}</p>` : '';
  return `<article class="appr${reduced ? '' : ' in'}" id="ap-${a.id}" data-id="${a.id}" style="--dc:${botColor(a.bot)}">
    <div class="appr-top"><span class="mini-code">${esc(b ? b.code : '')}</span>${esc(b ? botName(b.id) : a.bot)} · ${esc(a.unitId)} · <code>${esc(a.tool)}</code><span class="risk">${esc(t('risk.' + a.risk))}</span><span class="ex">${a.id}</span></div>
    <p class="appr-t">${esc(summary(a))}</p>
    ${body ? `<pre class="appr-body">${esc(body)}</pre>` : ''}${askHtml}${people}${viaLine}
    <p class="appr-why">${esc(t('riskWhy.' + a.risk))}</p>
    ${body ? `<details><summary>${esc(t('desk.edit'))}</summary><textarea id="ed-${a.id}" aria-label="${esc(t('desk.editAria'))}">${esc(body)}</textarea></details>` : ''}
    <div class="appr-act">
      <button type="button" class="btn primary" data-act="approve" data-id="${a.id}">${esc(t('desk.approve'))}</button>
      <button type="button" class="btn danger" data-act="reject" data-id="${a.id}">${esc(t('desk.reject'))}</button>
      <span class="appr-err" id="er-${a.id}"></span>
    </div>
    <label class="rule-opt"><input type="checkbox" id="rc-${a.id}"> ${esc(t('desk.ruleOpt'))}<input type="text" id="rt-${a.id}" placeholder="${esc(t('desk.rulePlaceholder'))}" aria-label="${esc(t('desk.ruleAria'))}"></label>
  </article>`;
}
function deskEmpty() {
  return `<div class="empty"><b>${esc(t('desk.emptyTitle'))}</b>${esc(t(busy() ? 'desk.emptyRunning' : 'desk.emptyIdle'))}</div>`;
}
function renderDesk(force) {
  const list = $('#apprList'), pend = S.approvals.pending, ids = new Set(pend.map(a => a.id));
  if (force) list.innerHTML = '';
  $$('.appr', list).forEach(el => { if (!ids.has(el.dataset.id)) el.remove(); });
  if (!pend.length) list.innerHTML = deskEmpty();
  else {
    const empty = list.querySelector('.empty'); if (empty) empty.remove();
    pend.forEach(a => { if (!document.getElementById('ap-' + a.id)) list.insertAdjacentHTML('beforeend', deskCard(a)); });
  }
  const h = S.approvals.history;
  $('#hist').innerHTML = h.length ? h.map(a =>
    `<li><span class="st ${a.status === 'approved' ? 'ok' : 'bad'}">${esc(t(a.status === 'approved' ? (a.edited ? 'desk.st.edited' : 'desk.st.approved') : 'desk.st.rejected'))}</span><span class="t">${esc(summary(a))}</span></li>`).join('')
    : `<li><span class="t">${esc(t('desk.historyEmpty'))}</span></li>`;
}
$('#apprList').addEventListener('click', async e => {
  const btn = e.target.closest('button[data-act]'); if (!btn) return;
  const id = btn.dataset.id, a = S.approvals.pending.find(x => x.id === id); if (!a) return;
  const card = $('#ap-' + id); $$('button', card).forEach(x => { x.disabled = true; });
  try {
    if (btn.dataset.act === 'approve') {
      const ed = $('#ed-' + id), body = ed && ed.value.trim() && ed.value !== a.input.body ? ed.value : undefined;
      await post(`/api/approvals/${id}/approve`, body ? { body } : {});
      toast(t('toast.approvedId', { id }));
    } else {
      const rule = $('#rc-' + id).checked ? $('#rt-' + id).value.trim() : '';
      await post(`/api/approvals/${id}/reject`, rule ? { rule } : {});
      toast(t(rule ? 'toast.rejectedRule' : 'toast.rejected'));
    }
  } catch (err) {
    $('#er-' + id).textContent = err.message;
    $$('button', card).forEach(x => { x.disabled = false; });
  }
});

/* ---------------- 规则与记忆 ---------------- */
function renderRules() {
  const red = RISKS.map(k => `<label class="sw"><input type="checkbox" class="tg" data-red="${k}" ${S.memory.redlines[k] ? 'checked' : ''}><span><span class="sw-t">${esc(t('risk.' + k))}</span><span class="sw-s">${esc(t('riskDesc.' + k))}</span></span></label>`).join('');
  const rb = $('#redlines'); if (rb.dataset.sig !== red) { rb.innerHTML = red; rb.dataset.sig = red; }
  const range = $('#budget');
  if (document.activeElement !== range) range.value = S.memory.budgetUsd;
  $('#budgetVal').textContent = usd(Number(range.value));
  const list = S.memory.rules;
  $('#ruleCount').textContent = t('rules.countOn', { n: list.filter(r => r.on).length });
  const html = list.map((r, i) => `<label class="sw"><input type="checkbox" class="tg" data-rule="${i}" ${r.on ? 'checked' : ''}><span><span class="sw-t">${esc(r.text)}</span><span class="sw-s">${esc(r.src)}</span></span></label>`).join('');
  const rl = $('#ruleList'); if (rl.dataset.sig !== html) { rl.innerHTML = html; rl.dataset.sig = html; }
  $('#memory').textContent = S.memory.raw;
}
$('#v-rules').addEventListener('change', async e => {
  const el = e.target;
  try {
    if (el.dataset.red) { await post('/api/redline', { risk: el.dataset.red, on: el.checked }); toast(t(el.checked ? 'toast.redlineOn' : 'toast.redlineOff', { name: t('risk.' + el.dataset.red) })); }
    else if (el.dataset.rule) { const r = S.memory.rules[+el.dataset.rule]; await post('/api/rules/toggle', { text: r.text, on: el.checked }); }
    else if (el.id === 'budget') { await post('/api/budget', { usd: Number(el.value) }); toast(t('toast.budget', { v: usd(Number(el.value)) })); }
  } catch (err) { toast(err.message); }
});
$('#budget').addEventListener('input', e => { $('#budgetVal').textContent = usd(Number(e.target.value)); });
$('#addRule').addEventListener('submit', async e => {
  e.preventDefault(); const v = $('#newRule').value.trim(); if (!v) return;
  try { const r = await post('/api/rules', { text: v }); $('#newRule').value = ''; toast(t(r.added ? 'toast.ruleSaved' : 'toast.ruleExists')); }
  catch (err) { toast(err.message); }
});

/* ---------------- 损益表 ---------------- */
function renderPnl() {
  const rate = Number(store.get('rate', 50)) || 50;
  const P = S.pnl, bots = P.actors.filter(a => a.kind === 'bot'), over = P.actors.filter(a => a.kind === 'overhead');
  const actorName = a => (a.kind === 'bot' ? botName(a.id) : a.id === 'orchestrator' ? t('log.who.orch') : t('log.who.check'));
  const minutes = bots.reduce((s, a) => s + a.minutes, 0), value = minutes / 60 * rate, passedN = bots.reduce((s, a) => s + a.passed, 0);
  $('#tiles').innerHTML = [
    [t('tile.aiCost'), usd(P.totalUsd), t('tile.aiCostLive', { n: P.runs }) + (P.mockRuns ? t('tile.aiCostMock', { m: P.mockRuns }) : ''), ''],
    [t('tile.savedEst'), t('unit.hours', { n: (minutes / 60).toFixed(1) }), t('tile.savedLive', { n: passedN }), ''],
    [t('tile.value'), usd(value), t('tile.valueLive', { rate: usd(rate) }), 'good'],
    [t('tile.sent'), String(S.counts.sent), t('tile.sentSub', { n: S.counts.drafts }), '']
  ].map(([k, v, s, c]) => `<div class="tile ${c}"><span>${esc(k)}</span><b>${esc(v)}</b><small>${esc(s)}</small></div>`).join('');
  const roiMax = Math.max(1, ...bots.map(a => (a.usd ? a.minutes / 60 * rate / a.usd : 0)));
  let html = `<thead><tr>${['th.bot', 'th.passed', 'th.rej', 'th.calls', 'th.cost', 'th.saved', 'th.value', 'th.roi'].map(k => `<th>${esc(t(k))}</th>`).join('')}</tr></thead><tbody>`;
  html += `<tr class="dept-row"><td colspan="8">${esc(t('dept.' + S.department))}</td></tr>`;
  bots.forEach(a => {
    const v = a.minutes / 60 * rate, roi = a.usd ? v / a.usd : null;
    html += `<tr><td>${esc(actorName(a))}</td><td>${a.passed}</td><td>${a.rejections}</td><td>${a.calls}</td><td>${usd(a.usd)}</td><td>${(a.minutes / 60).toFixed(1)} h</td><td>${usd(v)}</td><td>${roi == null ? '—' : `<span class="roi"><i class="${roi < 1 ? 'lo' : ''}" style="width:${Math.max(2, Math.round(roi / roiMax * 90))}px"></i>${roi.toFixed(0)}×</span>`}</td></tr>`;
  });
  if (over.length) {
    html += `<tr class="dept-row"><td colspan="8">${esc(t('pnl.overhead'))}</td></tr>`;
    over.forEach(a => { html += `<tr><td>${esc(actorName(a))}</td><td>—</td><td>—</td><td>${a.calls}</td><td>${usd(a.usd)}</td><td>—</td><td>—</td><td>—</td></tr>`; });
  }
  html += `<tr class="sum"><td>${esc(t('pnl.total'))}</td><td>${passedN}</td><td>${bots.reduce((s, a) => s + a.rejections, 0)}</td><td>${P.actors.reduce((s, a) => s + a.calls, 0)}</td><td>${usd(P.totalUsd)}</td><td>${(minutes / 60).toFixed(1)} h</td><td>${usd(value)}</td><td>${P.totalUsd ? (value / P.totalUsd).toFixed(0) + '×' : '—'}</td></tr></tbody>`;
  $('#pnlTable').innerHTML = html;
  $('#rateCur').textContent = '$';
}
$('#rate').addEventListener('input', e => { const v = Number(e.target.value); if (v > 0) { store.set('rate', v); renderPnl(); } });

/* ---------------- 导师课 ---------------- */
function tutorQuestions() {
  const bots = S.pnl.actors.filter(a => a.kind === 'bot');
  const top = [...bots].sort((a, b) => b.usd - a.usd || b.passed - a.passed)[0];
  const qs = [];
  qs.push(S.pnl.totalUsd > 0
    ? t('tq.costTotal', { bot: botName(top.id), cost: usd(top.usd), pct: Math.round(top.usd / S.pnl.totalUsd * 100) })
    : t('tq.busy', { bot: botName(top.id), n: top.passed }));
  const rej = units().filter(u => u.feedback.length);
  qs.push(rej.length ? t('tq.rejects', { n: rej.length, unit: `${rej[0].id} ${rej[0].kind}`, reason: rej[0].feedback[0] }) : t('tq.noRejects'));
  const h = S.approvals.history, ok = h.filter(a => a.status === 'approved').length;
  qs.push(h.length ? t('tq.desk', { ok, no: h.length - ok }) : t('tq.noDesk'));
  qs.push(t('tq.keep', { k: 2, n: S.bots.length }));
  return qs;
}
function renderTutor() {
  $('#qs').innerHTML = tutorQuestions().map((q, i) => {
    const a = answers[i];
    return `<div class="tq"><span class="tq-n">${['I', 'II', 'III', 'IV'][i]}</span><div class="tq-b"><p>${esc(q)}</p>${
      a ? `<div class="reply"><b>${esc(t('tutor.you'))}</b>${esc(a.text)}</div><div class="reply"><b>${esc(t('tutor.tutor'))}</b>${esc(t(a.replyKey))}</div>`
        : `<div class="ans"><textarea id="qa-${i}" aria-label="${esc(t('tutor.answerAria', { n: i + 1 }))}" placeholder="${esc(t('tutor.answerPlaceholder'))}"></textarea><button type="button" class="btn" data-q="${i}">${esc(t('tutor.answer'))}</button></div>`
    }</div></div>`;
  }).join('');
}
$('#qs').addEventListener('click', e => {
  const btn = e.target.closest('button[data-q]'); if (!btn) return;
  const i = +btn.dataset.q, text = $('#qa-' + i).value.trim(); if (!text) { $('#qa-' + i).focus(); return; }
  const replyKey = text.length < 15 ? 'tutor.short' : !/\d/.test(text) ? 'tutor.noNumber' : 'tutor.f' + ((text.length + i) % 4 + 1);
  answers[i] = { text, replyKey }; renderTutor();
});
const essay = $('#essay');
essay.value = store.get('essay', '');
const countEssay = () => {
  const v = essay.value, wordy = I.lang === 'en' || I.lang === 'vi';
  const n = wordy ? (v.trim() ? v.trim().split(/\s+/).length : 0) : v.replace(/\s/g, '').length;
  $('#essayCount').textContent = t('tutor.count', { n });
};
essay.addEventListener('input', () => { store.set('essay', essay.value); countEssay(); });

/* ---------------- 公司模板 ---------------- */
function renderTemplates() {
  $('#tpls').innerHTML = TEMPLATES.map(tp => {
    const on = tp.key === 'consultant';
    return `<div class="tpl ${on ? 'on' : 'soon'}"><h3>${esc(t(`t.${tp.key}.name`))}</h3><p class="who">${esc(t(`t.${tp.key}.who`))}</p>
      <ul>${tp.depts.map(([d, bots]) => `<li><b>${esc(t(`t.${tp.key}.${d}`))}</b><span>${esc(I.list(bots.map(b => t(`t.${tp.key}.b.${b}`))))}</span></li>`).join('')}</ul>
      <div class="foot">${on ? `<span class="on-tag">${esc(t('tpl.inUse'))}</span><span>${esc(t('tpl.liveBots', { list: I.list(S.bots.map(b => botName(b.id))) }))}</span>` : `<span>${esc(t('tpl.soon'))}</span>`}</div></div>`;
  }).join('');
}

/* ---------------- 视图切换 ---------------- */
const VIEWS = ['overview', 'desk', 'rules', 'pnl', 'tutor', 'templates'];
function renderView(force) {
  if (!S) return;
  if (view === 'desk') renderDesk(force);
  if (view === 'rules') renderRules();
  if (view === 'pnl') { $('#rate').value = store.get('rate', 50); renderPnl(); }
  if (view === 'templates') renderTemplates();
}
function show(v) {
  if (!VIEWS.includes(v)) v = 'overview';
  const changed = v !== view; view = v;
  VIEWS.forEach(x => { $('#v-' + x).hidden = x !== v; });
  $$('.tabs a').forEach(a => { if (a.dataset.view === v) a.setAttribute('aria-current', 'page'); else a.removeAttribute('aria-current'); });
  renderView();
  if (v === 'tutor' && S && (changed || !$('#qs').children.length)) renderTutor();
}
function go(v) { show(v); try { if (location.hash !== '#' + v) history.replaceState(null, '', '#' + v); } catch (e) { /* 地址栏不可写 */ } window.scrollTo(0, 0); }
window.addEventListener('hashchange', () => { if (location.hash === '#connect') openConn(); else if (location.hash === '#mail') openMail(); else show(location.hash.slice(1)); });
document.addEventListener('click', e => {
  const a = e.target.closest('a[href^="#"]'); if (!a) return;
  const v = a.getAttribute('href').slice(1); if (!VIEWS.includes(v)) return;
  e.preventDefault(); go(v);
});
$('#stats').addEventListener('click', e => { if (e.target.closest('#statWait')) go('desk'); });
$('#units').addEventListener('click', e => { if (e.target.closest('.u.wait')) go('desk'); });
$('#cmd').addEventListener('input', e => { e.target.dataset.touched = '1'; });
$('#cmdForm').addEventListener('submit', async e => {
  e.preventDefault();
  try { await post('/api/run', { instruction: $('#cmd').value.trim(), mock: $('#mockToggle').checked }); }
  catch (err) { toast(err.message); }
});
let resetArmed = null;
$('#resetBtn').addEventListener('click', async e => {
  const btn = e.currentTarget;
  if (!resetArmed) {
    btn.textContent = t('cmd.resetConfirm'); btn.classList.add('danger');
    resetArmed = setTimeout(() => { resetArmed = null; btn.textContent = t('cmd.resetSample'); btn.classList.remove('danger'); }, 3500);
    return;
  }
  clearTimeout(resetArmed); resetArmed = null; btn.textContent = t('cmd.resetSample'); btn.classList.remove('danger');
  try { await post('/api/reset'); toast(t('toast.reset')); } catch (err) { toast(err.message); }
});

/* ---------------- 连接模型 ---------------- */
const MODEL_CHOICES = { openai: ['gpt-6.1-sol', 'gpt-6.1-terra', 'gpt-6-astra', 'gpt-5.5'], claude: ['claude-opus-5-5', 'claude-sonnet-5-5', 'claude-fable-5-2'] };
const DEFAULT_MODEL = { openai: 'gpt-6.1-sol', claude: 'claude-opus-5-5' };
const dlg = $('#connDlg');
const connProv = () => ($$('input[name=connProv]').find(r => r.checked) || {}).value || 'openai';
function renderConnBtn() {
  if (!S) return;
  $('#connBtn').classList.toggle('on', S.hasKey);
  $('#connText').textContent = S.hasKey ? S.model : t('conn.button');
}
function fillConnProvider(prov, keepModel) {
  const c = S.connection;
  $('#connModels').innerHTML = MODEL_CHOICES[prov].map(m => `<option value="${m}"></option>`).join('');
  const m = $('#connModel');
  if (!keepModel || !m.value || Object.values(DEFAULT_MODEL).includes(m.value) && !MODEL_CHOICES[prov].includes(m.value)) {
    m.value = c.source === 'saved' && c.savedProvider === prov ? c.model : DEFAULT_MODEL[prov];
  }
  $('#connKeyNote').textContent = c.savedProvider === prov ? t('conn.keyKeep', { hint: c.keyHint }) : c.source === 'env' && c.provider === prov ? t('conn.envNote', { hint: c.keyHint }) : '';
  $('#connBaseWrap').hidden = prov !== 'openai';
}
function openConn() {
  if (!S) return;
  const c = S.connection;
  const prov = c.savedProvider || (c.provider === 'claude' ? 'claude' : 'openai');
  $$('input[name=connProv]').forEach(r => { r.checked = r.value === prov; });
  $('#connKey').value = '';
  $('#connModel').value = '';
  $('#connBase').value = c.baseURL || '';
  $('#connPin').value = c.priceInput ?? '';
  $('#connPout').value = c.priceOutput ?? '';
  $('#connErr').textContent = '';
  $('#connDisc').hidden = c.source !== 'saved';
  fillConnProvider(prov, false);
  dlg.showModal();
  $('#connKey').focus();
}
$('#connBtn').addEventListener('click', openConn);
$('#modeChip').addEventListener('click', openConn);
$$('input[name=connProv]').forEach(r => r.addEventListener('change', () => fillConnProvider(connProv(), true)));
$('#connCancel').addEventListener('click', () => dlg.close());
$('#connForm').addEventListener('submit', async e => {
  e.preventDefault();
  const btn = $('#connSave'), num = id => { const v = Number($(id).value); return v > 0 ? v : undefined; };
  $('#connErr').textContent = '';
  btn.disabled = true; btn.textContent = t('conn.saving');
  try {
    const r = await post('/api/connect', {
      provider: connProv(), apiKey: $('#connKey').value.trim(), model: $('#connModel').value.trim(),
      baseURL: connProv() === 'openai' ? $('#connBase').value.trim() : '', priceInput: num('#connPin'), priceOutput: num('#connPout')
    });
    $('#connKey').value = '';
    dlg.close();
    toast(t('conn.ok', { model: r.model }));
  } catch (err) {
    $('#connErr').textContent = err.message;
  } finally {
    btn.disabled = false; btn.textContent = t('conn.save');
  }
});
$('#connDisc').addEventListener('click', async () => {
  try { await post('/api/disconnect'); dlg.close(); toast(t('conn.removed')); } catch (err) { $('#connErr').textContent = err.message; }
});

/* ---------------- Oxford Solo 账号和付费等级（开关关着时整块不显示） ---------------- */
const adlg = $('#acctDlg');
const PLAN_CARDS = ['personal', 'pro', 'team'];
let acctStep = 'email';
const planName = p => t('plan.' + p);
const day10 = iso => (iso ? String(iso).slice(0, 10) : '');
const daysLeft = iso => Math.max(0, Math.ceil((Date.parse(iso) - Date.now()) / 86400000));
const acctInterval = () => ($$('input[name=acctInt]').find(r => r.checked) || {}).value || 'month';
function renderAcctBtn() {
  const P = S && S.plan, b = $('#acctBtn');
  b.hidden = !(P && P.licensing);
  if (b.hidden) return;
  b.classList.toggle('on', P.plan !== 'none');
  $('#acctText').textContent = !P.signedIn ? t('acct.button')
    : P.plan === 'none' ? t('acct.noPlan')
    : planName(P.plan) + (P.source === 'trial' && P.until ? ' · ' + t('acct.daysLeft', { n: daysLeft(P.until) }) : '');
}
function renderAcct() {
  const P = S.plan, signed = !!P.signedIn;
  const sub = P.account && P.account.subscription;
  $('#acctOut').hidden = signed;
  $('#acctIn').hidden = !signed;
  $('#acctLogout').hidden = !signed;
  $('#acctPortal').hidden = !(signed && sub);
  $('#acctGo').hidden = signed;
  $('#acctGo').textContent = t(acctStep === 'code' ? 'acct.verify' : 'acct.send');
  $('#acctCodeWrap').hidden = signed || acctStep !== 'code';
  if (!signed) return;
  const L = P.limits;
  const src = P.source === 'none' ? '' : t('acct.src.' + P.source) + (P.until ? ' · ' + t('acct.until', { date: day10(P.until) }) : '');
  $('#acctNow').innerHTML =
    `<div><b>${esc(P.email)}</b></div>` +
    `<div><span class="plan-pill${P.plan === 'none' ? ' none' : ''}">${esc(P.plan === 'none' ? t('acct.noPlan') : planName(P.plan))}</span> <span class="muted">${esc(src)}</span></div>` +
    (P.plan === 'none' ? `<p class="dlg-intro">${esc(t('acct.nonePitch'))}</p>`
      : `<div class="muted">${esc(t('acct.limits', { n: L.mailboxes }))} · ${esc(t(L.calendarBooking ? 'acct.bookYes' : 'acct.bookNo'))}</div>`) +
    (sub ? `<div class="muted">${esc(t('acct.sub', { plan: planName(sub.plan), interval: t(sub.interval === 'year' ? 'acct.int.year' : 'acct.int.month'), date: day10(sub.periodEnd) }))}${sub.cancelAtPeriodEnd ? ' · ' + esc(t('acct.cancelAtEnd')) : ''}</div>` : '') +
    (P.error ? `<p class="dlg-err">${esc(t('err.acct.' + P.error.code))}</p>` : '');
  $('#acctPlans').innerHTML = PLAN_CARDS.map(p => {
    const cur = P.plan === p && P.source !== 'trial';
    return `<div class="plan-card${cur ? ' cur' : ''}"><h3>${esc(planName(p))}</h3><ul>${[1, 2, 3].map(i => `<li>${esc(t('plan.' + p + '.f' + i))}</li>`).join('')}</ul>` +
      `<button type="button" class="btn ${cur ? 'ghost' : 'primary'}" data-plan="${p}"${cur ? ' disabled' : ''}>${esc(t(cur ? 'acct.current' : 'acct.choose'))}</button></div>`;
  }).join('');
  $$('#acctPlans [data-plan]').forEach(b => b.addEventListener('click', () => acctCheckout(b.dataset.plan, b)));
}
async function acctCheckout(plan, btn) {
  $('#acctErr').textContent = '';
  btn.disabled = true;
  try {
    const r = await post('/api/account/checkout', { plan, interval: acctInterval() });
    window.open(r.url, '_blank', 'noopener');
    toast(t('acct.checkoutOpened'));
  } catch (err) { $('#acctErr').textContent = err.message; }
  finally { btn.disabled = false; }
}
function openAcct() {
  if (!S || !S.plan || !S.plan.licensing) return;
  acctStep = 'email';
  $('#acctErr').textContent = '';
  $('#acctCode').value = '';
  if (!$('#acctEmail').value) $('#acctEmail').value = S.plan.email || '';
  renderAcct();
  adlg.showModal();
  if (S.plan.signedIn) post('/api/account/refresh').catch(() => {});
  else $('#acctEmail').focus();
}
$('#acctBtn').addEventListener('click', openAcct);
$('#acctClose').addEventListener('click', () => adlg.close());
$$('input[name=acctInt]').forEach(r => r.addEventListener('change', () => S && renderAcct()));
$('#acctForm').addEventListener('submit', async e => {
  e.preventDefault();
  const btn = $('#acctGo');
  $('#acctErr').textContent = '';
  btn.disabled = true;
  try {
    if (acctStep === 'email') {
      await post('/api/account/start', { email: $('#acctEmail').value.trim() });
      acctStep = 'code';
      renderAcct();
      $('#acctCode').focus();
    } else {
      await post('/api/account/verify', { email: $('#acctEmail').value.trim(), code: $('#acctCode').value.trim() });
      acctStep = 'email';
      toast(t('acct.welcome'));
    }
  } catch (err) { $('#acctErr').textContent = err.message; }
  finally { btn.disabled = false; if (S) renderAcct(); }
});
$('#acctLogout').addEventListener('click', async () => {
  try { await post('/api/account/logout'); toast(t('acct.loggedOut')); } catch (err) { $('#acctErr').textContent = err.message; }
});
$('#acctPortal').addEventListener('click', async () => {
  try { const r = await post('/api/account/portal'); window.open(r.url, '_blank', 'noopener'); } catch (err) { $('#acctErr').textContent = err.message; }
});

/* ---------------- 连接邮箱（Gmail / Outlook） ---------------- */
const mdlg = $('#mailDlg');
const MAIL_SHORT = { google: 'Gmail', microsoft: 'Outlook' };
const MAIL_LINKS = {
  google: [
    [['', 'https://console.cloud.google.com/projectcreate']],
    [['Gmail API', 'https://console.cloud.google.com/apis/library/gmail.googleapis.com'], ['Calendar API', 'https://console.cloud.google.com/apis/library/calendar-json.googleapis.com']],
    [['', 'https://console.cloud.google.com/auth/branding']],
    [['', 'https://console.cloud.google.com/auth/clients']],
    []
  ],
  microsoft: [[['', 'https://entra.microsoft.com/#view/Microsoft_AAD_RegisteredApps/ApplicationsListBlade']], [], [], [], []]
};
const mailProv = () => ($$('input[name=mailProv]').find(r => r.checked) || {}).value || 'google';
const mailApp = p => (S.mail.apps && S.mail.apps[p]) || {};
const mailPrimary = () => S.mail.accounts.find(a => a.primary) || S.mail.accounts[0];
const msRedirect = () => `http://localhost:${location.port || '4610'}/oauth/microsoft/callback`;
const mailErrText = e => (!e ? '' : e.code ? t('err.' + e.code, e.params || {}) : e.msg);
const mailAcctErr = a => (S.mail.accountErrors || []).find(x => x.id === a.id);
function renderMailBtn() {
  if (!S || !S.mail) return;
  const m = S.mail, live = m.active === 'live' && m.accounts.length, p = live ? mailPrimary() : null, n = m.accounts.length;
  const trouble = !!m.error || (m.accountErrors || []).length > 0 || m.accounts.some(a => a.needsReauth);
  $('#mailBtn').classList.toggle('on', !!live && !trouble);
  $('#mailText').textContent = live ? `${MAIL_SHORT[p.provider]} · ${p.email}${n > 1 ? ` +${n - 1}` : ''}` : t('mail.button');
  const chip = $('#dataChip');
  chip.removeAttribute('data-i18n'); chip.classList.add('live-src'); chip.classList.toggle('bad', !!live && trouble);
  chip.textContent = !live ? t('mail.sample') : n > 1 ? t('mail.chipMore', { name: MAIL_SHORT[p.provider], email: p.email, n }) : t('mail.chip', { name: MAIL_SHORT[p.provider], email: p.email });
  chip.title = m.error ? t('mail.countErr', { msg: mailErrText(m.error) }) : m.loading ? t('mail.loading') : t('mail.btnTitle');
}
function renderMailAccts() {
  const m = S.mail, live = m.active === 'live';
  const row = (name, sub, cls, act) => `<div class="acct ${cls}"><i></i><div class="acct-m"><b>${esc(name)}</b><small>${esc(sub)}</small></div><span class="acct-act">${act}</span></div>`;
  const btn = (attr, label, extra = '') => `<button type="button" class="btn ghost sm ${extra}" ${attr}>${esc(label)}</button>`;
  let html = row(t('mail.sample'), t('mail.sampleSub'), live ? 'ok' : 'on ok', live ? btn('data-use="local"', t('mail.use')) : `<em>${esc(t('mail.using'))}</em>`);
  for (const a of m.accounts) {
    const err = mailAcctErr(a);
    const sub = a.needsReauth ? t('mail.needsReauth') : err ? t('mail.countErr', { msg: mailErrText(err) }) : t('mail.' + a.provider + 'Sub');
    const act = (a.primary ? `<em>${esc(t('mail.primary'))}</em>` : btn(`data-primary="${a.id}"`, t('mail.setPrimary'))) + btn(`data-disc="${a.id}"`, t('mail.disconnect'), 'danger');
    html += row(`${MAIL_SHORT[a.provider]} · ${a.email}`, sub, `${live ? 'on' : ''} ${a.needsReauth || err ? 'warn' : 'ok'}`, act);
  }
  if (!live && m.accounts.length) html += `<div class="acct-live">${btn('data-use="live"', t('mail.useLive', { n: m.accounts.length }), 'primary')}</div>`;
  $('#mailAccts').innerHTML = html;
  $('#mailSig').hidden = S.workspace !== 'company';
  if ($('#sigBoxes').dataset.key !== sigBoxKey()) renderSigBoxes();
  $('#mailErr').textContent = m.lastError ? mailErrText(m.lastError) : m.error && live ? t('mail.countErr', { msg: mailErrText(m.error) }) : '';
}
/** 每个邮箱各自的署名（连了两个以上邮箱时才显示）；重画时保留老板正在填的内容 */
function sigBoxKey() { return S.mail.active === 'live' ? S.mail.accounts.map(a => a.email).join(',') : ''; }
function renderSigBoxes(fromSaved = false) {
  const wrap = $('#sigBoxes'), key = sigBoxKey(), boxes = key ? key.split(',') : [];
  const typed = {};
  if (!fromSaved) $$('#sigBoxes .sig-box').forEach(b => { typed[b.dataset.email] = { name: b.querySelector('.sb-name').value, company: b.querySelector('.sb-company').value }; });
  const saved = (S.owner && S.owner.signatures) || {};
  wrap.dataset.key = key;
  wrap.hidden = boxes.length < 2;
  wrap.innerHTML = boxes.length < 2 ? '' : `<p class="dlg-note">${esc(t('mail.sigPerHint'))}</p>` + boxes.map(e => {
    const s = typed[e] || saved[e.toLowerCase()] || {};
    return `<div class="sig-box" data-email="${esc(e)}"><span class="sig-for">${esc(t('mail.sigFor', { email: e }))}</span><div class="fld-row">`
      + `<input type="text" class="sb-name" maxlength="80" aria-label="${esc(t('mail.sigName') + ' · ' + e)}" placeholder="${esc(S.owner.name || t('mail.sigName'))}" value="${esc(s.name || '')}">`
      + `<input type="text" class="sb-company" maxlength="120" aria-label="${esc(t('mail.sigCompany') + ' · ' + e)}" placeholder="${esc(S.owner.company || t('mail.sigCompany'))}" value="${esc(s.company || '')}">`
      + `</div></div>`;
  }).join('');
}
/** reset = false：只换语言，不动老板正在填的内容 */
function fillMailProvider(prov, reset = true) {
  const a = mailApp(prov), g = prov === 'google';
  $('#mailIdNote').textContent = a.clientIdHint ? t('mail.clientIdKeep', { hint: a.clientIdHint }) : '';
  $('#mailSecretWrap').hidden = !g;
  $('#mailSecretNote').textContent = a.hasSecret ? t('mail.secretKeep') : '';
  $('#mailTenantWrap').hidden = g;
  if (reset) $('#mailTenant').value = a.tenant && a.tenant !== 'common' ? a.tenant : '';
  $('#mailClientId').placeholder = g ? '1234567890-abc123.apps.googleusercontent.com' : '00000000-0000-0000-0000-000000000000';
  $('#mailRedirect').innerHTML = (g ? esc(t('mail.redirectGoogle')) : `${esc(t('mail.redirectMs'))} <code>${esc(msRedirect())}</code>`) + (a.clientIdHint ? `<br>${esc(t('mail.addHint'))}` : '');
  $('#mailStepList').innerHTML = [1, 2, 3, 4, 5].map(i =>
    `<li>${esc(t(`mail.${g ? 'g' : 'm'}.${i}`))}${MAIL_LINKS[prov][i - 1].map(([label, url]) => `<a href="${url}" target="_blank" rel="noopener noreferrer">${esc(label || t('mail.open'))} ↗</a>`).join('')}</li>`).join('');
  if (reset) $('#mailSteps').open = !a.clientIdHint;
  $('#mailGo').dataset.prov = prov;
  $('#mailGoText').textContent = t('mail.go.' + prov);
}
function openMail() {
  if (!S || !S.mail) return;
  const m = S.mail;
  const prov = m.accounts.length ? mailPrimary().provider : 'google';
  $$('input[name=mailProv]').forEach(r => { r.checked = r.value === prov; });
  $('#mailClientId').value = ''; $('#mailSecret').value = ''; $('#mailConsent').checked = false;
  renderMailAccts(); fillMailProvider(prov);
  const liveCo = S.workspace === 'company';
  $('#mailSig').hidden = !liveCo;
  if (liveCo) { $('#sigName').value = S.owner.name || ''; $('#sigCompany').value = S.owner.company || ''; }
  renderSigBoxes(true);
  if (!mdlg.open) mdlg.showModal();
  if (liveCo && (!S.owner.name || !S.owner.company)) $('#sigName').focus();
}
/** 从 Google / Microsoft 登录页回来：成功就提示，失败就在窗口里显示原因 */
function backFromMail() {
  openMail();
  if (!S.mail.lastError && S.mail.lastAdded) toast(t('mail.ok', { email: S.mail.lastAdded }));
  try { history.replaceState(null, '', location.pathname); } catch (e) { /* 地址栏不可写 */ }
}
$('#mailBtn').addEventListener('click', openMail);
$('#dataChip').addEventListener('click', openMail);
$$('input[name=mailProv]').forEach(r => r.addEventListener('change', () => fillMailProvider(mailProv())));
$('#mailCancel').addEventListener('click', () => mdlg.close());
$('#sigSave').addEventListener('click', async () => {
  const mailboxes = {};
  $$('#sigBoxes .sig-box').forEach(b => { mailboxes[b.dataset.email] = { name: b.querySelector('.sb-name').value.trim(), company: b.querySelector('.sb-company').value.trim() }; });
  try { await post('/api/profile', { name: $('#sigName').value.trim(), company: $('#sigCompany').value.trim(), mailboxes }); toast(t('mail.sigSaved')); }
  catch (err) { $('#mailErr').textContent = err.message; }
});
$('#mailAccts').addEventListener('click', async e => {
  const use = e.target.closest('[data-use]'), disc = e.target.closest('[data-disc]'), prim = e.target.closest('[data-primary]');
  const email = id => (S.mail.accounts.find(a => a.id === id) || {}).email || id;
  try {
    if (use) { await post('/api/mail/use', { source: use.dataset.use }); toast(t('mail.switched', { name: t(use.dataset.use === 'local' ? 'mail.sample' : 'mail.live') })); }
    else if (prim) { await post('/api/mail/primary', { id: prim.dataset.primary }); toast(t('mail.primarySet', { email: email(prim.dataset.primary) })); }
    else if (disc) { const who = email(disc.dataset.disc); await post('/api/mail/disconnect', { id: disc.dataset.disc }); toast(t('mail.removed', { name: who })); }
  } catch (err) { $('#mailErr').textContent = err.message; }
});
$('#mailForm').addEventListener('submit', async e => {
  e.preventDefault();
  const btn = $('#mailGo'), prov = mailProv();
  $('#mailErr').textContent = '';
  if (!$('#mailConsent').checked) { $('#mailErr').textContent = t('err.mailConsent'); $('#mailConsent').focus(); return; }
  btn.disabled = true; $('#mailGoText').textContent = t('mail.going');
  try {
    const r = await post('/api/mail/connect', { provider: prov, consent: true, clientId: $('#mailClientId').value.trim(), clientSecret: $('#mailSecret').value.trim(), tenant: $('#mailTenant').value.trim() });
    $('#mailSecret').value = '';
    location.href = r.authUrl;
  } catch (err) {
    $('#mailErr').textContent = err.message;
    btn.disabled = false; $('#mailGoText').textContent = t('mail.go.' + prov);
  }
});

/* ---------------- 语言：界面语言也是公司的工作语言（AI 汇报、验收标准、MEMORY.md 都跟着换） ---------------- */
function syncLanguage() {
  if (S && S.language !== I.lang) post('/api/language', { lang: I.lang }).catch(err => toast(err.message));
}
I.onChange(() => {
  if (!S) return;
  renderHeader(); renderOverview(); renderLog(true); renderView(true); countEssay();
  if (view === 'tutor') renderTutor();
  if (mdlg.open) { fillMailProvider(mailProv(), false); renderSigBoxes(); }
  syncLanguage();
});

/* ---------------- 实时连接 ---------------- */
function renderAll() { renderHeader(); renderOverview(); renderView(); }
function connect() {
  const es = new EventSource('/api/events');
  es.onopen = () => { connected = true; if (S) renderHeader(); };
  es.onmessage = ev => {
    const msg = JSON.parse(ev.data);
    if (msg.type === 'state') {
      const first = !S;
      S = msg.state; connected = true; renderAll();
      if (first) { syncLanguage(); if (location.hash === '#connect') openConn(); else if (location.hash === '#mail') backFromMail(); }
    } else if (msg.type === 'run' && S) { S.run = msg.run; S.running = msg.running; renderHeader(); renderOverview(); }
  };
  es.onerror = () => { connected = false; if (S) renderHeader(); };
}

/* ---------------- 连线 ---------------- */
const cv = $('#wires'), ctx = cv.getContext('2d');
const narrow = matchMedia('(max-width: 1180px)');
const hash = s => { let x = 7; for (const c of s) x = (x * 31 + c.codePointAt(0)) >>> 0; return x; };
function bez(a, b, k) {
  const dx = Math.max(24, (b.x - a.x) * .5), m = 1 - k;
  const p1 = { x: a.x + dx, y: a.y }, p2 = { x: b.x - dx, y: b.y };
  return { x: m * m * m * a.x + 3 * m * m * k * p1.x + 3 * m * k * k * p2.x + k * k * k * b.x, y: m * m * m * a.y + 3 * m * m * k * p1.y + 3 * m * k * k * p2.y + k * k * k * b.y };
}
function draw() {
  requestAnimationFrame(draw);
  if (!S || view !== 'overview' || narrow.matches) return;
  const mesh = $('#mesh'), r = mesh.getBoundingClientRect(), dpr = window.devicePixelRatio || 1;
  const W = mesh.clientWidth, H = mesh.clientHeight;
  if (cv.width !== Math.round(W * dpr) || cv.height !== Math.round(H * dpr)) { cv.width = Math.round(W * dpr); cv.height = Math.round(H * dpr); }
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0); ctx.clearRect(0, 0, W, H);
  const ox = r.left + mesh.clientLeft, oy = r.top + mesh.clientTop;
  const cs = getComputedStyle(document.documentElement), col = n => cs.getPropertyValue(n).trim();
  const R = el => el.getBoundingClientRect();
  const right = b => ({ x: b.right - ox, y: b.top + b.height / 2 - oy });
  const left = b => ({ x: b.left - ox, y: b.top + b.height / 2 - oy });
  const line = (a, b, c, w, al) => { ctx.globalAlpha = al; ctx.strokeStyle = c; ctx.lineWidth = w; const dx = Math.max(24, (b.x - a.x) * .5); ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.bezierCurveTo(a.x + dx, a.y, b.x - dx, b.y, b.x, b.y); ctx.stroke(); };
  const vline = (x, y1, y2, c) => { ctx.globalAlpha = .8; ctx.strokeStyle = c; ctx.lineWidth = 1.2; ctx.beginPath(); ctx.moveTo(x, y1); ctx.lineTo(x, y2); ctx.stroke(); };
  const base = col('--line-2'), okc = col('--ok'), runc = col('--run'), gold = col('--gold');
  const active = busy();
  const orch = R($('#orch')), chk = R($('#checkNode')), spl = R($('#splitNode'));
  $$('#inputs li').forEach(li => line(right(R(li)), left(orch), active ? gold : base, 1.2, active ? .7 : .55));
  const cx = orch.left + orch.width / 2 - ox;
  vline(cx, orch.bottom - oy, chk.top - oy, okc);
  vline(cx, chk.bottom - oy, spl.top - oy, runc);
  const sp = right(spl), now = performance.now();
  for (const b of S.bots) {
    const el = document.getElementById('bot-' + b.id); if (!el) continue;
    const isBusy = el.classList.contains('busy'), dc = col(`--d${botIndex(b.id) % 6 + 1}`);
    line(sp, left(R(el)), isBusy ? dc : base, isBusy ? 1.6 : 1, isBusy ? .85 : .45);
  }
  const ub = R($('#units'));
  for (const u of units()) {
    if (u.state !== 'running' && u.state !== 'checking') continue;
    const el = document.getElementById('u-' + u.id), be = document.getElementById('bot-' + u.bot); if (!el || !be) continue;
    const eb = R(el); if (eb.bottom < ub.top || eb.top > ub.bottom) continue;
    const a = right(R(be)), b = left(eb), dc = col(`--d${botIndex(u.bot) % 6 + 1}`);
    line(a, b, u.state === 'checking' ? okc : dc, 1.4, .8);
    if (!reduced) {
      const p = bez(a, b, ((now + hash(u.id) % 900) % 900) / 900);
      ctx.globalAlpha = 1; ctx.fillStyle = u.state === 'checking' ? okc : dc; ctx.beginPath(); ctx.arc(p.x, p.y, 2.4, 0, Math.PI * 2); ctx.fill();
    }
  }
  ctx.globalAlpha = 1;
}

/* ---------------- 启动 ---------------- */
I.init();
I.picker($('#langSel'));
countEssay();
show(location.hash.slice(1) || 'overview');
connect();
requestAnimationFrame(draw);
})();
