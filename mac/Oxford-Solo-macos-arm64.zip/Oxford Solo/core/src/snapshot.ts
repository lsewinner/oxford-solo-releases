import type { Deps } from './connectors/index.js';
import type { Snapshot } from './types.js';

export function addDays(iso: string, n: number): string {
  const d = new Date(iso + 'T00:00:00Z');
  d.setUTCDate(d.getUTCDate() + n);
  return d.toISOString().slice(0, 10);
}

export function daysBetween(a: string, b: string): number {
  return Math.round((Date.parse(b.slice(0, 10) + 'T00:00:00Z') - Date.parse(a.slice(0, 10) + 'T00:00:00Z')) / 864e5);
}

/** 总指挥开工前读的公司现状：收件箱、客户库、未来 7 天日程 */
export async function buildSnapshot(deps: Deps): Promise<Snapshot> {
  const [emails, events, timeZone] = await Promise.all([
    deps.mailbox.list({ limit: 30 }),
    deps.calendar.list(deps.today, addDays(deps.today, 7)),
    deps.calendar.timeZone().catch(() => undefined),
  ]);
  return { today: deps.today, owner: deps.owner, emails, contacts: deps.contacts.list(), events, ...(timeZone ? { timeZone } : {}) };
}

export function snapshotText(s: Snapshot): string {
  const unread = s.emails.filter((e) => e.unread).length;
  return [
    `今天是 ${s.today}。老板：${s.owner.name}，公司：${s.owner.company}（${s.owner.email}）。`,
    ...(s.owner.mailboxes && s.owner.mailboxes.length > 1
      ? [`老板连接了 ${s.owner.mailboxes.length} 个邮箱：${s.owner.mailboxes.map((m, i) => (i ? m : m + '（主邮箱）')).join('、')}。回复会自动从收到原邮件的邮箱发出。`]
      : []),
    '',
    `## 收件箱（${s.emails.length} 封，未读 ${unread} 封）`,
    ...s.emails.map(
      (e) =>
        `- ${e.id} · ${e.fromName} <${e.from}>${e.account && s.owner.mailboxes && s.owner.mailboxes.length > 1 ? ` → ${e.account}` : ''} · 「${e.subject}」 · ${e.date.slice(0, 16).replace('T', ' ')}` +
        `${e.unread ? ' · 未读' : ''}${e.labels.length ? ' · 标签：' + e.labels.join('、') : ''}`,
    ),
    '',
    '## 客户库',
    ...s.contacts.map(
      (c) =>
        `- ${c.id} · ${c.name}（${c.company}）<${c.email}> · ${c.stage} · 最近联系 ${c.lastContact}（${daysBetween(c.lastContact, s.today)} 天前）` +
        `${c.lastProposal ? ' · 上次方案：' + c.lastProposal : ''}`,
    ),
    '',
    `## 未来 7 天日程${
      !s.timeZone ? '' : s.timeZone.includes(';') ? `（各邮箱日历的时区：${s.timeZone}；每个日程的时间是它所在日历的当地时间）` : `（日历时区：${s.timeZone}，下面的时间都是这个时区的当地时间）`
    }`,
    ...(s.events.length
      ? s.events.map(
          (e) =>
            `- ${e.id} · ${e.start.replace('T', ' ')}–${e.end.slice(11)} · ${e.title}` +
            `${e.attendees.length ? ' · 参会：' + e.attendees.join('、') : ' · 个人日程'}`,
        )
      : ['- 没有日程']),
  ].join('\n');
}
