// 本机网页界面的服务器：提供公司状态、实时运行事件（SSE）和老板的操作接口。
// 只监听 127.0.0.1，只接受本机发来的 JSON 请求。
import fs from 'node:fs';
import http from 'node:http';
import type { AddressInfo } from 'node:net';
import path from 'node:path';
import {
  MAIL_PROVIDERS,
  REAL_ENDPOINTS,
  activeSource,
  authUrl,
  finishAuth,
  loadAccounts,
  newState,
  pkcePair,
  publicAccounts,
  redirectUri,
  liveAccounts,
  revokeAccount,
  storeAccount,
  updateAccounts,
  type Endpoints,
  type MailProvider,
  type OAuthApp,
} from './accounts.js';
import { AccountClient, AccountError, botsForPlan, licensingOn } from './account.js';
import { Approvals } from './approvals.js';
import { BOTS, BOT_MAP, DEPARTMENT, KIND_MINUTES } from './bots.js';
import { choiceLabel, makeBrain as pickBrain, resolveChoice, verifyConnection, type BrainChoice, type Provider } from './brain/pick.js';
import { setPrice, todayISO } from './config.js';
import { DEFAULT_HOME, clearConnection, keyHint, loadConnection, saveConnection, type ConnProvider } from './credentials.js';
import type { Brain } from './brain/types.js';
import { ROOT } from './config.js';
import { LocalCalendar, LocalMailbox, MultiMailbox, OutboxLog, makeDeps, type MailSource } from './connectors/index.js';
import { MAIL_SOURCES } from './connectors/types.js';
import type { LedgerRun } from './ledger.js';
import { CodedError, LANGS, isLang, msg, t } from './i18n.js';
import { Memory } from './memory.js';
import { narrate, type LogLine } from './narrate.js';
import { runInstruction, type RunEvent, type RunReport } from './orchestrator.js';
import { addDays } from './snapshot.js';
import { RISKS, type RedlineRisk, type Unit } from './types.js';
import { companyWorkspace, type Workspace } from './workspace.js';

export interface LiveRun {
  runId: string;
  instruction: string;
  mode: string;
  status: 'planning' | 'running' | 'waiting' | 'done' | 'error';
  startedAt: number;
  criteria: string[];
  units: Unit[];
  log: Array<LogLine & { t: number }>;
  spentUsd: number;
  budgetUsd: number;
  stoppedByBudget: boolean;
  error?: string;
}

export interface ServerOptions {
  ws: Workspace;
  /** 固定"今天"（测试、演示用）；不填就每次取这台电脑的当地日期 */
  today?: string;
  port?: number;
  host?: string;
  /** 测试时注入；默认按 API key 选：Claude → OpenAI → 离线模拟 */
  brain?: (mock: boolean) => Brain;
  /** 指定用哪个大脑；不填就自动检测 */
  provider?: Provider;
  /** 兼容旧写法：false 等于 provider: 'mock' */
  hasKey?: boolean;
  /** 保存模型连接和邮箱授权的目录，默认 ~/.oxford-solo（测试时换成临时目录） */
  home?: string;
  /** Google / Microsoft 接口地址；测试时换成本机的假服务 */
  endpoints?: Endpoints;
  /** 付费等级开关（不填就看 core/edition.json 和 SOLO_LICENSING）；测试时直接指定 */
  licensing?: boolean;
  /** Oxford Solo 账号客户端；测试时换成连假账号服务的 */
  account?: AccountClient;
}

/** 带错误代码的 HTTP 错误：界面按代码翻译成当前语言 */
class HttpError extends CodedError {
  constructor(
    readonly status: number,
    code: string,
    params: Record<string, string | number> = {},
  ) {
    super(code, params);
  }
}

const LOCAL_HOSTS = ['localhost', '127.0.0.1', '[::1]'];
const LOCAL_ORIGIN = /^http:\/\/(localhost|127\.0\.0\.1|\[::1\])(:\d+)?$/;

export function createSoloServer(o: ServerOptions): http.Server {
  const sampleWs = o.ws.ensure();
  let companyWs: Workspace | null = null;
  /** 现在这家公司：用示例数据时是示例公司，用真实邮箱时是老板自己的公司 */
  const W = (): Workspace => {
    if (activeSource(home) !== 'live') return sampleWs;
    companyWs ??= companyWorkspace(home).ensure();
    return companyWs;
  };
  const home = o.home ?? DEFAULT_HOME;
  const day = () => o.today ?? todayISO();
  const forced: Provider | null = o.provider ?? (o.hasKey === false ? 'mock' : null);
  /** 每次都重新读：老板在连接窗口里保存或断开后马上生效 */
  const choice = (): BrainChoice => (forced ? { provider: forced, model: '', source: forced === 'mock' ? 'none' : 'env' } : resolveChoice(process.env, home));
  const makeBrain = o.brain ?? ((mock: boolean) => pickBrain(mock ? 'mock' : choice(), { paceMs: [350, 900] }));
  const endpoints = o.endpoints ?? REAL_ENDPOINTS;
  const depsFor = (source?: MailSource) => makeDeps(W(), day(), { home, endpoints, source });
  const clients = new Set<http.ServerResponse>();
  // ---------- Oxford Solo 账号和付费等级（开关关着时什么都不限制） ----------
  const licensing = o.licensing ?? licensingOn();
  const acct = o.account ?? new AccountClient(home);
  let acctError: { code: string } | null = null;
  const refreshAccount = () =>
    acct
      .refresh()
      .then(() => (acctError = null))
      .catch((e) => (acctError = { code: e instanceof AccountError ? e.code : 'server' }))
      .finally(() => pushState());
  if (licensing) {
    void acct.load().then(() => refreshAccount());
    setInterval(() => void refreshAccount(), 6 * 3_600_000).unref();
  }
  /** 等级限制；开关关着时返回 null（不限制） */
  const limits = () => (licensing ? acct.state().limits : null);
  const planState = () => (licensing ? { licensing: true, ...acct.state(), error: acctError } : { licensing: false });
  let running = false;
  let run: LiveRun | null = loadLastRun();

  /** 服务器重启后，界面仍然能看到上一次运行的结果 */
  function loadLastRun(): LiveRun | null {
    const files = fs.readdirSync(W().path('runs')).filter((f) => f.endsWith('.json')).sort();
    const last = files.at(-1);
    if (!last) return null;
    const report = W().readJson<{ report: RunReport }>(`runs/${last}`).report;
    return {
      runId: report.runId,
      instruction: report.instruction,
      mode: report.mode,
      status: report.fatalError ? 'error' : 'done',
      startedAt: Date.now(),
      criteria: report.criteria,
      units: report.units,
      log: [{ t: 0, kind: 'dim', who: msg('log.who.last'), msg: msg('log.instruction', { text: report.instruction }) }, ...narrate({ type: 'done', report }).map((l) => ({ ...l, t: 0 }))],
      spentUsd: report.costUsd,
      budgetUsd: report.budgetUsd,
      stoppedByBudget: report.stoppedByBudget,
      error: report.fatalError ?? undefined,
    };
  }

  function pnl() {
    const book = W().readJson<{ runs: LedgerRun[] }>('ledger.json').runs;
    const actors = new Map<string, { id: string; name: string; kind: 'bot' | 'overhead'; usd: number; calls: number; passed: number; rejections: number; minutes: number }>();
    const row = (id: string) => {
      if (!actors.has(id)) actors.set(id, { id, name: BOT_MAP[id]?.name ?? id, kind: BOT_MAP[id] ? 'bot' : 'overhead', usd: 0, calls: 0, passed: 0, rejections: 0, minutes: 0 });
      return actors.get(id)!;
    };
    BOTS.forEach((b) => row(b.id));
    for (const r of book) {
      for (const [id, v] of Object.entries(r.byActor)) {
        row(id).usd += v.usd;
        row(id).calls += v.calls;
      }
    }
    for (const f of fs.readdirSync(W().path('runs')).filter((x) => x.endsWith('.json'))) {
      for (const u of W().readJson<{ report: RunReport }>(`runs/${f}`).report.units) {
        const a = row(u.bot);
        if (u.state === 'done' || u.state === 'awaiting') {
          a.passed++;
          a.minutes += KIND_MINUTES[u.kind] ?? 10;
        }
        a.rejections += u.feedback.length;
      }
    }
    return {
      runs: book.length,
      mockRuns: book.filter((r) => r.mode === 'mock').length,
      totalUsd: book.reduce((s, r) => s + r.totalUsd, 0),
      actors: [...actors.values()],
    };
  }

  /** 给界面看的连接信息：永远不包含 key 本身，只给提示 */
  function connectionState() {
    const c = choice();
    const saved = loadConnection(home);
    return {
      mode: c.provider,
      model: choiceLabel(c),
      hasKey: c.provider !== 'mock',
      connection: {
        provider: c.provider,
        model: c.model,
        source: c.source,
        keyHint: saved ? keyHint(saved.apiKey) : c.source === 'env' ? keyHint(String(process.env.OPENAI_API_KEY ?? process.env.ANTHROPIC_API_KEY ?? '')) : '',
        savedProvider: saved?.provider ?? null,
        baseURL: saved?.baseURL ?? '',
        priceInput: saved?.priceInput ?? null,
        priceOutput: saved?.priceOutput ?? null,
      },
    };
  }

  // ---------- 邮箱 ----------
  type ErrInfo = { code?: string; params?: Record<string, string | number>; msg: string };
  const errInfo = (e: unknown): ErrInfo =>
    e instanceof CodedError ? { code: e.code, params: e.params, msg: (e as Error).message } : { msg: (e as Error)?.message ?? String(e) };

  /** 真实邮箱要联网，数量缓存两分钟，不能每次刷新界面都去问 */
  let mailStatus: {
    source: MailSource;
    emails: number | null;
    unread: number | null;
    events: number | null;
    at: number;
    error?: ErrInfo;
    /** 某几个账号读取失败（其余账号照常） */
    accountErrors?: Array<{ id: string; email: string } & ErrInfo>;
  } | null = null;
  let mailBusy = false;
  /** 最近一次授权失败的原因，界面打开邮箱窗口时显示 */
  let lastMailError: ErrInfo | null = null;
  /** 最近一次授权成功连上的邮箱，界面回来时提示 */
  let lastAdded = '';
  const pendingAuth = new Map<string, { provider: MailProvider; app: OAuthApp; verifier: string; redirectUri: string; returnTo: string; at: number }>();

  function refreshMail(): void {
    const source = activeSource(home);
    if (mailBusy || source === 'local') return;
    mailBusy = true;
    (async () => {
      const deps = depsFor(source);
      const [emails, events] = await Promise.all([deps.mailbox.list({ limit: 30 }), deps.calendar.list(day(), addDays(day(), 7))]);
      const failed = deps.mailbox instanceof MultiMailbox ? deps.mailbox.errors : [];
      mailStatus = {
        source,
        emails: emails.length,
        unread: emails.filter((e) => e.unread).length,
        events: events.length,
        at: Date.now(),
        accountErrors: failed.map((f) => ({ id: f.id, email: f.email, ...errInfo(f.error) })),
      };
    })()
      .catch((e) => {
        mailStatus = { source, emails: null, unread: null, events: null, at: Date.now(), error: errInfo(e) };
      })
      .finally(() => {
        mailBusy = false;
        pushState();
      });
  }

  function mailCounts() {
    const source = activeSource(home);
    if (source === 'local') {
      const emails = new LocalMailbox(W(), new OutboxLog(W())).listSync();
      const events = new LocalCalendar(W()).listSync(day(), addDays(day(), 7));
      return { source, emails: emails.length, unread: emails.filter((e) => e.unread).length, events: events.length, error: null, accountErrors: [], loading: false };
    }
    if (!mailStatus || mailStatus.source !== source || Date.now() - mailStatus.at > 120_000) refreshMail();
    const m = mailStatus?.source === source ? mailStatus : null;
    return { source, emails: m?.emails ?? null, unread: m?.unread ?? null, events: m?.events ?? null, error: m?.error ?? null, accountErrors: m?.accountErrors ?? [], loading: !m };
  }

  function state() {
    const memory = new Memory(W());
    const all = new Approvals(W()).all();
    const mc = mailCounts();
    const outbox = new OutboxLog(W());
    let owner = W().readJson<{ name: string; company: string; email: string }>('profile.json');
    try {
      owner = depsFor(mc.source).owner;
    } catch {
      /* 账号刚被断开，用 profile 里的 */
    }
    if (run && !running && run.status !== 'error') {
      const id = run.runId;
      run.status = all.some((a) => a.status === 'pending' && a.runId === id) ? 'waiting' : 'done';
    }
    return {
      ...connectionState(),
      language: W().language(),
      workspace: W().kind,
      languages: LANGS,
      today: day(),
      owner,
      department: DEPARTMENT,
      bots: BOTS,
      counts: {
        emails: mc.emails,
        unread: mc.unread,
        contacts: W().readJson<unknown[]>('contacts.json').length,
        events: mc.events,
        sent: outbox.sent().length,
        drafts: outbox.drafts().length,
      },
      mail: { ...publicAccounts(home), loading: mc.loading, error: mc.error, accountErrors: mc.accountErrors, lastError: lastMailError, lastAdded },
      memory: { ...memory.data, raw: W().readText('MEMORY.md') },
      approvals: {
        pending: all.filter((a) => a.status === 'pending'),
        history: all
          .filter((a) => a.status !== 'pending')
          .sort((a, b) => (b.decidedAt ?? '').localeCompare(a.decidedAt ?? ''))
          .slice(0, 15),
      },
      pnl: pnl(),
      plan: planState(),
      running,
      run,
    };
  }

  const send = (res: http.ServerResponse, msg: unknown) => res.write(`data: ${JSON.stringify(msg)}\n\n`);
  const broadcast = (msg: unknown) => clients.forEach((c) => send(c, msg));
  const pushState = () => broadcast({ type: 'state', state: state() });
  let runTimer: NodeJS.Timeout | null = null;
  const pushRun = () => {
    if (runTimer) return;
    runTimer = setTimeout(() => {
      runTimer = null;
      broadcast({ type: 'run', run, running });
    }, 120);
  };

  function onEvent(r: LiveRun, e: RunEvent): void {
    const t = (Date.now() - r.startedAt) / 1000;
    for (const l of narrate(e)) r.log.push({ ...l, t });
    if (r.log.length > 400) r.log.splice(0, r.log.length - 400);
    if (e.type === 'start') {
      r.runId = e.runId;
      r.budgetUsd = e.budgetUsd;
    } else if (e.type === 'criteria') r.criteria = e.criteria;
    else if (e.type === 'split') {
      r.units = e.units;
      r.status = 'running';
    } else if (e.type === 'unit') r.spentUsd = e.spentUsd;
    else if (e.type === 'budget') r.stoppedByBudget = true;
    else if (e.type === 'done') {
      r.spentUsd = e.report.costUsd;
      if (e.report.fatalError) {
        r.status = 'error';
        r.error = e.report.fatalError;
      }
    }
    if (e.type === 'approval' || e.type === 'rule') pushState();
    else pushRun();
  }

  function startRun(instruction: string, mock: boolean): void {
    if (running) throw new HttpError(409, 'busy');
    const live = activeSource(home) === 'live';
    if (live && mock) throw new HttpError(409, 'mockLive');
    const brain = makeBrain(mock);
    if (live && brain.mode === 'mock') throw new HttpError(409, 'mockLive');
    if (live) {
      const pr = W().readJson<{ name?: string; company?: string }>('profile.json');
      if (!pr.name?.trim() || !pr.company?.trim()) throw new HttpError(400, 'profileMissing');
    }
    const L = limits();
    if (live && L) {
      if (!L.liveRuns) throw new HttpError(402, 'planRequired');
      if (liveAccounts(loadAccounts(home)).length > L.mailboxes) throw new HttpError(402, 'planMailboxOver', { n: L.mailboxes });
    }
    const current: LiveRun = {
      runId: '',
      instruction,
      mode: brain.mode,
      status: 'planning',
      startedAt: Date.now(),
      criteria: [],
      units: [],
      log: [],
      spentUsd: 0,
      budgetUsd: new Memory(W()).data.budgetUsd,
      stoppedByBudget: false,
    };
    run = current;
    running = true;
    pushState();
    const bots = live && L ? botsForPlan(L) : undefined;
    runInstruction({ instruction, brain, ws: W(), today: day(), lang: W().language(), home, endpoints, bots, onEvent: (e) => onEvent(current, e) })
      .catch((err: Error) => {
        current.status = 'error';
        current.error = err.message;
        current.log.push({ t: (Date.now() - current.startedAt) / 1000, kind: 'bad', who: msg('log.who.error'), msg: msg('log.error', { msg: err.message }) });
      })
      .finally(() => {
        running = false;
        if (mailStatus) mailStatus.at = 0;
        pushState();
      });
  }

  function guard(req: http.IncomingMessage): void {
    const host = (req.headers.host ?? '').replace(/:\d+$/, '');
    if (!LOCAL_HOSTS.includes(host)) throw new HttpError(403, 'localOnly');
    if (req.method === 'POST') {
      if (!String(req.headers['content-type'] ?? '').startsWith('application/json')) throw new HttpError(415, 'jsonOnly');
      const origin = req.headers.origin;
      if (origin && !LOCAL_ORIGIN.test(origin)) throw new HttpError(403, 'crossSite');
    }
  }

  async function readJson(req: http.IncomingMessage): Promise<Record<string, unknown>> {
    let size = 0;
    const chunks: Buffer[] = [];
    for await (const chunk of req) {
      size += (chunk as Buffer).length;
      if (size > 1_000_000) throw new HttpError(413, 'tooLarge');
      chunks.push(chunk as Buffer);
    }
    if (!chunks.length) return {};
    try {
      const v = JSON.parse(Buffer.concat(chunks).toString('utf8'));
      if (v && typeof v === 'object' && !Array.isArray(v)) return v as Record<string, unknown>;
    } catch {
      /* 下面统一报错 */
    }
    throw new HttpError(400, 'badInput');
  }

  const json = (res: http.ServerResponse, status: number, body: unknown) => {
    res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
    res.end(JSON.stringify(body));
  };
  const text = (v: unknown) => (typeof v === 'string' ? v.trim() : '');

  const srv = http.createServer(async (req, res) => {
    try {
      guard(req);
      const url = new URL(req.url ?? '/', 'http://localhost');
      const p = url.pathname;

      if (req.method === 'GET') {
        if (p === '/' || p === '/index.html') {
          res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' });
          res.end(fs.readFileSync(path.join(ROOT, 'web', 'index.html')));
          return;
        }
        if (p === '/api/state') return json(res, 200, state());
        let cb: RegExpMatchArray | null;
        if ((cb = p.match(/^\/oauth\/(google|microsoft)\/callback$/))) {
          // Google / Microsoft 登录页同意后跳回这里，带着授权码；换成令牌后回到界面
          const st = url.searchParams.get('state') ?? '';
          const pend = pendingAuth.get(st);
          const back = (pend?.returnTo ?? '/') + '#mail';
          const go = () => {
            res.writeHead(302, { Location: back, 'Cache-Control': 'no-store' });
            res.end();
          };
          if (!pend || pend.provider !== cb[1]) {
            lastMailError = { code: 'mailStateInvalid', msg: 'state' };
            pushState();
            return go();
          }
          pendingAuth.delete(st);
          const err = url.searchParams.get('error');
          const code = url.searchParams.get('code');
          if (err || !code) {
            const why = [err, url.searchParams.get('error_description')].filter(Boolean).join(': ') || 'no code';
            lastMailError = { code: err === 'access_denied' ? 'mailDenied' : 'mailAuthFailed', params: { msg: why }, msg: why };
            pushState();
            return go();
          }
          try {
            const account = await finishAuth(pend.provider, pend.app, { code, verifier: pend.verifier, redirectUri: pend.redirectUri, endpoints });
            const L = limits();
            const d = loadAccounts(home);
            const known = Object.values(d.accounts).some((x) => x.provider === account.provider && x.email.toLowerCase() === account.email.toLowerCase());
            if (L && !known && liveAccounts(d).length >= L.mailboxes) {
              // 超出等级允许的邮箱数：不保存，并把刚拿到的令牌作废（重新授权已连接的邮箱不受影响）
              await revokeAccount({ ...account, id: 'over-limit' }, endpoints).catch(() => undefined);
              lastMailError = { code: L.mailboxes ? 'planMailboxLimit' : 'planRequired', params: { n: L.mailboxes }, msg: 'plan' };
            } else {
              storeAccount(home, account, pend.app);
              if (!running) run = loadLastRun();
              lastMailError = null;
              lastAdded = account.email;
              mailStatus = null;
            }
          } catch (e) {
            lastMailError = errInfo(e);
          }
          pushState();
          return go();
        }
        if (p === '/api/events') {
          res.writeHead(200, { 'Content-Type': 'text/event-stream; charset=utf-8', 'Cache-Control': 'no-store', Connection: 'keep-alive' });
          clients.add(res);
          send(res, { type: 'state', state: state() });
          const beat = setInterval(() => res.write(': keep-alive\n\n'), 20_000);
          req.on('close', () => {
            clearInterval(beat);
            clients.delete(res);
          });
          return;
        }
      }

      if (req.method === 'POST') {
        const body = await readJson(req);
        let m: RegExpMatchArray | null;
        if (p === '/api/run') {
          startRun(text(body.instruction) || t(W().language(), 'cmd.default'), body.mock === true);
          return json(res, 202, { ok: true });
        }
        if ((m = p.match(/^\/api\/approvals\/([A-Za-z0-9]+)\/approve$/))) {
          const a = await new Approvals(W()).approve(m[1], (source) => depsFor(source), { body: text(body.body) ? String(body.body) : undefined });
          if (mailStatus) mailStatus.at = 0;
          pushState();
          return json(res, 200, a);
        }
        if ((m = p.match(/^\/api\/approvals\/([A-Za-z0-9]+)\/reject$/))) {
          const a = new Approvals(W()).reject(m[1], { rule: text(body.rule) || undefined, memory: new Memory(W()), lang: W().language() });
          pushState();
          return json(res, 200, a);
        }
        if (p === '/api/redline') {
          const risk = body.risk as RedlineRisk;
          if (!RISKS.includes(risk) || typeof body.on !== 'boolean') throw new HttpError(400, 'badInput');
          new Memory(W()).setRedline(risk, body.on);
          pushState();
          return json(res, 200, { ok: true });
        }
        if (p === '/api/budget') {
          const usd = Number(body.usd);
          if (!(usd > 0 && usd <= 1000)) throw new HttpError(400, 'budget');
          new Memory(W()).setBudget(usd);
          pushState();
          return json(res, 200, { ok: true });
        }
        if (p === '/api/rules') {
          const rule = text(body.text);
          if (!rule) throw new HttpError(400, 'emptyRule');
          const added = new Memory(W()).addRule(rule, t(W().language(), 'src.ui'));
          pushState();
          return json(res, 200, { added });
        }
        if (p === '/api/rules/toggle') {
          if (typeof body.on !== 'boolean' || !new Memory(W()).toggleRule(text(body.text), body.on)) throw new HttpError(400, 'ruleNotFound');
          pushState();
          return json(res, 200, { ok: true });
        }
        if (p === '/api/language') {
          if (!isLang(body.lang)) throw new HttpError(400, 'badInput');
          W().setLanguage(body.lang);
          new Memory(W()).setLanguage(body.lang);
          pushState();
          return json(res, 200, { ok: true });
        }
        if (p === '/api/connect') {
          if (running) throw new HttpError(409, 'busy');
          const provider = body.provider as ConnProvider;
          if (provider !== 'openai' && provider !== 'claude') throw new HttpError(400, 'badInput');
          const model = text(body.model);
          if (!model) throw new HttpError(400, 'badInput');
          const saved = loadConnection(home);
          const apiKey = text(body.apiKey) || (saved?.provider === provider ? saved.apiKey : '');
          if (!apiKey) throw new HttpError(400, 'keyMissing');
          const baseURL = provider === 'openai' ? text(body.baseURL) || undefined : undefined;
          const price = (v: unknown) => (typeof v === 'number' && v > 0 && v < 10_000 ? v : undefined);
          const priceInput = price(body.priceInput), priceOutput = price(body.priceOutput);
          await verifyConnection({ provider, apiKey, model, baseURL });
          saveConnection({ provider, apiKey, model, baseURL, priceInput, priceOutput, savedAt: new Date().toISOString() }, home);
          if (priceInput && priceOutput) setPrice(model, priceInput, priceOutput);
          pushState();
          return json(res, 200, { ok: true, model: choiceLabel(choice()) });
        }
        if (p === '/api/disconnect') {
          if (running) throw new HttpError(409, 'busy');
          clearConnection(home);
          pushState();
          return json(res, 200, { ok: true });
        }
        if (p === '/api/mail/connect') {
          // 第一步：记下 Client ID（Google 还有 secret），生成授权链接，界面跳过去让老板自己登录、同意
          if (running) throw new HttpError(409, 'busy');
          const provider = body.provider as MailProvider;
          if (!MAIL_PROVIDERS.includes(provider)) throw new HttpError(400, 'badInput');
          // 老板要先在界面上勾选：知道邮件内容会发给他选的 AI 服务商（Google 审核要求产品内告知并取得同意）
          if (body.consent !== true) throw new HttpError(400, 'mailConsent');
          if (limits()?.mailboxes === 0) throw new HttpError(402, 'planRequired');
          const saved = loadAccounts(home).apps[provider];
          const clientId = text(body.clientId) || saved?.clientId || '';
          if (!clientId) throw new HttpError(400, 'mailClientIdMissing');
          if (provider === 'google' && !/^[\w-]+\.apps\.googleusercontent\.com$/.test(clientId)) throw new HttpError(400, 'mailClientIdFormat', { provider: 'Google' });
          if (provider === 'microsoft' && !/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(clientId))
            throw new HttpError(400, 'mailClientIdFormat', { provider: 'Microsoft' });
          const same = saved?.clientId === clientId;
          const app: OAuthApp = { clientId };
          if (provider === 'google') {
            app.clientSecret = text(body.clientSecret) || (same ? saved?.clientSecret : '') || '';
            if (!app.clientSecret) throw new HttpError(400, 'mailSecretMissing');
          } else {
            app.tenant = text(body.tenant) || (same ? saved?.tenant : '') || 'common';
          }
          const { verifier, challenge } = pkcePair();
          const st = newState();
          const ru = redirectUri(provider, (srv.address() as AddressInfo).port);
          for (const [k, v] of pendingAuth) if (Date.now() - v.at > 15 * 60_000) pendingAuth.delete(k);
          pendingAuth.set(st, { provider, app, verifier, redirectUri: ru, returnTo: `http://${req.headers.host}/`, at: Date.now() });
          lastMailError = null;
          lastAdded = '';
          return json(res, 200, { authUrl: authUrl(provider, app, { redirectUri: ru, state: st, challenge, endpoints }), redirectUri: ru });
        }
        if (p === '/api/mail/use') {
          if (running) throw new HttpError(409, 'busy');
          const source = body.source as MailSource;
          if (!MAIL_SOURCES.includes(source)) throw new HttpError(400, 'badInput');
          if (source === 'live' && !Object.keys(loadAccounts(home).accounts).length) throw new HttpError(400, 'mailNotConnected', { provider: 'Google / Microsoft' });
          updateAccounts(home, (d) => (d.active = source));
          mailStatus = null;
          run = loadLastRun();
          pushState();
          return json(res, 200, { ok: true });
        }
        if (p === '/api/mail/disconnect') {
          // 删除本机令牌（Google 的顺手作废）；Client ID 留着，下次一键重连
          if (running) throw new HttpError(409, 'busy');
          const id = text(body.id);
          const account = loadAccounts(home).accounts[id];
          if (!account) throw new HttpError(400, 'mailNotConnected', { provider: id || '?' });
          await revokeAccount(account, endpoints);
          updateAccounts(home, (d) => {
            delete d.accounts[id];
            const left = liveAccounts(d);
            if (d.primary === id) d.primary = left[0]?.id;
            if (!left.length) d.active = 'local';
            if (body.forget === true && !left.some((a) => a.provider === account.provider)) delete d.apps[account.provider];
          });
          mailStatus = null;
          if (!running) run = loadLastRun();
          pushState();
          return json(res, 200, { ok: true });
        }
        if (p === '/api/profile') {
          // 真实公司的署名：老板的名字和公司名（bot 发信时用）
          const name = text(body.name).slice(0, 80);
          const company = text(body.company).slice(0, 120);
          if (!name || !company) throw new HttpError(400, 'profileMissing');
          const pr = W().readJson<{ signatures?: Record<string, { name?: string; company?: string }> }>('profile.json');
          // 每个邮箱的署名（不同邮箱属于不同公司时用）：只收已连接的邮箱，空着的就用默认署名
          const signatures = { ...(pr.signatures ?? {}) };
          if (body.mailboxes && typeof body.mailboxes === 'object') {
            const connected = new Set(liveAccounts(loadAccounts(home)).map((a) => a.email.toLowerCase()));
            for (const [k, v] of Object.entries(body.mailboxes as Record<string, unknown>)) {
              const email = k.trim().toLowerCase();
              if (!connected.has(email)) continue;
              const o = (v && typeof v === 'object' ? v : {}) as Record<string, unknown>;
              const sn = text(o.name).slice(0, 80);
              const sc = text(o.company).slice(0, 120);
              if (sn || sc) signatures[email] = { ...(sn ? { name: sn } : {}), ...(sc ? { company: sc } : {}) };
              else delete signatures[email];
            }
          }
          W().writeJson('profile.json', { ...pr, name, company, signatures });
          pushState();
          return json(res, 200, { ok: true });
        }
        if (p === '/api/mail/primary') {
          if (running) throw new HttpError(409, 'busy');
          const id = text(body.id);
          if (!loadAccounts(home).accounts[id]) throw new HttpError(400, 'mailNotConnected', { provider: id || '?' });
          updateAccounts(home, (d) => (d.primary = id));
          pushState();
          return json(res, 200, { ok: true });
        }
        if (p.startsWith('/api/account/')) {
          // Oxford Solo 账号：登录、刷新等级、升级付款。账号服务的错误代码翻译成 err.acct.<代码>
          if (!licensing) throw new HttpError(404, 'notFound', { id: p });
          try {
            if (p === '/api/account/start') {
              await acct.start(text(body.email), W().language());
              return json(res, 200, { ok: true });
            }
            if (p === '/api/account/verify') await acct.verify(text(body.email), text(body.code));
            else if (p === '/api/account/refresh') await acct.refresh();
            else if (p === '/api/account/logout') await acct.logout();
            else if (p === '/api/account/checkout') return json(res, 200, await acct.checkout(text(body.plan), text(body.interval)));
            else if (p === '/api/account/portal') return json(res, 200, await acct.portal());
            else throw new HttpError(404, 'notFound', { id: p });
            acctError = null;
            pushState();
            return json(res, 200, { ok: true, plan: planState() });
          } catch (e) {
            if (e instanceof AccountError) throw new HttpError(e.status === 401 ? 401 : e.status >= 500 ? 502 : 400, 'acct.' + e.code);
            throw e;
          }
        }
        if (p === '/api/reset') {
          if (running) throw new HttpError(409, 'resetBusy');
          if (activeSource(home) === 'live') throw new HttpError(409, 'resetLive');
          sampleWs.reset();
          run = null;
          pushState();
          return json(res, 200, { ok: true });
        }
      }
      throw new HttpError(404, 'notFound', { id: p });
    } catch (e) {
      const err = e as Error;
      if (res.headersSent) return res.end();
      const status = e instanceof HttpError ? e.status : 400;
      json(res, status, e instanceof CodedError ? { error: err.message, code: e.code, params: e.params } : { error: err.message });
    }
  });
  return srv;
}

export async function startServer(o: ServerOptions): Promise<{ server: http.Server; url: string; mode: Provider; model: string }> {
  const server = createSoloServer(o);
  const host = o.host ?? '127.0.0.1';
  await new Promise<void>((resolve, reject) => {
    server.once('error', reject);
    server.listen(o.port ?? 0, host, () => resolve());
  });
  const addr = server.address();
  const port = typeof addr === 'object' && addr ? addr.port : o.port;
  const forced: Provider | null = o.provider ?? (o.hasKey === false ? 'mock' : null);
  const c: BrainChoice = forced ? { provider: forced, model: '', source: 'env' } : resolveChoice(process.env, o.home ?? DEFAULT_HOME);
  return { server, url: `http://localhost:${port}`, mode: c.provider, model: choiceLabel(c) };
}
