import type { BotDef } from './types.js';

/** 第一版上岗的 3 个 bot（独立咨询顾问模板的客户沟通部门） */
export const BOTS: BotDef[] = [
  {
    id: 'inbox',
    name: '收件箱分拣',
    code: 'IT',
    role: '处理收件箱里的一封邮件：读完后打分类标签；需要回复的写好回复并提交发送；广告、系统通知归档。',
    kinds: ['inbox.sort'],
    tools: ['mail_read', 'mail_search', 'mail_label', 'mail_archive', 'mail_draft', 'mail_send', 'contacts_find', 'desk_ask'],
  },
  {
    id: 'follow',
    name: '客户跟进',
    code: 'FU',
    role: '跟进一位方案已发出、超过 7 天没有联系的客户：查清上次发了什么方案，写一封简短的跟进邮件并提交发送。',
    kinds: ['followup.send'],
    tools: ['contacts_find', 'mail_search', 'mail_list', 'mail_read', 'mail_draft', 'mail_send', 'desk_ask'],
  },
  {
    id: 'meet',
    name: '会议准备',
    code: 'MP',
    role:
      '为一场有外部客户参加的会议写一页简报笔记：会议目的、对方是谁、最近往来、要带的材料、要问的问题。' +
      '缺少的细节（时区、会议链接、对方的准备情况）写进简报的“待确认”里就好，不要为此给客户写信；只有日历和往来邮件互相矛盾、或会议明显需要改期时，才写邮件提交发送（会先进决策台）。' +
      '也负责订新会议（单元类型 cal.book）：客户来信或老板指令要求约时间时，先查日历确认那个时段空闲，再用 calendar_book 订（有外部参会人时会先进决策台）；邀请会自动发给参会人，不用另写确认邮件。时间不明确或有冲突时用 desk_ask 请老板定。',
    kinds: ['notes.prep', 'cal.book'],
    tools: ['calendar_list', 'contacts_find', 'mail_search', 'mail_list', 'mail_read', 'notes_write', 'mail_draft', 'mail_send', 'calendar_book', 'desk_ask'],
  },
];

export const BOT_MAP: Record<string, BotDef> = Object.fromEntries(BOTS.map((b) => [b.id, b]));

/** 一个人亲自做这类单元大约要花的分钟数，用来估算"节省工时"。是估计值，不是测量值 */
export const KIND_MINUTES: Record<string, number> = {
  'inbox.sort': 6,
  'followup.send': 15,
  'notes.prep': 30,
  'cal.book': 10,
};

/** 第一版所有 bot 都在"客户沟通"部门（文案键 dept.comm） */
export const DEPARTMENT = 'comm';
