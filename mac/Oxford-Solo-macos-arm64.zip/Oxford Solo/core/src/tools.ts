// bot 能用的工具，以及红线拦截。
// 红线由代码强制执行，不靠模型自觉：碰到红线的调用不会执行，而是生成一条审批，等老板在决策台拍板。
import { z } from 'zod';
import type { Deps } from './connectors/index.js';
import { fmt, msg, type Lang, type Msg } from './i18n.js';
import type { Memory } from './memory.js';
import type { ActionRecord, BotDef, Risk, Unit } from './types.js';

export interface ToolDef {
  name: string;
  description: string;
  schema: z.ZodObject<z.ZodRawShape>;
  /** 固定的红线类别，或根据输入判断（例如有外部参会人的会议邀请才算对外发送） */
  risk?: Risk | ((input: any) => Risk | null);
  /** 给老板看的一句话说明 */
  summarize?: (input: any) => Msg;
  run: (input: any, deps: Deps) => string | Promise<string>;
}

const json = (v: unknown) => JSON.stringify(v, null, 1);
/** mail_draft 的返回里取出草稿编号（d3），打回时靠它删掉半成品 */
const DRAFT_SAVED = /草稿已保存（(d\d+)）/;

const MailOut = z.object({
  to: z.string().describe('收件人邮箱'),
  subject: z.string().describe('邮件标题；回复时用 "Re: 原标题"'),
  body: z.string().describe('完整正文，包含称呼和署名'),
  replyTo: z.string().nullable().describe('回复的原邮件 ID，例如 e1 或 g2-m14；新邮件填 null'),
  from: z
    .string()
    .nullable()
    .optional()
    .describe('发件邮箱：回复时不用填，会自动从收到原邮件的那个邮箱发出；写新邮件时可填老板的某个邮箱，不填就用主邮箱'),
});

const LABELS = ['needs-reply', 'fyi', 'newsletter', 'finance', 'client', 'event', 'spam'] as const;

export const TOOLS: ToolDef[] = [
  {
    name: 'mail_list',
    description: '列出收件箱里的邮件（不含已归档）。返回 ID、发件人、标题、日期、标签、是否未读。',
    schema: z.object({ unreadOnly: z.boolean().describe('只看未读') }),
    run: async (i, d) =>
      json(
        (await d.mailbox.list({ unreadOnly: i.unreadOnly })).map((e) => ({
          id: e.id,
          from: e.from,
          fromName: e.fromName,
          ...(e.account ? { account: e.account } : {}),
          subject: e.subject,
          date: e.date,
          labels: e.labels,
          unread: e.unread,
        })),
      ),
  },
  {
    name: 'mail_read',
    description: '读一封邮件的全文，并标记为已读。',
    schema: z.object({ id: z.string().describe('邮件 ID，例如 e1 或 m12') }),
    run: async (i, d) => json(await d.mailbox.read(i.id)),
  },
  {
    name: 'mail_search',
    description:
      '在全部邮件（含已发送、已归档）里搜索往来记录、方案、报价、合同等。可以用对方邮箱、公司名或关键词，多个词用空格隔开。返回 ID、发件人、标题、日期和摘要；要看全文再用 mail_read。',
    schema: z.object({ query: z.string().describe('搜索词，例如 "wangmin@beichen.example" 或 "北辰 报价"') }),
    run: async (i, d) => {
      const r = await d.mailbox.search(i.query, 10);
      return r.length
        ? json(r.map((e) => ({ id: e.id, from: e.from, fromName: e.fromName, to: e.to, ...(e.account ? { account: e.account } : {}), subject: e.subject, date: e.date, labels: e.labels, snippet: e.body.slice(0, 200) })))
        : `没有找到和「${i.query}」相关的邮件`;
    },
  },
  {
    name: 'mail_label',
    description: `给邮件打分类标签。可选：${LABELS.join('、')}。`,
    schema: z.object({ id: z.string(), label: z.enum(LABELS) }),
    run: async (i, d) => {
      await d.mailbox.label(i.id, i.label);
      return `已给 ${i.id} 打上标签 ${i.label}`;
    },
  },
  {
    name: 'mail_archive',
    description: '把邮件归档（移出收件箱，可恢复）。用于广告、通知、无需处理的邮件。',
    schema: z.object({ id: z.string() }),
    run: async (i, d) => {
      await d.mailbox.archive(i.id);
      return `已归档 ${i.id}`;
    },
  },
  {
    name: 'mail_draft',
    description: '保存一封邮件草稿，不会发出。',
    schema: MailOut,
    run: async (i, d) => `草稿已保存（${(await d.mailbox.saveDraft(i)).id}）`, // 格式和下面的 DRAFT_SAVED 对应
  },
  {
    name: 'mail_send',
    description: '发出一封邮件。对外发送受红线保护：会先进入老板的决策台，批准后才真正发出。',
    schema: MailOut,
    risk: 'external',
    summarize: (i) => msg('sum.mail', { to: i.to, subject: i.subject }),
    run: async (i, d) => {
      const m = await d.mailbox.send(i);
      d.contacts.touch(i.to, d.today);
      return `已发送（${m.id}）`;
    },
  },
  {
    name: 'desk_ask',
    description:
      '把需要老板拍板的事提交到决策台（不发任何邮件）。用于你不能替老板决定的事：付款或续费、账号与安全、要不要回复或接受、方案取舍、无法核实的信息。' +
      '写清楚问题、你核实到的情况和依据、你的建议。不要给老板自己发邮件来请示，用这个工具。',
    schema: z.object({
      question: z.string().describe('一句话：要老板决定什么'),
      context: z.string().describe('发生了什么、你核实了什么、依据是哪封邮件或哪个日程'),
      recommendation: z.string().describe('你的建议，以及老板同意后接下来会怎么做'),
      ref: z.string().nullable().describe('相关的邮件或日程 ID；没有填 null'),
    }),
    risk: 'decide',
    summarize: (i) => msg('sum.ask', { question: i.question }),
    run: async () => '老板已拍板：同意建议',
  },
  {
    name: 'contacts_list',
    description: '列出客户库里的联系人，可按阶段筛选（线索、方案已发、客户）。',
    schema: z.object({ stage: z.string().nullable().describe('阶段；不筛选填 null') }),
    run: (i, d) => json(d.contacts.list().filter((c) => !i.stage || c.stage === i.stage)),
  },
  {
    name: 'contacts_find',
    description: '按姓名、公司、邮箱或客户 ID 查找联系人。',
    schema: z.object({ query: z.string() }),
    run: (i, d) => {
      const r = d.contacts.find(i.query);
      return r.length ? json(r) : `没有找到「${i.query}」`;
    },
  },
  {
    name: 'calendar_list',
    description: '列出某个日期范围内的日程（日期格式 YYYY-MM-DD，含首尾）。返回 timeZone（日历所在时区）和 events；所有时间都是这个时区的当地时间。',
    schema: z.object({ from: z.string(), to: z.string() }),
    run: async (i, d) => json({ timeZone: await d.calendar.timeZone().catch(() => null), events: await d.calendar.list(i.from, i.to) }),
  },
  {
    name: 'calendar_book',
    description:
      '在日历上订一个时间段（时间格式 YYYY-MM-DDTHH:mm，按日历时区的当地时间，时区见 calendar_list 返回的 timeZone）。' +
      '对方说的是别的时区时，可以直接写带偏移的时间（如 2026-11-19T15:00+08:00），会自动换算成日历时区。' +
      '有外部参会人时会发出邀请，受红线保护，先进决策台；没有参会人的个人日程直接订。',
    schema: z.object({
      title: z.string(),
      start: z.string(),
      end: z.string(),
      attendees: z.array(z.string()).describe('参会人邮箱；个人日程填空数组'),
      calendar: z.string().nullable().optional().describe('订在老板哪个邮箱的日历上；不填就用主邮箱'),
    }),
    risk: (i) => (i.attendees?.length ? 'external' : null),
    summarize: (i) => msg('sum.cal', { title: i.title, start: i.start.replace('T', ' '), end: i.end.slice(11), list: i.attendees.join(', ') }),
    run: async (i, d) => `已预订（${(await d.calendar.book(i)).id}）`,
  },
  {
    name: 'notes_write',
    description: '把一份笔记写进工作区的 notes 文件夹（Markdown），例如会议简报。',
    schema: z.object({ title: z.string(), content: z.string().describe('Markdown 正文') }),
    run: (i, d) => {
      const safe = i.title.replace(/[^\p{L}\p{N}_-]+/gu, '-').replace(/^-+|-+$/g, '').slice(0, 60) || 'note';
      const file = `notes/${d.today}-${safe}.md`;
      d.ws.writeText(file, `# ${i.title}\n\n${i.content}\n`);
      return `笔记已保存：${file}`;
    },
  },
];

export const TOOL_MAP: Record<string, ToolDef> = Object.fromEntries(TOOLS.map((t) => [t.name, t]));

export function riskOf(tool: ToolDef, input: unknown): Risk | null {
  return typeof tool.risk === 'function' ? tool.risk(input) : (tool.risk ?? null);
}

export interface GateContext {
  lang: Lang;
  deps: Deps;
  memory: Memory;
  unit: Unit;
  bot: BotDef;
  actions: ActionRecord[];
}

/**
 * 一个 bot 在一个任务单元里能用的工具箱。所有调用都经过这里：校验输入、留下记录。
 * 对外发送、付款、公开发布这类动作一律先暂存，不在执行阶段发生：
 * 质检通过后，红线打开的进决策台等老板批准，红线关闭的才自动执行；质检打回的直接丢弃。
 */
export class ToolBox {
  readonly tools: ToolDef[];

  constructor(private ctx: GateContext) {
    this.tools = ctx.bot.tools.map((n) => TOOL_MAP[n]).filter((t): t is ToolDef => Boolean(t));
  }

  async call(name: string, raw: unknown): Promise<string> {
    const tool = this.tools.find((t) => t.name === name);
    if (!tool) return this.record(name, raw, `这个 bot 没有工具 ${name}`);
    const parsed = tool.schema.safeParse(raw);
    if (!parsed.success) {
      const why = parsed.error.issues.map((x) => `${x.path.join('.') || '输入'}：${x.message}`).join('；');
      return this.record(name, raw, `输入不合法：${why}`);
    }
    const input = parsed.data;
    const risk = riskOf(tool, input);
    if (risk) {
      const same = this.ctx.actions.find(
        (a) => a.staged && a.tool === name && JSON.stringify(a.input) === JSON.stringify(input),
      );
      if (same) return '这件事已经暂存过，不要重复提交。';
      const summaryMsg = tool.summarize?.(input) ?? msg('log.error', { msg: name });
      const summary = fmt(this.ctx.lang, summaryMsg);
      const note = this.ctx.memory.redlineOn(risk)
        ? `已暂存：${summary}。质检通过后进入老板的决策台，老板批准才真正执行。不要重复提交。`
        : `已暂存：${summary}。质检通过后会自动执行。不要重复提交。`;
      this.ctx.actions.push({ tool: name, input, result: note, staged: { risk, summary, summaryMsg } });
      return note;
    }
    try {
      const result = await tool.run(input, this.ctx.deps);
      return this.record(name, input, result, name === 'mail_draft' ? DRAFT_SAVED.exec(result)?.[1] : undefined);
    } catch (e) {
      return this.record(name, input, `执行失败：${(e as Error).message}`);
    }
  }

  private record(tool: string, input: unknown, result: string, ref?: string): string {
    this.ctx.actions.push({ tool, input, result, ...(ref ? { ref } : {}) });
    return result;
  }
}
