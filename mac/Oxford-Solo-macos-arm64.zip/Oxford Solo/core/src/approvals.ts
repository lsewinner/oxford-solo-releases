// 决策台：碰到红线的动作停在这里，等老板批准、修改后批准，或驳回（可顺手记成规则）
import type { Deps, MailSource } from './connectors/index.js';
import { CodedError, DEFAULT_LANG, t, type Lang, type Msg } from './i18n.js';
import type { Memory } from './memory.js';
import { TOOL_MAP } from './tools.js';
import type { Risk } from './types.js';
import type { Workspace } from './workspace.js';

export type ApprovalStatus = 'pending' | 'approved' | 'rejected';

export interface Approval {
  id: string;
  runId: string;
  unitId: string;
  bot: string;
  /** 动作要在哪个邮箱执行（生成时用的那个）；旧记录没有这个字段，按示例数据处理 */
  source?: MailSource;
  tool: string;
  risk: Risk;
  input: Record<string, unknown>;
  summary: string;
  summaryMsg?: Msg;
  status: ApprovalStatus;
  /** 老板改过正文后批准 */
  edited?: boolean;
  createdAt: string;
  decidedAt?: string;
  result?: string;
  note?: string;
}

export class Approvals {
  constructor(private ws: Workspace) {}

  all(): Approval[] {
    return this.ws.readJson<Approval[]>('approvals.json');
  }

  pending(): Approval[] {
    return this.all().filter((a) => a.status === 'pending');
  }

  get(id: string): Approval {
    const a = this.all().find((x) => x.id.toLowerCase() === id.toLowerCase());
    if (!a) throw new CodedError('notFound', { id });
    return a;
  }

  private update(id: string, patch: Partial<Approval>): Approval {
    const list = this.all();
    const a = list.find((x) => x.id === id);
    if (!a) throw new Error(`找不到审批 ${id}`);
    Object.assign(a, patch);
    this.ws.writeJson('approvals.json', list);
    return a;
  }

  create(a: Omit<Approval, 'id' | 'status' | 'createdAt'>): Approval {
    const list = this.all();
    const ap: Approval = {
      id: 'A' + String(list.reduce((m, x) => Math.max(m, Number(x.id.slice(1)) || 0), 0) + 1).padStart(3, '0'),
      status: 'pending',
      createdAt: new Date().toISOString(),
      ...a,
    };
    list.push(ap);
    this.ws.writeJson('approvals.json', list);
    return ap;
  }

  /**
   * 批准：此时才真正执行动作。edit 可以在批准前改正文。
   * deps 可以传一个函数：按这件事生成时用的邮箱来组装（老板中途换了邮箱也不会发错地方）
   */
  async approve(id: string, depsOrFor: Deps | ((source: MailSource) => Deps), edit: { body?: string } = {}): Promise<Approval> {
    const a = this.get(id);
    if (a.status !== 'pending') throw new CodedError('notPending', { id: a.id });
    const source: MailSource = !a.source || a.source === 'local' ? 'local' : 'live';
    const deps = typeof depsOrFor === 'function' ? depsOrFor(source) : depsOrFor;
    if (a.source && deps.source !== source) throw new CodedError('mailSourceChanged', {});
    const tool = TOOL_MAP[a.tool];
    if (!tool) throw new Error(`未知工具 ${a.tool}`);
    const input = edit.body ? { ...a.input, body: edit.body } : a.input;
    const result = await tool.run(input, deps);
    return this.update(a.id, {
      status: 'approved',
      input,
      result,
      edited: Boolean(edit.body),
      decidedAt: new Date().toISOString(),
    });
  }

  reject(id: string, opts: { rule?: string; memory?: Memory; lang?: Lang } = {}): Approval {
    const a = this.get(id);
    if (a.status !== 'pending') throw new CodedError('notPending', { id: a.id });
    if (opts.rule && opts.memory) opts.memory.addRule(opts.rule, t(opts.lang ?? DEFAULT_LANG, 'src.ownerReject', { id: a.id, tool: a.tool }));
    return this.update(a.id, {
      status: 'rejected',
      note: opts.rule ? `驳回并记成规则：${opts.rule}` : '驳回',
      decidedAt: new Date().toISOString(),
    });
  }
}
