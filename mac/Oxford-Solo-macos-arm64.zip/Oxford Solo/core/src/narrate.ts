// 把运行事件翻译成日志行。日志行是结构化消息（文案键 + 参数），命令行和网页按各自的语言显示。
import { BOT_MAP } from './bots.js';
import { msg, type Msg } from './i18n.js';
import type { RunEvent } from './orchestrator.js';

export type LogKind = 'you' | 'orch' | 'check' | 'split' | 'bot' | 'rule' | 'desk' | 'bad' | 'dim';

export interface LogLine {
  kind: LogKind;
  who: Msg;
  msg: Msg;
  /** 附在这一行下面的条目，例如验收标准（模型或模拟大脑写的原文） */
  sub?: string[];
}

export const fmtUsd = (n: number) => '$' + (n > 0 && n < 0.01 ? n.toFixed(4) : n.toFixed(2));

const who = (k: string) => msg('log.who.' + k);

export function narrate(e: RunEvent): LogLine[] {
  switch (e.type) {
    case 'start':
      return [
        { kind: 'you', who: who('you'), msg: msg('log.instruction', { text: e.instruction }) },
        { kind: 'dim', who: who('mode'), msg: e.mode === 'mock' ? msg('log.modeMock') : msg('log.modeClaude', { model: e.model, budget: fmtUsd(e.budgetUsd) }) },
      ];
    case 'context':
      return [
        {
          kind: 'orch',
          who: who('orch'),
          msg: msg('log.context', { emails: e.emails, unread: e.unread, contacts: e.contacts, events: e.events, rules: e.rules }),
        },
      ];
    case 'criteria':
      return [{ kind: 'check', who: who('check'), msg: msg('log.criteria', { n: e.criteria.length }), sub: e.criteria }];
    case 'split':
      return [
        { kind: 'split', who: who('split'), msg: msg('log.split', { units: e.units.length, bots: new Set(e.units.map((u) => u.bot)).size }) },
        ...e.dropped.map((d): LogLine => ({ kind: 'bad', who: who('split'), msg: msg('log.dropped', { text: d }) })),
      ];
    case 'unit': {
      const b = BOT_MAP[e.unit.bot];
      const botWho = b ? msg('log.who.bot', { code: b.code, name: msg('bot.' + b.id) }) : msg('log.error', { msg: e.unit.bot });
      switch (e.state) {
        case 'running':
          return [
            {
              kind: 'bot',
              who: botWho,
              msg: msg('log.start', { id: e.unit.id, title: e.unit.title, attempt: e.unit.attempts > 1 ? msg('log.attempt', { n: e.unit.attempts }) : '' }),
            },
          ];
        case 'done':
          return [{ kind: 'check', who: who('check'), msg: msg('log.pass', { id: e.unit.id, text: e.text ?? '' }) }];
        case 'awaiting':
          return [{ kind: 'check', who: who('check'), msg: msg('log.passWait', { id: e.unit.id, ids: e.unit.approvals.join(' ') }) }];
        case 'failed':
          return [{ kind: 'bad', who: who('fail'), msg: msg('log.failed', { id: e.unit.id, text: e.text ?? '' }) }];
        case 'skipped':
          return [{ kind: 'dim', who: who('skip'), msg: msg('log.failed', { id: e.unit.id, text: e.text ?? '' }) }];
        default:
          return [];
      }
    }
    case 'rejected':
      return [{ kind: 'bad', who: who('check'), msg: msg('log.rejected', { id: e.unit.id, reason: e.reason }) }];
    case 'rule':
      return [{ kind: 'rule', who: who('rule'), msg: msg('log.rule', { text: e.text }) }];
    case 'approval':
      return [
        {
          kind: 'desk',
          who: who('desk'),
          msg: msg('log.approval', { id: e.approval.id, risk: msg('risk.' + e.approval.risk), summary: e.approval.summaryMsg ?? e.approval.summary }),
        },
      ];
    case 'budget':
      return [{ kind: 'bad', who: who('budget'), msg: msg('log.budget', { spent: fmtUsd(e.spentUsd), budget: fmtUsd(e.budgetUsd) }) }];
    case 'error':
      return [{ kind: 'bad', who: who('error'), msg: msg('log.error', { msg: `${e.unitId ? e.unitId + ': ' : ''}${e.message}` }) }];
    case 'done': {
      const k = e.report.counts;
      return [
        {
          kind: 'orch',
          who: who('orch'),
          msg: msg('log.done', { done: k.done, awaiting: k.awaiting, failed: k.failed, skipped: k.skipped, rej: k.rejections, cost: fmtUsd(e.report.costUsd) }),
        },
      ];
    }
  }
}
