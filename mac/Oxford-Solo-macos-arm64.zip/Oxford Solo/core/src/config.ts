import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));

export const ROOT = path.resolve(here, '..');
export const SAMPLE_DIR = path.join(ROOT, 'data', 'sample');
export const DEFAULT_WORKSPACE = process.env.SOLO_WORKSPACE
  ? path.resolve(process.env.SOLO_WORKSPACE)
  : path.join(ROOT, 'workspace');

export const MODEL = 'claude-opus-5-5';

/** 美元 / 每百万 token。缓存写入按 5 分钟 TTL 的 1.25 倍输入价计。 */
export const PRICES: Record<string, { input: number; output: number; cacheRead: number; cacheWrite: number }> = {
  'claude-opus-5-5': { input: 4, output: 20, cacheRead: 0.2, cacheWrite: 5 },
  'claude-sonnet-5-5': { input: 2, output: 10, cacheRead: 0.1, cacheWrite: 2.5 },
  'claude-haiku-5-5': { input: 0.1, output: 0.5, cacheRead: 0.01, cacheWrite: 0.125 },
  'claude-fable-5-2': { input: 8, output: 40, cacheRead: 0.2, cacheWrite: 10 },
};

export type Price = { input: number; output: number; cacheRead: number; cacheWrite: number };
/** 老板在"连接模型"里填的价格，优先于价目表 */
export const PRICE_OVERRIDES = new Map<string, Price>();
export function setPrice(model: string, input: number, output: number): void {
  PRICE_OVERRIDES.set(model, { input, output, cacheRead: input / 10, cacheWrite: input * 1.25 });
}

/**
 * OpenAI 模型的价格（美元 / 每百万 token）。各模型价格不同，请按 OpenAI 官网填写：
 * OPENAI_PRICE_INPUT、OPENAI_PRICE_OUTPUT。没填时按偏高的估计值算，保证预算上限只会提前、不会失效。
 */
export function openaiPrice() {
  const input = Number(process.env.OPENAI_PRICE_INPUT ?? 5);
  const output = Number(process.env.OPENAI_PRICE_OUTPUT ?? 30);
  return { input, output, cacheRead: input / 10, cacheWrite: input };
}

export const DEFAULT_BUDGET_USD = 3;
export const DEFAULT_PORT = Number(process.env.SOLO_PORT ?? 4610);
export const MAX_ATTEMPTS = 3;
/** 一道指令最多拆成多少个任务单元：一封邮件、一位客户、一场会议各一个 */
export const MAX_UNITS = 100;
/**
 * 同时开工的 bot 数：每个单元一个 bot，全部并行。真正同时打到模型 API 的请求数由 brain/throttle.ts 按限额自动调节，
 * 所以这里可以放开；要省着用可以设 SOLO_MAX_PARALLEL。
 */
export const MAX_PARALLEL = Math.max(1, Math.min(MAX_UNITS, Number(process.env.SOLO_MAX_PARALLEL) || MAX_UNITS));
/** 还没有任何一次尝试完成时，按这个估计每次尝试的花费来预留预算（美元） */
export const FIRST_ATTEMPT_ESTIMATE_USD = 0.03;

export function todayISO(): string {
  if (process.env.SOLO_TODAY) return process.env.SOLO_TODAY;
  // 用这台电脑的当地日期，不用 UTC（北京时间早上 8 点前 UTC 还是前一天）
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}
