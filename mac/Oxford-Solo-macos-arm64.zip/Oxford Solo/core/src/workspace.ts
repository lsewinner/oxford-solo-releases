import fs from 'node:fs';
import path from 'node:path';
import { SAMPLE_DIR } from './config.js';
import { DEFAULT_LANG, normalizeLang, type Lang } from './i18n.js';
import { parseMemory, renderMemory } from './memory.js';

const SEED_FILES = ['inbox.json', 'contacts.json', 'calendar.json', 'profile.json', 'MEMORY.md'];
const EMPTY_FILES: Array<[string, string]> = [
  ['drafts.json', '[]'],
  ['sent.json', '[]'],
  ['approvals.json', '[]'],
  ['ledger.json', '{ "runs": [] }'],
];

/**
 * 一家公司的全部状态都放在一个文件夹里：邮箱、日历、客户、记忆、审批、账本、运行记录。
 * sample = 演示用的示例公司（林间咨询工作室），可以随时恢复；
 * company = 老板自己的真实公司，接真实邮箱时用，放在 ~/.oxford-solo/company，永远不会被一键清空。
 */
export type WorkspaceKind = 'sample' | 'company';

/** 老板真实公司的工作区 */
export function companyWorkspace(home: string): Workspace {
  return new Workspace(path.join(home, 'company'), 'company');
}

export class Workspace {
  constructor(
    readonly dir: string,
    readonly kind: WorkspaceKind = 'sample',
  ) {}

  path(...parts: string[]): string {
    return path.join(this.dir, ...parts);
  }

  exists(name: string): boolean {
    return fs.existsSync(this.path(name));
  }

  /** 第一次使用时建好工作区：示例公司拷贝示例数据；真实公司从空的客户库、空白资料、没有规则的 MEMORY.md 开始 */
  ensure(): this {
    const mode = this.kind === 'company' ? 0o700 : undefined;
    fs.mkdirSync(this.dir, { recursive: true, mode });
    fs.mkdirSync(this.path('runs'), { recursive: true, mode });
    fs.mkdirSync(this.path('notes'), { recursive: true, mode });
    if (this.kind === 'company') {
      if (!this.exists('contacts.json')) fs.writeFileSync(this.path('contacts.json'), '[]\n');
      if (!this.exists('profile.json')) this.writeJson('profile.json', { name: '', company: '', email: '', language: DEFAULT_LANG });
      if (!this.exists('MEMORY.md')) {
        const d = parseMemory(fs.readFileSync(path.join(SAMPLE_DIR, 'MEMORY.md'), 'utf8'));
        d.rules = [];
        this.writeText('MEMORY.md', renderMemory(d, DEFAULT_LANG));
      }
    } else {
      for (const f of SEED_FILES) {
        if (!this.exists(f)) fs.copyFileSync(path.join(SAMPLE_DIR, f), this.path(f));
      }
    }
    for (const [f, init] of EMPTY_FILES) {
      if (!this.exists(f)) fs.writeFileSync(this.path(f), init + '\n');
    }
    this.migrateSingleAccount();
    return this;
  }

  /**
   * 旧版每家只能连一个账号，短 ID 是 m3、ev2；新版带账号前缀 g1-m3、o1-ev2。
   * 把旧的对照表和决策台上还没处理的事一起换成新格式（只做一次）。
   */
  private migrateSingleAccount(): void {
    const legacy: Array<[string, string]> = [
      ['google', 'g1'],
      ['microsoft', 'o1'],
    ];
    for (const [old, acct] of legacy) {
      const from = this.path(`ids-${old}.json`);
      if (!fs.existsSync(from)) continue;
      const d = JSON.parse(fs.readFileSync(from, 'utf8')) as { next: Record<string, number>; short: Record<string, string>; long: Record<string, string> };
      const to = { next: {} as Record<string, number>, short: {} as Record<string, string>, long: {} as Record<string, string> };
      for (const [p, n] of Object.entries(d.next)) to.next[`${acct}-${p}`] = n;
      for (const [k, v] of Object.entries(d.short)) {
        const i = k.indexOf(':');
        to.short[`${acct}-${k.slice(0, i)}:${k.slice(i + 1)}`] = `${acct}-${v}`;
      }
      for (const [k, v] of Object.entries(d.long)) to.long[`${acct}-${k}`] = v;
      if (!this.exists(`ids-${acct}.json`)) this.writeJson(`ids-${acct}.json`, to);
      fs.renameSync(from, from + '.migrated');
    }
    if (!this.exists('approvals.json')) return;
    const list = this.readJson<Array<{ source?: string; input: Record<string, unknown> }>>('approvals.json');
    let changed = false;
    for (const a of list) {
      const acct = a.source === 'google' ? 'g1' : a.source === 'microsoft' ? 'o1' : null;
      if (!acct) continue;
      if (typeof a.input.replyTo === 'string' && /^(m|ev)\d+$/.test(a.input.replyTo)) a.input.replyTo = `${acct}-${a.input.replyTo}`;
      a.source = 'live';
      changed = true;
    }
    if (changed) this.writeJson('approvals.json', list);
  }

  /** 清空并恢复成示例数据。真实公司的工作区不允许这样做 */
  reset(): this {
    if (this.kind === 'company') throw new Error('真实公司的数据不能一键清空');
    fs.rmSync(this.dir, { recursive: true, force: true });
    return this.ensure();
  }

  readText(name: string): string {
    return fs.readFileSync(this.path(name), 'utf8');
  }

  writeText(name: string, text: string): void {
    const p = this.path(name);
    fs.mkdirSync(path.dirname(p), { recursive: true });
    const tmp = p + '.tmp';
    fs.writeFileSync(tmp, text);
    fs.renameSync(tmp, p);
  }

  /** 公司的工作语言（profile.json 里的 language） */
  language(): Lang {
    try {
      return normalizeLang(this.readJson<{ language?: string }>('profile.json').language) ?? DEFAULT_LANG;
    } catch {
      return DEFAULT_LANG;
    }
  }

  setLanguage(lang: Lang): void {
    const profile = this.readJson<Record<string, unknown>>('profile.json');
    profile.language = lang;
    this.writeJson('profile.json', profile);
  }

  readJson<T>(name: string): T {
    return JSON.parse(this.readText(name)) as T;
  }

  writeJson(name: string, data: unknown): void {
    this.writeText(name, JSON.stringify(data, null, 2) + '\n');
  }
}
