import { DEFAULT_BUDGET_USD } from './config.js';
import { LANGS, t, type Lang } from './i18n.js';
import { RISKS, type RedlineRisk, type Risk } from './types.js';
import type { Workspace } from './workspace.js';

export interface Rule {
  text: string;
  on: boolean;
  src: string;
}

export interface MemoryData {
  redlines: Record<RedlineRisk, boolean>;
  budgetUsd: number;
  rules: Rule[];
}

/** 任何语言写的小标题都认得（换了工作语言后，旧文件照样能读） */
const headings = (key: string) => LANGS.map((l) => t(l, 'mem.h.' + key));
const H_REDLINES = headings('redlines');
const H_BUDGET = headings('budget');
const H_RULES = headings('rules');
const isSection = (name: string, list: string[]) => list.some((h) => name.startsWith(h));

/** MEMORY.md 是人能直接读、直接改的纯文本；这里负责解析和写回 */
export function parseMemory(md: string): MemoryData {
  const data: MemoryData = {
    redlines: { external: true, pay: true, public: true },
    budgetUsd: DEFAULT_BUDGET_USD,
    rules: [],
  };
  let section: 'redlines' | 'budget' | 'rules' | '' = '';
  for (const raw of md.split(/\r?\n/)) {
    const line = raw.trim();
    if (line.startsWith('## ')) {
      const name = line.slice(3).trim();
      section = isSection(name, H_REDLINES) ? 'redlines' : isSection(name, H_BUDGET) ? 'budget' : isSection(name, H_RULES) ? 'rules' : '';
      continue;
    }
    const item = line.match(/^- \[( |x|X)\] (.+)$/);
    if (section === 'redlines' && item) {
      const key = item[2].split(/[：:]/)[0].trim() as Risk;
      if (RISKS.includes(key as RedlineRisk)) data.redlines[key as RedlineRisk] = item[1] !== ' ';
    } else if (section === 'rules' && item) {
      const withSrc = item[2].match(/^(.*?)\s*<!--\s*[^：:]*[：:]\s*(.*?)\s*-->$/);
      data.rules.push({ text: (withSrc ? withSrc[1] : item[2]).trim(), src: withSrc ? withSrc[2].trim() : '', on: item[1] !== ' ' });
    } else if (section === 'budget') {
      const b = line.match(/\$\s*([\d.]+)/);
      if (b) data.budgetUsd = Number(b[1]);
    }
  }
  return data;
}

export function renderMemory(d: MemoryData, lang: Lang = 'zh-CN'): string {
  const colon = lang === 'en' || lang === 'vi' ? ': ' : '：';
  return [
    '# MEMORY.md',
    '',
    t(lang, 'mem.intro'),
    '',
    '## ' + t(lang, 'mem.h.redlines'),
    ...RISKS.map((r) => `- [${d.redlines[r] ? 'x' : ' '}] ${r}${colon}${t(lang, 'mem.redline.' + r)}`),
    '',
    '## ' + t(lang, 'mem.h.budget'),
    `- ${t(lang, 'mem.budgetLine', { v: '$' + d.budgetUsd.toFixed(2) })}`,
    '',
    '## ' + t(lang, 'mem.h.rules'),
    ...d.rules.map((r) => `- [${r.on ? 'x' : ' '}] ${r.text}  <!-- ${t(lang, 'mem.src')}${colon}${r.src} -->`),
    '',
  ].join('\n');
}

export class Memory {
  data: MemoryData;
  lang: Lang;

  constructor(private ws: Workspace) {
    this.lang = ws.language();
    this.data = parseMemory(ws.readText('MEMORY.md'));
  }

  save(): void {
    this.ws.writeText('MEMORY.md', renderMemory(this.data, this.lang));
  }

  activeRules(): string[] {
    return this.data.rules.filter((r) => r.on).map((r) => r.text);
  }

  redlineOn(r: Risk): boolean {
    return r === 'decide' || this.data.redlines[r];
  }

  /** 加一条规则；重复的、换个说法的同一条规则都不加。返回是否真的加上了 */
  addRule(text: string, src: string): boolean {
    const clean = text.replace(/\s+/g, ' ').trim();
    if (!clean || this.data.rules.some((r) => r.text === clean || sameRule(r.text, clean))) return false;
    this.data.rules.push({ text: clean, src, on: true });
    this.save();
    return true;
  }

  toggleRule(text: string, on: boolean): boolean {
    const r = this.data.rules.find((x) => x.text === text);
    if (!r) return false;
    r.on = on;
    this.save();
    return true;
  }

  setRedline(r: RedlineRisk, on: boolean): void {
    this.data.redlines[r] = on;
    this.save();
  }

  setBudget(usd: number): void {
    this.data.budgetUsd = usd;
    this.save();
  }

  /** 换工作语言：小标题和说明换成新语言，规则原文不动 */
  setLanguage(lang: Lang): void {
    this.lang = lang;
    this.save();
  }
}

/**
 * 两条规则是不是同一个意思换了说法（例如"须"和"必须"、多一个"提交"）。
 * 去掉标点后按相邻两个字符比相似度，≥ 0.85 算重复；"周五/周四"、"全称/简称"这种一字之差会保留。
 */
export function sameRule(a: string, b: string): boolean {
  const pairs = (s: string) => {
    const t = s.toLowerCase().replace(/[\p{P}\p{S}\s]+/gu, '');
    const out = new Set<string>();
    for (let i = 0; i < t.length - 1; i++) out.add(t.slice(i, i + 2));
    return out;
  };
  const A = pairs(a), B = pairs(b);
  if (A.size < 3 || B.size < 3) return false;
  let both = 0;
  for (const x of A) if (B.has(x)) both++;
  return (2 * both) / (A.size + B.size) >= 0.85;
}
