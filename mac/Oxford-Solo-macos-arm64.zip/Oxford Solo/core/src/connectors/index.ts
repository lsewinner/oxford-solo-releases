// 连接器入口：按老板选的数据来源，组装邮箱、日历和客户库。
// local = 工作区里的示例数据；live = 老板连接的全部真实账号（Gmail / Google 日历、Outlook / Microsoft 365，可以好几个）。
// 模拟运行（没有接模型）永远只用示例数据，不会碰真实邮箱。
import { REAL_ENDPOINTS, TokenSource, activeSource, liveAccounts, loadAccounts, type Endpoints } from '../accounts.js';
import { DEFAULT_HOME } from '../credentials.js';
import { CodedError } from '../i18n.js';
import type { Owner } from '../types.js';
import type { Workspace } from '../workspace.js';
import { GmailMailbox, GoogleCalendar } from './google.js';
import { ApiClient, IdMap } from './http.js';
import { LocalCalendar, LocalContacts, LocalMailbox, OutboxLog } from './local.js';
import { IMMUTABLE, OutlookCalendar, OutlookMailbox } from './microsoft.js';
import { MultiCalendar, MultiMailbox, type LiveAccount } from './multi.js';
import type { Calendar, Mailbox, MailSource } from './types.js';

export { LocalCalendar, LocalContacts, LocalMailbox, OutboxLog } from './local.js';
export { MultiCalendar, MultiMailbox } from './multi.js';
export type { Calendar, Draft, Mailbox, MailSource, NewEvent } from './types.js';

export interface Deps {
  ws: Workspace;
  /** 这次用的是示例数据还是真实账号 */
  source: MailSource;
  mailbox: Mailbox;
  calendar: Calendar;
  contacts: LocalContacts;
  /** Solo 自己留的草稿和已发记录 */
  outbox: OutboxLog;
  owner: Owner;
  today: string;
}

export interface DepsOptions {
  /** 保存授权的目录，默认 ~/.oxford-solo */
  home?: string;
  /** 不填就用老板在界面上选的 */
  source?: MailSource;
  /** 测试时换成本机的假服务 */
  endpoints?: Endpoints;
}

export function makeDeps(ws: Workspace, today: string, o: DepsOptions = {}): Deps {
  const home = o.home ?? DEFAULT_HOME;
  const source = o.source ?? activeSource(home);
  const owner = ws.readJson<Owner>('profile.json');
  const outbox = new OutboxLog(ws);
  const contacts = new LocalContacts(ws);
  if (source === 'local') {
    return { ws, source, mailbox: new LocalMailbox(ws, outbox, owner.email), calendar: new LocalCalendar(ws), contacts, outbox, owner, today };
  }
  const accounts = liveAccounts(loadAccounts(home));
  if (!accounts.length) throw new CodedError('mailNotConnected', { provider: 'Google / Microsoft' });
  const ep = o.endpoints ?? REAL_ENDPOINTS;
  const live: LiveAccount[] = accounts.map((a) => {
    const tokens = new TokenSource(home, a.id, ep);
    const ids = new IdMap(ws, a.id);
    const ref = { id: a.id, email: a.email };
    if (a.provider === 'google') {
      return {
        id: a.id,
        email: a.email,
        mailbox: new GmailMailbox(new ApiClient(tokens, `Gmail（${a.email}）`), ep.gmail, ids, outbox, ref),
        calendar: new GoogleCalendar(new ApiClient(tokens, `Google Calendar（${a.email}）`), ep.gcal, ids, ref),
      };
    }
    const api = new ApiClient(tokens, `Microsoft Graph（${a.email}）`, { Prefer: IMMUTABLE });
    return { id: a.id, email: a.email, mailbox: new OutlookMailbox(api, ep.graph, ids, outbox, ref), calendar: new OutlookCalendar(api, ep.graph, ids, ref) };
  });
  return {
    ws,
    source,
    mailbox: new MultiMailbox(live),
    calendar: new MultiCalendar(live),
    contacts,
    outbox,
    owner: { ...owner, email: accounts[0].email, mailboxes: accounts.map((a) => a.email) },
    today,
  };
}
