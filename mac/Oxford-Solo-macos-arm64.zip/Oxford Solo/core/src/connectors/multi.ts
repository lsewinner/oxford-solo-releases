// 把老板的几个邮箱账号合成一个收件箱、一个日历给 bot 用。
// 邮件和日程的 ID 都带账号前缀（g1-m3、g2-ev5、o1-m2），按前缀找回是哪个账号：
// 回复永远从收到原邮件的那个邮箱发出；新邮件和新日程默认用主邮箱，也可以指定。
import type { CalEvent, Email, OutMail } from '../types.js';
import { findClash, toWallTime, type Calendar, type Draft, type ListOpts, type Mailbox, type NewEvent } from './types.js';

export interface LiveAccount {
  id: string;
  email: string;
  mailbox: Mailbox;
  calendar: Calendar;
}

/** 某个账号读取失败（例如授权过期）：其余账号照常工作，失败的记下来给界面看 */
export interface AccountError {
  id: string;
  email: string;
  error: unknown;
}

function route(accts: LiveAccount[], id: string): LiveAccount {
  const m = id.trim().match(/^([a-z]\d+)-/);
  const a = m && accts.find((x) => x.id === m[1]);
  if (!a) throw new Error(`找不到 ${id}：请先用列表或搜索拿到它的 ID`);
  return a;
}

function byEmail(accts: LiveAccount[], addr?: string | null): LiveAccount {
  if (!addr) return accts[0];
  const a = accts.find((x) => x.email.toLowerCase() === addr.trim().toLowerCase());
  if (!a) throw new Error(`没有连接邮箱 ${addr}；可以用的是：${accts.map((x) => x.email).join('、')}`);
  return a;
}

/** 几个账号一起查：失败的跳过并记下；全部失败才报错 */
async function gather<T>(accts: LiveAccount[], fn: (a: LiveAccount) => Promise<T[]>, errors: AccountError[]): Promise<T[]> {
  const res = await Promise.allSettled(accts.map(fn));
  errors.length = 0;
  const out: T[] = [];
  res.forEach((r, i) => {
    if (r.status === 'fulfilled') out.push(...r.value);
    else errors.push({ id: accts[i].id, email: accts[i].email, error: r.reason });
  });
  if (errors.length === accts.length && accts.length) throw errors[0].error;
  return out;
}

export class MultiMailbox implements Mailbox {
  readonly source = 'live' as const;
  readonly errors: AccountError[] = [];

  /** accts 里主邮箱排第一 */
  constructor(private accts: LiveAccount[]) {}

  /** limit 是每个账号最多取几封 */
  async list(opts: ListOpts = {}): Promise<Email[]> {
    const all = await gather(this.accts, (a) => a.mailbox.list(opts), this.errors);
    return all.sort((x, y) => y.date.localeCompare(x.date));
  }

  async read(id: string): Promise<Email> {
    return route(this.accts, id).mailbox.read(id);
  }

  async search(query: string, limit = 10): Promise<Email[]> {
    const all = await gather(this.accts, (a) => a.mailbox.search(query, limit), []);
    return all.sort((x, y) => y.date.localeCompare(x.date)).slice(0, limit * 2);
  }

  async label(id: string, label: string): Promise<void> {
    return route(this.accts, id).mailbox.label(id, label);
  }

  async archive(id: string): Promise<void> {
    return route(this.accts, id).mailbox.archive(id);
  }

  /** 回复：从收到原邮件的邮箱发；新邮件：from 指定的邮箱，不填用主邮箱 */
  private sender(d: Draft): LiveAccount {
    return d.replyTo ? route(this.accts, d.replyTo) : byEmail(this.accts, d.from);
  }

  async saveDraft(d: Draft): Promise<OutMail> {
    return this.sender(d).mailbox.saveDraft(d);
  }

  /** 草稿记录里写着是哪个邮箱存的，每个邮箱只删自己的 */
  async discardDraft(id: string): Promise<void> {
    for (const a of this.accts) await a.mailbox.discardDraft(id);
  }

  async send(d: Draft): Promise<OutMail> {
    return this.sender(d).mailbox.send(d);
  }
}

export class MultiCalendar implements Calendar {
  readonly source = 'live' as const;
  readonly errors: AccountError[] = [];

  constructor(private accts: LiveAccount[]) {}

  /** 同一个会议邀请了老板的两个邮箱时只显示一次（保留主邮箱那一份） */
  async list(from?: string, to?: string): Promise<CalEvent[]> {
    const all = await gather(this.accts, (a) => a.calendar.list(from, to), this.errors);
    const seen = new Set<string>();
    return all
      .filter((e) => {
        const key = `${e.title}|${e.start}|${e.end}`;
        if (seen.has(key)) return false;
        seen.add(key);
        return true;
      })
      .sort((a, b) => a.start.localeCompare(b.start));
  }

  /** 各日历时区都一样就返回一个；不一样时写明每个邮箱的时区 */
  async timeZone(): Promise<string> {
    const zones = await Promise.all(this.accts.map(async (a) => [a.email, await a.calendar.timeZone().catch(() => '?')] as const));
    const uniq = [...new Set(zones.map(([, z]) => z))];
    return uniq.length === 1 ? uniq[0] : zones.map(([e, z]) => `${e}: ${z}`).join('; ');
  }

  /** 老板只有一个人：任何一个日历上有冲突都算冲突 */
  async book(input: NewEvent): Promise<CalEvent> {
    const a = byEmail(this.accts, input.calendar);
    const zone = await a.calendar.timeZone().catch(() => undefined);
    const e = { ...input, start: toWallTime(input.start, zone), end: toWallTime(input.end, zone) };
    const clash = findClash(await this.list(e.start.slice(0, 10), e.end.slice(0, 10)), e);
    if (clash) throw new Error(`和「${clash.title}」（${clash.start}–${clash.end}）时间冲突`);
    return a.calendar.book(e);
  }
}
