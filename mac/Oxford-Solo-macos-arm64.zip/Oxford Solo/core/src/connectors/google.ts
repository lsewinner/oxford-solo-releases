// Gmail + Google 日历连接器（Gmail API v1、Calendar API v3）
// 分类标签在 Gmail 里显示为 "Solo/needs-reply" 这样的标签；归档 = 移出收件箱，可以随时恢复。
import type { CalEvent, Email, OutMail } from '../types.js';
import { addDays } from '../snapshot.js';
import { ApiClient, ApiError, IdMap, clip, decodeEntities, htmlToText, localMinute, mapLimit, parseAddress } from './http.js';
import type { OutboxLog } from './local.js';
import { checkNewEvent, findClash, toWallTime, type Calendar, type Draft, type ListOpts, type Mailbox, type NewEvent } from './types.js';

export const LABEL_PREFIX = 'Solo/';

interface GPart {
  mimeType?: string;
  headers?: Array<{ name: string; value: string }>;
  body?: { data?: string; size?: number };
  parts?: GPart[];
}

interface GMsg {
  id: string;
  threadId?: string;
  labelIds?: string[];
  snippet?: string;
  internalDate?: string;
  payload?: GPart;
}

const headerMap = (p?: GPart) => Object.fromEntries((p?.headers ?? []).map((h) => [h.name.toLowerCase(), h.value]));

function decodePart(p: GPart): string {
  const bytes = Buffer.from(p.body?.data ?? '', 'base64url');
  try {
    return new TextDecoder('utf-8', { fatal: true }).decode(bytes);
  } catch {
    const charset = /charset="?([\w-]+)/i.exec(headerMap(p)['content-type'] ?? '')?.[1] ?? 'utf-8';
    try {
      return new TextDecoder(charset).decode(bytes);
    } catch {
      return bytes.toString('utf8');
    }
  }
}

/** 找正文：优先纯文本，没有就把 HTML 转成文本 */
export function extractBody(p?: GPart): string {
  if (!p) return '';
  const all: GPart[] = [];
  const walk = (x: GPart) => {
    all.push(x);
    x.parts?.forEach(walk);
  };
  walk(p);
  const plain = all.find((x) => x.mimeType === 'text/plain' && x.body?.data);
  if (plain) return decodePart(plain).trim();
  const html = all.find((x) => x.mimeType === 'text/html' && x.body?.data);
  return html ? htmlToText(decodePart(html)) : '';
}

/** 非 ASCII 的邮件头按 RFC 2047 编码，每段不超过 45 字节 */
export function encodeHeader(v: string): string {
  if (/^[\x20-\x7e]*$/.test(v)) return v;
  const words: string[] = [];
  let cur = '';
  for (const ch of v) {
    if (Buffer.byteLength(cur + ch) > 45) {
      words.push(cur);
      cur = '';
    }
    cur += ch;
  }
  if (cur) words.push(cur);
  return words.map((w) => `=?UTF-8?B?${Buffer.from(w).toString('base64')}?=`).join('\r\n ');
}

export function buildMime(d: { to: string; subject: string; body: string; inReplyTo?: string; references?: string }): string {
  const body = Buffer.from(d.body.replace(/\r?\n/g, '\r\n'))
    .toString('base64')
    .replace(/.{76}/g, '$&\r\n');
  const lines = [
    `To: ${d.to}`,
    `Subject: ${encodeHeader(d.subject)}`,
    'MIME-Version: 1.0',
    'Content-Type: text/plain; charset="UTF-8"',
    'Content-Transfer-Encoding: base64',
    ...(d.inReplyTo ? [`In-Reply-To: ${d.inReplyTo}`] : []),
    ...(d.references ? [`References: ${d.references}`] : []),
    '',
    body,
  ];
  return Buffer.from(lines.join('\r\n')).toString('base64url');
}

/** 一个已连接账号：短 ID（g1）和邮箱地址 */
export interface AcctRef {
  id: string;
  email: string;
}

export class GmailMailbox implements Mailbox {
  readonly source = 'google' as const;
  private labelCache: Promise<Array<{ id: string; name: string }>> | null = null;

  constructor(
    private api: ApiClient,
    private base: string,
    private ids: IdMap,
    private outbox: OutboxLog,
    private acct: AcctRef,
  ) {}

  private labels(): Promise<Array<{ id: string; name: string }>> {
    this.labelCache ??= this.api.call<{ labels?: Array<{ id: string; name: string }> }>('GET', `${this.base}/labels`).then((r) => r.labels ?? []);
    this.labelCache.catch(() => (this.labelCache = null));
    return this.labelCache;
  }

  private async labelId(name: string): Promise<string> {
    const found = (await this.labels()).find((l) => l.name === name);
    if (found) return found.id;
    try {
      const l = await this.api.call<{ id: string; name: string }>('POST', `${this.base}/labels`, { name, labelListVisibility: 'labelShow', messageListVisibility: 'show' });
      (await this.labels()).push(l);
      return l.id;
    } catch (e) {
      this.labelCache = null;
      const again = (await this.labels()).find((l) => l.name === name);
      if (again) return again.id;
      throw e;
    }
  }

  private async toEmail(m: GMsg, body?: string): Promise<Email> {
    const names = new Map((await this.labels()).map((l) => [l.id, l.name]));
    const h = headerMap(m.payload);
    const from = parseAddress(h.from ?? '');
    const labelIds = m.labelIds ?? [];
    const labels = labelIds
      .map((id) => names.get(id) ?? '')
      .filter((n) => n.startsWith(LABEL_PREFIX))
      .map((n) => n.slice(LABEL_PREFIX.length));
    if (labelIds.includes('SENT')) labels.push('sent');
    return {
      id: this.ids.short(`${this.acct.id}-m`, m.id),
      account: this.acct.email,
      from: from.email,
      fromName: from.name || from.email,
      to: h.to ?? '',
      subject: h.subject ?? '',
      date: localMinute(Number(m.internalDate ?? Date.now())),
      body: body ?? decodeEntities(m.snippet ?? ''),
      labels,
      unread: labelIds.includes('UNREAD'),
      ...(labelIds.includes('INBOX') || labelIds.includes('SENT') ? {} : { archived: true }),
    };
  }

  private async query(params: Record<string, string>): Promise<Email[]> {
    const r = await this.api.call<{ messages?: Array<{ id: string }> }>('GET', `${this.base}/messages?${new URLSearchParams(params)}`);
    const meta = await mapLimit(r.messages ?? [], 8, (x) =>
      this.api.call<GMsg>('GET', `${this.base}/messages/${x.id}?format=metadata&metadataHeaders=From&metadataHeaders=To&metadataHeaders=Subject`),
    );
    return Promise.all(meta.map((m) => this.toEmail(m)));
  }

  list(opts: ListOpts = {}): Promise<Email[]> {
    const p: Record<string, string> = { maxResults: String(opts.limit ?? 25) };
    if (!opts.includeArchived) p.labelIds = 'INBOX';
    if (opts.unreadOnly) p.q = 'is:unread';
    return this.query(p);
  }

  async read(id: string): Promise<Email> {
    const long = this.ids.long(id);
    const m = await this.api.call<GMsg>('GET', `${this.base}/messages/${long}?format=full`);
    if (m.labelIds?.includes('UNREAD')) {
      await this.api.call('POST', `${this.base}/messages/${long}/modify`, { removeLabelIds: ['UNREAD'] });
      m.labelIds = m.labelIds.filter((x) => x !== 'UNREAD');
    }
    return this.toEmail(m, clip(extractBody(m.payload)));
  }

  search(query: string, limit = 10): Promise<Email[]> {
    return this.query({ q: query, maxResults: String(limit) });
  }

  async label(id: string, label: string): Promise<void> {
    const lid = await this.labelId(LABEL_PREFIX + label);
    await this.api.call('POST', `${this.base}/messages/${this.ids.long(id)}/modify`, { addLabelIds: [lid] });
  }

  async archive(id: string): Promise<void> {
    await this.api.call('POST', `${this.base}/messages/${this.ids.long(id)}/modify`, { removeLabelIds: ['INBOX', 'UNREAD'] });
  }

  /** 回复时带上原邮件的会话和 Message-ID，Gmail 里会显示在同一个对话里 */
  private async mime(d: Draft): Promise<{ raw: string; threadId?: string }> {
    if (!d.replyTo) return { raw: buildMime(d) };
    const m = await this.api.call<GMsg>(
      'GET',
      `${this.base}/messages/${this.ids.long(d.replyTo)}?format=metadata&metadataHeaders=Message-ID&metadataHeaders=References`,
    );
    const h = headerMap(m.payload);
    const mid = h['message-id'];
    return { raw: buildMime({ ...d, inReplyTo: mid, references: [h.references, mid].filter(Boolean).join(' ') || undefined }), threadId: m.threadId };
  }

  async saveDraft(d: Draft): Promise<OutMail> {
    const r = await this.api.call<{ id: string }>('POST', `${this.base}/drafts`, { message: await this.mime(d) });
    return this.outbox.add('drafts', d, { source: 'google', providerId: r.id, account: this.acct.email });
  }

  async discardDraft(id: string): Promise<void> {
    const m = this.outbox.draft(id);
    if (!m || m.source !== 'google' || m.account !== this.acct.email) return;
    if (m.providerId) {
      try {
        await this.api.call('DELETE', `${this.base}/drafts/${encodeURIComponent(m.providerId)}`);
      } catch (e) {
        // 老板已经在 Gmail 里删掉（或发出）了，就当删过了
        if (!(e instanceof ApiError && e.status === 404)) throw e;
      }
    }
    this.outbox.discard(id);
  }

  async send(d: Draft): Promise<OutMail> {
    const r = await this.api.call<{ id: string }>('POST', `${this.base}/messages/send`, await this.mime(d));
    const mail = this.outbox.add('sent', d, { source: 'google', providerId: r.id, account: this.acct.email });
    if (d.replyTo) await this.label(d.replyTo, 'replied').catch(() => undefined);
    return mail;
  }
}

interface GEvent {
  id: string;
  status?: string;
  summary?: string;
  location?: string;
  start?: { dateTime?: string; date?: string };
  end?: { dateTime?: string; date?: string };
  attendees?: Array<{ email: string; self?: boolean; resource?: boolean }>;
}

export class GoogleCalendar implements Calendar {
  readonly source = 'google' as const;
  private tz: string | undefined;

  constructor(
    private api: ApiClient,
    private base: string,
    private ids: IdMap,
    private acct: AcctRef,
  ) {}

  private wall(t: { dateTime?: string; date?: string } | undefined, endOfAllDay = false): string {
    if (t?.dateTime) return localMinute(Date.parse(t.dateTime), this.tz);
    if (t?.date) return endOfAllDay ? addDays(t.date, -1) + 'T23:59' : t.date + 'T00:00';
    return '';
  }

  private async fetch(from: string, to: string): Promise<CalEvent[]> {
    const q = new URLSearchParams({
      singleEvents: 'true',
      orderBy: 'startTime',
      maxResults: '250',
      timeMin: addDays(from, -1) + 'T00:00:00Z',
      timeMax: addDays(to, 2) + 'T00:00:00Z',
    });
    const r = await this.api.call<{ items?: GEvent[]; timeZone?: string }>('GET', `${this.base}/calendars/primary/events?${q}`);
    if (r.timeZone) this.tz = r.timeZone;
    return (r.items ?? [])
      .filter((e) => e.status !== 'cancelled')
      .map((e) => ({
        id: this.ids.short(`${this.acct.id}-ev`, e.id),
        account: this.acct.email,
        title: e.summary ?? '',
        start: this.wall(e.start),
        end: this.wall(e.end, true),
        attendees: (e.attendees ?? []).filter((a) => !a.self && !a.resource).map((a) => a.email),
        ...(e.location ? { location: e.location } : {}),
        ...(e.start?.date ? { allDay: true } : {}),
      }));
  }

  async list(from?: string, to?: string): Promise<CalEvent[]> {
    const f = from ?? localMinute(Date.now()).slice(0, 10);
    const t = to ?? addDays(f, 30);
    return (await this.fetch(f, t)).filter((e) => e.start.slice(0, 10) >= f && e.start.slice(0, 10) <= t).sort((a, b) => a.start.localeCompare(b.start));
  }

  async timeZone(): Promise<string> {
    if (!this.tz) {
      const r = await this.api.call<{ timeZone?: string }>('GET', `${this.base}/calendars/primary/events?maxResults=1`);
      if (r.timeZone) this.tz = r.timeZone;
    }
    return this.tz ?? Intl.DateTimeFormat().resolvedOptions().timeZone;
  }

  async book(input: NewEvent): Promise<CalEvent> {
    // 带时区的时间按日历自己的时区换算成当地时间
    const zone = await this.timeZone().catch(() => undefined);
    const e = { ...input, start: toWallTime(input.start, zone), end: toWallTime(input.end, zone) };
    checkNewEvent(e);
    const existing = await this.list(e.start.slice(0, 10), e.end.slice(0, 10));
    const clash = findClash(existing, e);
    if (clash) throw new Error(`和「${clash.title}」（${clash.start}–${clash.end}）时间冲突`);
    const tz = this.tz ?? Intl.DateTimeFormat().resolvedOptions().timeZone;
    const r = await this.api.call<GEvent>('POST', `${this.base}/calendars/primary/events?sendUpdates=${e.attendees.length ? 'all' : 'none'}`, {
      summary: e.title,
      start: { dateTime: e.start + ':00', timeZone: tz },
      end: { dateTime: e.end + ':00', timeZone: tz },
      attendees: e.attendees.map((email) => ({ email })),
    });
    const { calendar: _cal, ...rest } = e;
    return { id: this.ids.short(`${this.acct.id}-ev`, r.id), ...rest, account: this.acct.email };
  }
}
