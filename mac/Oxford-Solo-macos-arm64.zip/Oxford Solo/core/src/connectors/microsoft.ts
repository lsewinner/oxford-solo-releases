// Outlook / Microsoft 365 连接器（Microsoft Graph v1.0），个人账号和工作账号都能用。
// 分类标签用 Outlook 的"类别"（Solo/needs-reply）；归档 = 移到"存档"文件夹。
// 所有请求都要求不可变 ID（ImmutableId），邮件移动文件夹后 ID 不变。
import type { CalEvent, Email, OutMail } from '../types.js';
import { addDays } from '../snapshot.js';
import { ApiClient, ApiError, IdMap, clip, localMinute } from './http.js';
import type { AcctRef } from './google.js';
import type { OutboxLog } from './local.js';
import { checkNewEvent, findClash, toWallTime, type Calendar, type Draft, type ListOpts, type Mailbox, type NewEvent } from './types.js';

export const IMMUTABLE = 'IdType="ImmutableId"';
const CATEGORY_PREFIX = 'Solo/';
const SELECT = 'id,subject,from,toRecipients,receivedDateTime,isRead,categories,bodyPreview,parentFolderId';

interface Addr {
  emailAddress?: { name?: string; address?: string };
}

interface GraphMsg {
  id: string;
  subject?: string;
  from?: Addr;
  toRecipients?: Addr[];
  receivedDateTime?: string;
  isRead?: boolean;
  categories?: string[];
  bodyPreview?: string;
  body?: { contentType?: string; content?: string };
}

/** Graph 的查询参数要带 $，这里自己拼，避免 $ 被编码 */
const qs = (p: Record<string, string>) =>
  Object.entries(p)
    .map(([k, v]) => `${k}=${encodeURIComponent(v)}`)
    .join('&');

const recipients = (to: string) =>
  to
    .split(/[,;]/)
    .map((s) => s.trim())
    .filter(Boolean)
    .map((address) => ({ emailAddress: { address } }));

export class OutlookMailbox implements Mailbox {
  readonly source = 'microsoft' as const;

  constructor(
    private api: ApiClient,
    private base: string,
    private ids: IdMap,
    private outbox: OutboxLog,
    private acct: AcctRef,
  ) {}

  private toEmail(m: GraphMsg, body?: string): Email {
    const from = m.from?.emailAddress ?? {};
    return {
      id: this.ids.short(`${this.acct.id}-m`, m.id),
      account: this.acct.email,
      from: from.address ?? '',
      fromName: from.name || from.address || '',
      to: (m.toRecipients ?? []).map((r) => r.emailAddress?.address ?? '').filter(Boolean).join(', '),
      subject: m.subject ?? '',
      date: localMinute(Date.parse(m.receivedDateTime ?? new Date().toISOString())),
      body: body ?? m.bodyPreview ?? '',
      labels: (m.categories ?? []).filter((c) => c.startsWith(CATEGORY_PREFIX)).map((c) => c.slice(CATEGORY_PREFIX.length)),
      unread: m.isRead === false,
    };
  }

  private msg = (id: string) => `${this.base}/me/messages/${encodeURIComponent(this.ids.long(id))}`;

  async list(opts: ListOpts = {}): Promise<Email[]> {
    const p: Record<string, string> = { $top: String(opts.limit ?? 25), $select: SELECT };
    // Graph 不允许 $filter 和另一字段的 $orderby 同时用；默认顺序本来就是最新在前
    if (opts.unreadOnly) p.$filter = 'isRead eq false';
    else p.$orderby = 'receivedDateTime desc';
    const where = opts.includeArchived ? `${this.base}/me/messages` : `${this.base}/me/mailFolders/inbox/messages`;
    const r = await this.api.call<{ value?: GraphMsg[] }>('GET', `${where}?${qs(p)}`);
    return (r.value ?? []).map((m) => this.toEmail(m));
  }

  async read(id: string): Promise<Email> {
    const m = await this.api.call<GraphMsg>('GET', `${this.msg(id)}?${qs({ $select: SELECT + ',body' })}`, undefined, {
      Prefer: `${IMMUTABLE}, outlook.body-content-type="text"`,
    });
    if (m.isRead === false) {
      await this.api.call('PATCH', this.msg(id), { isRead: true });
      m.isRead = true;
    }
    return this.toEmail(m, clip((m.body?.content ?? '').trim()));
  }

  async search(query: string, limit = 10): Promise<Email[]> {
    const q = `"${query.replace(/["\\]/g, ' ').trim()}"`;
    const r = await this.api.call<{ value?: GraphMsg[] }>('GET', `${this.base}/me/messages?${qs({ $search: q, $top: String(limit), $select: SELECT })}`);
    return (r.value ?? []).map((m) => this.toEmail(m));
  }

  async label(id: string, label: string): Promise<void> {
    const m = await this.api.call<GraphMsg>('GET', `${this.msg(id)}?${qs({ $select: 'categories' })}`);
    const cats = new Set(m.categories ?? []);
    cats.add(CATEGORY_PREFIX + label);
    await this.api.call('PATCH', this.msg(id), { categories: [...cats] });
  }

  async archive(id: string): Promise<void> {
    await this.api.call('PATCH', this.msg(id), { isRead: true });
    await this.api.call('POST', `${this.msg(id)}/move`, { destinationId: 'archive' });
  }

  /** 回复用 createReply，Outlook 里会显示在同一个会话；正文换成 bot 写的 */
  private async draftFor(d: Draft): Promise<string> {
    const content = { subject: d.subject, body: { contentType: 'Text', content: d.body }, toRecipients: recipients(d.to) };
    if (!d.replyTo) return (await this.api.call<GraphMsg>('POST', `${this.base}/me/messages`, content)).id;
    const draft = await this.api.call<GraphMsg>('POST', `${this.msg(d.replyTo)}/createReply`, {});
    await this.api.call('PATCH', `${this.base}/me/messages/${encodeURIComponent(draft.id)}`, content);
    return draft.id;
  }

  async saveDraft(d: Draft): Promise<OutMail> {
    return this.outbox.add('drafts', d, { source: 'microsoft', providerId: await this.draftFor(d), account: this.acct.email });
  }

  async discardDraft(id: string): Promise<void> {
    const m = this.outbox.draft(id);
    if (!m || m.source !== 'microsoft' || m.account !== this.acct.email) return;
    if (m.providerId) {
      try {
        await this.api.call('DELETE', `${this.base}/me/messages/${encodeURIComponent(m.providerId)}`);
      } catch (e) {
        // 老板已经在 Outlook 里删掉（或发出）了，就当删过了
        if (!(e instanceof ApiError && e.status === 404)) throw e;
      }
    }
    this.outbox.discard(id);
  }

  async send(d: Draft): Promise<OutMail> {
    let providerId: string | undefined;
    if (d.replyTo) {
      providerId = await this.draftFor(d);
      await this.api.call('POST', `${this.base}/me/messages/${encodeURIComponent(providerId)}/send`);
    } else {
      await this.api.call('POST', `${this.base}/me/sendMail`, {
        message: { subject: d.subject, body: { contentType: 'Text', content: d.body }, toRecipients: recipients(d.to) },
        saveToSentItems: true,
      });
    }
    const mail = this.outbox.add('sent', d, { source: 'microsoft', providerId, account: this.acct.email });
    if (d.replyTo) await this.label(d.replyTo, 'replied').catch(() => undefined);
    return mail;
  }
}

interface GraphEvent {
  id: string;
  subject?: string;
  isAllDay?: boolean;
  isCancelled?: boolean;
  start?: { dateTime?: string };
  end?: { dateTime?: string };
  location?: { displayName?: string };
  attendees?: Addr[];
}

export class OutlookCalendar implements Calendar {
  readonly source = 'microsoft' as const;
  private tz: Promise<string> | null = null;

  constructor(
    private api: ApiClient,
    private base: string,
    private ids: IdMap,
    private acct: AcctRef,
  ) {}

  /** 邮箱设置里的时区（可能是 Windows 名称，例如 China Standard Time），读写日程都用它 */
  timeZone(): Promise<string> {
    this.tz ??= this.api
      .call<{ value?: string }>('GET', `${this.base}/me/mailboxSettings/timeZone`)
      .then((r) => r.value || 'UTC')
      .catch(() => 'UTC');
    return this.tz;
  }

  async list(from?: string, to?: string): Promise<CalEvent[]> {
    const f = from ?? localMinute(Date.now()).slice(0, 10);
    const t = to ?? addDays(f, 30);
    const tz = await this.timeZone();
    const p = {
      startDateTime: addDays(f, -1) + 'T00:00:00Z',
      endDateTime: addDays(t, 2) + 'T00:00:00Z',
      $top: '200',
      $select: 'id,subject,start,end,attendees,location,isAllDay,isCancelled',
      $orderby: 'start/dateTime',
    };
    const r = await this.api.call<{ value?: GraphEvent[] }>('GET', `${this.base}/me/calendarView?${qs(p)}`, undefined, {
      Prefer: `${IMMUTABLE}, outlook.timezone="${tz}"`,
    });
    const me = this.acct.email.toLowerCase();
    return (r.value ?? [])
      .filter((e) => !e.isCancelled)
      .map((e) => {
        const start = (e.start?.dateTime ?? '').slice(0, 16);
        let end = (e.end?.dateTime ?? '').slice(0, 16);
        if (e.isAllDay && end.endsWith('T00:00')) end = addDays(end.slice(0, 10), -1) + 'T23:59';
        return {
          id: this.ids.short(`${this.acct.id}-ev`, e.id),
          account: this.acct.email,
          title: e.subject ?? '',
          start,
          end,
          attendees: (e.attendees ?? []).map((a) => a.emailAddress?.address ?? '').filter((x) => x && x.toLowerCase() !== me),
          ...(e.location?.displayName ? { location: e.location.displayName } : {}),
          ...(e.isAllDay ? { allDay: true } : {}),
        };
      })
      .filter((e) => e.start.slice(0, 10) >= f && e.start.slice(0, 10) <= t)
      .sort((a, b) => a.start.localeCompare(b.start));
  }

  async book(input: NewEvent): Promise<CalEvent> {
    const zone = await this.timeZone(); // 可能是 Windows 名称，toWallTime 认不出时按本机时区
    const e = { ...input, start: toWallTime(input.start, zone), end: toWallTime(input.end, zone) };
    checkNewEvent(e);
    const clash = findClash(await this.list(e.start.slice(0, 10), e.end.slice(0, 10)), e);
    if (clash) throw new Error(`和「${clash.title}」（${clash.start}–${clash.end}）时间冲突`);
    const tz = await this.timeZone();
    const r = await this.api.call<GraphEvent>('POST', `${this.base}/me/events`, {
      subject: e.title,
      start: { dateTime: e.start + ':00', timeZone: tz },
      end: { dateTime: e.end + ':00', timeZone: tz },
      attendees: e.attendees.map((address) => ({ emailAddress: { address }, type: 'required' })),
    });
    const { calendar: _cal, ...rest } = e;
    return { id: this.ids.short(`${this.acct.id}-ev`, r.id), ...rest, account: this.acct.email };
  }
}
