// 调用 Gmail / Google 日历 / Microsoft Graph 的小工具：自动带令牌、令牌过期自动刷新、限流和服务端错误自动重试
import fs from 'node:fs';
import type { TokenSource } from '../accounts.js';
import type { Workspace } from '../workspace.js';

export class ApiError extends Error {
  constructor(
    readonly status: number,
    message: string,
  ) {
    super(message);
  }
}

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

/** 同一个邮箱账号同时最多发几个请求：上百个 bot 并行时，别一下子撞上 Gmail / Graph 的每用户限额 */
export const MAX_IN_FLIGHT_PER_ACCOUNT = 8;
const MAX_ATTEMPTS = 6;

/** Gmail 的限流有时是 403 加 rateLimitExceeded / userRateLimitExceeded，也要当成限流重试 */
function isRateLimit(status: number, raw: string): boolean {
  return status === 429 || (status === 403 && /rateLimitExceeded|userRateLimitExceeded|quotaExceeded.*per.?minute/i.test(raw));
}

export class ApiClient {
  private inFlight = 0;
  private waiters: Array<() => void> = [];

  constructor(
    private tokens: TokenSource,
    /** 出错时给 bot 看的服务名，例如 Gmail、Microsoft Graph */
    private label: string,
    private baseHeaders: Record<string, string> = {},
  ) {}

  private async slot(): Promise<void> {
    while (this.inFlight >= MAX_IN_FLIGHT_PER_ACCOUNT) await new Promise<void>((r) => this.waiters.push(r));
    this.inFlight++;
  }
  private free(): void {
    this.inFlight--;
    this.waiters.shift()?.();
  }

  async call<T = any>(method: string, url: string, body?: unknown, headers: Record<string, string> = {}): Promise<T> {
    let force = false;
    for (let attempt = 0; ; attempt++) {
      const token = await this.tokens.get(force);
      force = false;
      await this.slot();
      let res: Response;
      let raw: string;
      try {
        res = await fetch(url, {
          method,
          headers: {
            Authorization: `Bearer ${token}`,
            Accept: 'application/json',
            ...(body === undefined ? {} : { 'Content-Type': 'application/json' }),
            ...this.baseHeaders,
            ...headers,
          },
          body: body === undefined ? undefined : JSON.stringify(body),
          signal: AbortSignal.timeout(30_000),
        });
        raw = await res.text();
      } catch (e) {
        this.free();
        if (attempt < 2) {
          await sleep(800 * 2 ** attempt * (0.5 + Math.random()));
          continue;
        }
        throw e;
      }
      this.free();
      if (res.status === 401 && attempt === 0) {
        force = true;
        continue;
      }
      if ((isRateLimit(res.status, raw) || res.status >= 500) && attempt < MAX_ATTEMPTS - 1) {
        const wait = Number(res.headers.get('retry-after'));
        await sleep(wait > 0 && wait < 60 ? wait * 1000 : Math.min(30_000, 800 * 2 ** attempt) * (0.5 + Math.random()));
        continue;
      }
      if (!res.ok) {
        let why = raw.slice(0, 300);
        try {
          const j = JSON.parse(raw) as { error?: { message?: string } | string; error_description?: string };
          why = (typeof j.error === 'object' ? j.error?.message : j.error_description ?? j.error) ?? why;
        } catch {
          /* 不是 JSON，就用原文 */
        }
        throw new ApiError(res.status, `${this.label} 接口出错（${res.status}）：${why}`);
      }
      return (raw ? JSON.parse(raw) : undefined) as T;
    }
  }
}

/** 同时最多跑 n 个请求 */
export async function mapLimit<A, B>(items: A[], n: number, fn: (a: A) => Promise<B>): Promise<B[]> {
  const out: B[] = new Array(items.length);
  let i = 0;
  await Promise.all(
    Array.from({ length: Math.min(n, items.length) }, async () => {
      while (i < items.length) {
        const k = i++;
        out[k] = await fn(items[k]);
      }
    }),
  );
  return out;
}

interface IdData {
  next: Record<string, number>;
  short: Record<string, string>;
  long: Record<string, string>;
}

const idCache = new Map<string, IdData>();

/**
 * 把 Gmail / Outlook 很长的原始 ID 换成 m12、ev3 这样的短 ID 给 bot 用：省 token，也不容易抄错。
 * 对照表存在工作区里，同一个邮件永远是同一个短 ID。
 */
export class IdMap {
  private file: string;

  constructor(
    ws: Workspace,
    source: string,
  ) {
    this.file = ws.path(`ids-${source}.json`);
  }

  /** fresh = true：重新从磁盘读。网页服务器和命令行可能同时在用同一张对照表，查不到或要新编号时先读最新的，避免互相覆盖 */
  private data(fresh = false): IdData {
    let d = idCache.get(this.file);
    if (!d || fresh) {
      try {
        d = JSON.parse(fs.readFileSync(this.file, 'utf8')) as IdData;
      } catch {
        d = d ?? { next: {}, short: {}, long: {} };
      }
      idCache.set(this.file, d);
    }
    return d;
  }

  short(prefix: string, longId: string): string {
    const key = prefix + ':' + longId;
    const cached = this.data().short[key];
    if (cached) return cached;
    const d = this.data(true);
    if (d.short[key]) return d.short[key];
    const n = (d.next[prefix] ?? 0) + 1;
    d.next[prefix] = n;
    const id = prefix + n;
    d.short[key] = id;
    d.long[id] = longId;
    const tmp = this.file + '.tmp';
    fs.writeFileSync(tmp, JSON.stringify(d));
    fs.renameSync(tmp, this.file);
    return id;
  }

  long(shortId: string): string {
    const id = this.data().long[shortId.trim()] ?? this.data(true).long[shortId.trim()];
    if (!id) throw new Error(`找不到 ${shortId}：请先用列表或搜索拿到它的 ID`);
    return id;
  }
}

/** 时间戳 → 当地时间 YYYY-MM-DDTHH:mm（用这台电脑的时区） */
export function localMinute(ms: number, timeZone?: string): string {
  const s = new Intl.DateTimeFormat('sv-SE', {
    timeZone,
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    hourCycle: 'h23',
  }).format(new Date(ms));
  return s.replace(' ', 'T');
}

/** "王敏 <wangmin@x.com>" → 名字和地址 */
export function parseAddress(v: string): { name: string; email: string } {
  const m = v.match(/^\s*"?([^"<]*?)"?\s*<([^>]+)>\s*$/);
  if (m) return { name: m[1].trim(), email: m[2].trim() };
  return { name: '', email: v.trim() };
}

/** 简单把 HTML 邮件变成纯文本 */
export function htmlToText(html: string): string {
  return decodeEntities(
    html
      .replace(/<(script|style)[\s\S]*?<\/\1>/gi, '')
      .replace(/<br\s*\/?>/gi, '\n')
      .replace(/<\/(p|div|li|tr|h\d)>/gi, '\n')
      .replace(/<[^>]+>/g, ''),
  )
    .replace(/[ \t]+\n/g, '\n')
    .replace(/\n{3,}/g, '\n\n')
    .trim();
}

export function decodeEntities(s: string): string {
  return s
    .replace(/&nbsp;/g, ' ')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#39;|&#x27;/g, "'")
    .replace(/&#(\d+);/g, (_, n) => String.fromCodePoint(Number(n)))
    .replace(/&amp;/g, '&');
}

/** 正文太长时截断，避免一封邮件吃掉整个上下文 */
export const clip = (s: string, n = 12_000) => (s.length > n ? s.slice(0, n) + '\n…（正文过长，已截断）' : s);
