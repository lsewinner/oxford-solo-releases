// 本地连接器：用工作区里的 JSON 文件当作邮箱、日历和客户库（示例数据，也用于模拟运行和测试）。
// 客户库（contacts.json）是 Oxford Solo 自己的，接了 Gmail / Outlook 也继续用它。
import type { CalEvent, Contact, Email, OutMail } from '../types.js';
import type { Workspace } from '../workspace.js';
import { checkNewEvent, findClash, matchesAll, toWallTime, type Calendar, type Draft, type ListOpts, type Mailbox, type NewEvent } from './types.js';

export function nextId(prefix: string, ids: string[]): string {
  const n = ids.reduce((m, id) => Math.max(m, Number(id.replace(/\D/g, '')) || 0), 0);
  return prefix + (n + 1);
}

/** Solo 自己存的草稿和已发记录（不管用哪个邮箱，都在这里留一份，界面和账本用它） */
export class OutboxLog {
  constructor(private ws: Workspace) {}

  private all(kind: 'drafts' | 'sent'): OutMail[] {
    return this.ws.readJson<OutMail[]>(`${kind}.json`);
  }

  /** 还在的草稿（丢弃过的不算） */
  drafts(): OutMail[] {
    return this.all('drafts').filter((m) => !m.discarded);
  }

  sent(): OutMail[] {
    return this.all('sent');
  }

  /** 按编号找一份还在的草稿 */
  draft(id: string): OutMail | undefined {
    return this.drafts().find((m) => m.id === id);
  }

  /** 标记草稿已丢弃。记录留着，所以编号不会被下一份草稿重复使用 */
  discard(id: string): void {
    const list = this.all('drafts');
    const m = list.find((x) => x.id === id);
    if (!m || m.discarded) return;
    m.discarded = new Date().toISOString();
    this.ws.writeJson('drafts.json', list);
  }

  add(kind: 'drafts' | 'sent', d: Draft, extra: { source: string; providerId?: string; account?: string }): OutMail {
    const list = this.all(kind);
    const { from: _from, ...rest } = d;
    const mail: OutMail = { id: nextId(kind === 'drafts' ? 'd' : 's', list.map((m) => m.id)), ...rest, createdAt: new Date().toISOString(), ...extra };
    list.push(mail);
    this.ws.writeJson(`${kind}.json`, list);
    return mail;
  }
}

export class LocalMailbox implements Mailbox {
  readonly source = 'local' as const;
  constructor(
    private ws: Workspace,
    private outbox: OutboxLog,
    private ownerEmail = '',
  ) {}

  private all(): Email[] {
    return this.ws.readJson<Email[]>('inbox.json');
  }

  private change(id: string, fn: (e: Email) => void): Email {
    const list = this.all();
    const e = list.find((x) => x.id === id);
    if (!e) throw new Error(`找不到邮件 ${id}`);
    fn(e);
    this.ws.writeJson('inbox.json', list);
    return e;
  }

  /** 同步版，给界面数数用 */
  listSync(opts: ListOpts = {}): Email[] {
    return this.all().filter((e) => (opts.includeArchived || !e.archived) && (!opts.unreadOnly || e.unread));
  }

  async list(opts: ListOpts = {}): Promise<Email[]> {
    return this.listSync(opts);
  }

  async read(id: string): Promise<Email> {
    return this.change(id, (e) => (e.unread = false));
  }

  async search(query: string, limit = 10): Promise<Email[]> {
    const inbox = this.all().filter((e) => matchesAll(query, [e.from, e.fromName, e.to, e.subject, e.body]));
    const sent: Email[] = this.outbox
      .sent()
      .filter((m) => matchesAll(query, [m.to, m.subject, m.body]))
      .map((m) => ({ id: m.id, from: this.ownerEmail, fromName: '', to: m.to, subject: m.subject, date: m.createdAt.slice(0, 19), body: m.body, labels: ['sent'], unread: false }));
    return [...inbox, ...sent].sort((a, b) => b.date.localeCompare(a.date)).slice(0, limit);
  }

  async label(id: string, label: string): Promise<void> {
    this.change(id, (e) => {
      if (!e.labels.includes(label)) e.labels.push(label);
    });
  }

  async archive(id: string): Promise<void> {
    this.change(id, (e) => {
      e.archived = true;
      e.unread = false;
    });
  }

  async saveDraft(d: Draft): Promise<OutMail> {
    return this.outbox.add('drafts', d, { source: 'local' });
  }

  async discardDraft(id: string): Promise<void> {
    if (this.outbox.draft(id)?.source === 'local') this.outbox.discard(id);
  }

  async send(d: Draft): Promise<OutMail> {
    const mail = this.outbox.add('sent', d, { source: 'local' });
    if (d.replyTo) await this.label(d.replyTo, 'replied').catch(() => undefined);
    return mail;
  }
}

export class LocalCalendar implements Calendar {
  readonly source = 'local' as const;
  constructor(private ws: Workspace) {}

  listSync(from?: string, to?: string): CalEvent[] {
    return this.ws
      .readJson<CalEvent[]>('calendar.json')
      .filter((e) => (!from || e.start.slice(0, 10) >= from) && (!to || e.start.slice(0, 10) <= to))
      .sort((a, b) => a.start.localeCompare(b.start));
  }

  async list(from?: string, to?: string): Promise<CalEvent[]> {
    return this.listSync(from, to);
  }

  /** 示例数据的时间按本机时区 */
  async timeZone(): Promise<string> {
    return Intl.DateTimeFormat().resolvedOptions().timeZone;
  }

  async book(input: NewEvent): Promise<CalEvent> {
    const e = { ...input, start: toWallTime(input.start), end: toWallTime(input.end) };
    checkNewEvent(e);
    const list = this.ws.readJson<CalEvent[]>('calendar.json');
    const clash = findClash(list, e);
    if (clash) throw new Error(`和「${clash.title}」（${clash.start}–${clash.end}）时间冲突`);
    const { calendar: _cal, ...rest } = e;
    const ev: CalEvent = { id: nextId('ev', list.map((x) => x.id)), ...rest };
    list.push(ev);
    this.ws.writeJson('calendar.json', list);
    return ev;
  }
}

export class LocalContacts {
  constructor(private ws: Workspace) {}

  list(): Contact[] {
    return this.ws.readJson<Contact[]>('contacts.json');
  }

  get(id: string): Contact | undefined {
    return this.list().find((c) => c.id === id);
  }

  find(query: string): Contact[] {
    const q = query.trim().toLowerCase();
    return this.list().filter((c) => [c.id, c.name, c.company, c.email].some((v) => v.toLowerCase().includes(q)));
  }

  /** 发出邮件后，更新客户的最近联系日期 */
  touch(email: string, date: string): void {
    const list = this.list();
    const c = list.find((x) => x.email.toLowerCase() === email.toLowerCase());
    if (!c) return;
    c.lastContact = date;
    this.ws.writeJson('contacts.json', list);
  }
}
