// 邮箱和日历的统一接口。示例数据、Gmail / Google 日历、Outlook / Microsoft 365 都实现同一套，
// bot、总指挥和决策台不用关心背后是哪一家。
import type { CalEvent, Email, OutMail } from '../types.js';

/** 数据从哪里来：local = 工作区里的示例数据；live = 老板连接的真实账号（可以好几个） */
export type MailSource = 'local' | 'live';
export const MAIL_SOURCES: MailSource[] = ['local', 'live'];

export interface Draft {
  to: string;
  subject: string;
  body: string;
  /** 回复的原邮件 ID；新邮件是 null */
  replyTo: string | null;
  /** 从哪个邮箱发：回复时自动用收到原邮件的那个邮箱；新邮件不填就用主邮箱 */
  from?: string | null;
}

export interface NewEvent {
  title: string;
  /** 当地时间 YYYY-MM-DDTHH:mm */
  start: string;
  end: string;
  attendees: string[];
  /** 订在哪个账号的日历上；不填就用主邮箱的日历 */
  calendar?: string | null;
}

export interface ListOpts {
  unreadOnly?: boolean;
  includeArchived?: boolean;
  /** 最多取几封，默认 25 */
  limit?: number;
}

export interface Mailbox {
  /** local、google、microsoft 或 live（几个账号合在一起） */
  readonly source: string;
  /** 收件箱里的邮件，最新的在前；正文只给摘要，全文用 read */
  list(opts?: ListOpts): Promise<Email[]>;
  /** 读全文，并标记为已读 */
  read(id: string): Promise<Email>;
  /** 在全部邮件（含已发送、已归档）里搜索往来记录 */
  search(query: string, limit?: number): Promise<Email[]>;
  label(id: string, label: string): Promise<void>;
  archive(id: string): Promise<void>;
  saveDraft(d: Draft): Promise<OutMail>;
  /** 删掉 Solo 自己存的一份草稿（编号如 d3）。不是这个邮箱存的、或已经删过的，什么都不做 */
  discardDraft(id: string): Promise<void>;
  /** 真正发出。只会在老板批准后、或对外发送红线关闭时被调用 */
  send(d: Draft): Promise<OutMail>;
}

export interface Calendar {
  readonly source: string;
  /** 日期范围内的日程（YYYY-MM-DD，含首尾），按开始时间排序 */
  list(from?: string, to?: string): Promise<CalEvent[]>;
  /** 订一个时间段；有参会人时会发出邀请 */
  book(e: NewEvent): Promise<CalEvent>;
  /** 日历所在的时区（Google 是 IANA 名称如 Asia/Singapore；Outlook 可能是 Windows 名称）。日程的时间都是这个时区的当地时间 */
  timeZone(): Promise<string>;
}

/** 新日程和已有日程是否冲突（时间格式相同，直接比字符串） */
export function findClash(events: CalEvent[], e: { start: string; end: string }): CalEvent | undefined {
  return events.find((x) => !x.allDay && x.start < e.end && e.start < x.end);
}

/**
 * 模型有时会给带时区或秒的时间（2026-11-19T15:00+08:00、…Z、15:00:00）。
 * 统一换成日历时区里的“墙上时间” YYYY-MM-DDTHH:mm；本来就是这个格式的原样返回，认不出的也原样返回（交给 checkNewEvent 报错）。
 */
export function toWallTime(s: string, tz?: string): string {
  const v = s.trim();
  const m = /^(\d{4}-\d{2}-\d{2}T\d{2}:\d{2})(?::\d{2}(?:\.\d+)?)?(Z|[+-]\d{2}:?\d{2})?$/.exec(v);
  if (!m) return s;
  if (!m[2]) return m[1];
  const ms = Date.parse(v);
  if (Number.isNaN(ms)) return m[1];
  const fmt = (zone?: string) =>
    new Intl.DateTimeFormat('en-CA', { timeZone: zone, hourCycle: 'h23', year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit' });
  let f: Intl.DateTimeFormat;
  try {
    f = fmt(tz);
  } catch {
    f = fmt(); // 不是 IANA 名称（例如 Outlook 的 China Standard Time），按本机时区
  }
  const p = Object.fromEntries(f.formatToParts(new Date(ms)).map((x) => [x.type, x.value]));
  return `${p.year}-${p.month}-${p.day}T${p.hour}:${p.minute}`;
}

export function checkNewEvent(e: NewEvent): void {
  const re = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}$/;
  if (!re.test(e.start) || !re.test(e.end)) throw new Error('时间格式必须是 YYYY-MM-DDTHH:mm');
  if (!(e.start < e.end)) throw new Error('结束时间必须晚于开始时间');
}

/** 搜索词拆成几个词，全部出现才算命中（不分大小写） */
export function matchesAll(query: string, fields: Array<string | undefined>): boolean {
  const hay = fields.filter(Boolean).join('\n').toLowerCase();
  const words = query.toLowerCase().split(/\s+/).filter(Boolean);
  return words.length > 0 && words.every((w) => hay.includes(w));
}
