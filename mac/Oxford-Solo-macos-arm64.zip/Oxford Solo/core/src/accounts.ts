// 邮箱账号授权（Google、Microsoft）。用的是 OAuth 授权码 + PKCE：
// 老板在 Google / Microsoft 自己的登录页上登录并同意，Oxford Solo 只拿到授权令牌，永远看不到密码。
// 令牌保存在本机 ~/.oxford-solo/accounts.json（权限 600），不在项目文件夹里，也不会发给浏览器。
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import type { MailSource } from './connectors/types.js';
import { DEFAULT_HOME } from './credentials.js';
import { CodedError } from './i18n.js';

export type MailProvider = 'google' | 'microsoft';
export const MAIL_PROVIDERS: MailProvider[] = ['google', 'microsoft'];

/** 老板在 Google Cloud / Microsoft Entra 里登记的"应用"：Client ID（Google 还有 Client secret） */
export interface OAuthApp {
  clientId: string;
  clientSecret?: string;
  /** Microsoft 的租户：common（个人和工作账号都行）、organizations、consumers，或公司自己的租户 ID */
  tenant?: string;
}

export interface Account {
  /** 短 ID：g1、g2 是 Google 账号，o1、o2 是 Microsoft（Outlook）账号。邮件 ID 以它开头，例如 g2-m14 */
  id: string;
  provider: MailProvider;
  email: string;
  name?: string;
  refreshToken: string;
  accessToken?: string;
  /** 毫秒时间戳 */
  expiresAt?: number;
  scope?: string;
  connectedAt: string;
  /** 授权过期或被撤销，需要老板重新授权 */
  needsReauth?: boolean;
}

export interface AccountsFile {
  /** local = 示例数据；live = 同时用所有已连接的账号 */
  active: MailSource;
  /** 主邮箱：写新邮件默认从这里发，新日程默认订在这里 */
  primary?: string;
  apps: Partial<Record<MailProvider, OAuthApp>>;
  /** 按账号 ID 存，同一家可以连好几个账号 */
  accounts: Record<string, Account>;
}

/** 各家接口地址。测试时换成本机的假服务 */
export interface Endpoints {
  googleAuth: string;
  googleToken: string;
  googleRevoke: string;
  gmail: string;
  gcal: string;
  msLogin: string;
  graph: string;
}

export const REAL_ENDPOINTS: Endpoints = {
  googleAuth: 'https://accounts.google.com/o/oauth2/v2/auth',
  googleToken: 'https://oauth2.googleapis.com/token',
  googleRevoke: 'https://oauth2.googleapis.com/revoke',
  gmail: 'https://gmail.googleapis.com/gmail/v1/users/me',
  gcal: 'https://www.googleapis.com/calendar/v3',
  msLogin: 'https://login.microsoftonline.com',
  graph: 'https://graph.microsoft.com/v1.0',
};

/** 只要做事必需的权限：读写邮件、发邮件、读写日程 */
export const SCOPES: Record<MailProvider, string[]> = {
  google: ['https://www.googleapis.com/auth/gmail.modify', 'https://www.googleapis.com/auth/calendar.events'],
  microsoft: ['offline_access', 'User.Read', 'Mail.ReadWrite', 'Mail.Send', 'Calendars.ReadWrite', 'MailboxSettings.Read'],
};

const REQUIRED: Record<MailProvider, string[]> = {
  google: SCOPES.google,
  microsoft: ['Mail.ReadWrite', 'Mail.Send', 'Calendars.ReadWrite'],
};

/** 授权回调地址。Google 桌面应用用 127.0.0.1；Microsoft 登记的是 http://localhost（端口不参与匹配） */
export function redirectUri(provider: MailProvider, port: number): string {
  return provider === 'google' ? `http://127.0.0.1:${port}/oauth/google/callback` : `http://localhost:${port}/oauth/microsoft/callback`;
}

// ---------- 本机保存 ----------

const file = (home: string) => path.join(home, 'accounts.json');

// 打包给别人用的版本自带 Oxford Solo 自己的 OAuth 客户端（core/oauth-apps.json，由打包脚本写入，不进 git）。
// 新用户直接点"使用 Google 账号登录"即可，不用自己去 Google Cloud 登记应用。
// 桌面应用的 client secret 按 Google 的说明不算机密，但仍然只放在安装包里。开发目录里没有这个文件，行为不变。
const BUNDLED_APPS = new URL('../oauth-apps.json', import.meta.url);
function bundledApps(): AccountsFile['apps'] {
  try {
    const raw = JSON.parse(fs.readFileSync(BUNDLED_APPS, 'utf8')) as AccountsFile['apps'];
    const out: AccountsFile['apps'] = {};
    for (const p of MAIL_PROVIDERS) if (raw?.[p]?.clientId) out[p] = raw[p];
    return out;
  } catch {
    return {};
  }
}

export function loadAccounts(home = DEFAULT_HOME): AccountsFile {
  let raw: { active?: string; primary?: string; apps?: AccountsFile['apps']; accounts?: Record<string, Partial<Account>> };
  try {
    raw = JSON.parse(fs.readFileSync(file(home), 'utf8'));
  } catch {
    return { active: 'local', apps: bundledApps(), accounts: {} };
  }
  // 旧格式（每家只能连一个，按 google / microsoft 存）自动换成新格式
  const accounts: Record<string, Account> = {};
  for (const [key, a] of Object.entries(raw.accounts ?? {})) {
    if (!a?.provider || !a.refreshToken) continue;
    const id = a.id ?? (key === 'google' ? 'g1' : key === 'microsoft' ? 'o1' : key);
    accounts[id] = { ...(a as Account), id };
  }
  const legacyPrimary = raw.active === 'google' ? 'g1' : raw.active === 'microsoft' ? 'o1' : undefined;
  const ids = Object.keys(accounts);
  const primary = raw.primary && accounts[raw.primary] ? raw.primary : legacyPrimary && accounts[legacyPrimary] ? legacyPrimary : ids[0];
  const active: MailSource = raw.active === 'local' || !raw.active ? 'local' : 'live';
  return { active, primary, apps: { ...bundledApps(), ...(raw.apps ?? {}) }, accounts };
}

export function saveAccounts(d: AccountsFile, home = DEFAULT_HOME): void {
  fs.mkdirSync(home, { recursive: true, mode: 0o700 });
  const tmp = file(home) + '.' + process.pid + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(d, null, 2) + '\n', { mode: 0o600 });
  fs.renameSync(tmp, file(home));
  fs.chmodSync(file(home), 0o600);
}

export function updateAccounts(home: string, fn: (d: AccountsFile) => void): AccountsFile {
  const d = loadAccounts(home);
  fn(d);
  saveAccounts(d, home);
  return d;
}

/** 现在实际在用的数据来源：选了真实邮箱但一个账号都没连上，就退回示例数据 */
export function activeSource(home = DEFAULT_HOME): MailSource {
  const d = loadAccounts(home);
  return d.active === 'live' && Object.keys(d.accounts).length ? 'live' : 'local';
}

/** 已连接的账号，主邮箱排第一，其余按 ID */
export function liveAccounts(d: AccountsFile): Account[] {
  return Object.values(d.accounts).sort((a, b) => (a.id === d.primary ? -1 : b.id === d.primary ? 1 : a.id.localeCompare(b.id, 'en', { numeric: true })));
}

/** 授权成功后保存账号：同一家、同一个邮箱就更新令牌（ID 不变），否则编一个新 ID。返回账号 ID */
export function storeAccount(home: string, a: Omit<Account, 'id'>, app: OAuthApp): string {
  let id = '';
  updateAccounts(home, (d) => {
    const same = Object.values(d.accounts).find((x) => x.provider === a.provider && x.email.toLowerCase() === a.email.toLowerCase());
    const letter = a.provider === 'google' ? 'g' : 'o';
    const n = Math.max(0, ...Object.keys(d.accounts).filter((k) => k[0] === letter).map((k) => Number(k.slice(1)) || 0)) + 1;
    id = same?.id ?? letter + n;
    d.apps[a.provider] = app;
    d.accounts[id] = { ...a, id };
    d.active = 'live';
    if (!d.primary || !d.accounts[d.primary]) d.primary = id;
  });
  return id;
}

/** 给界面看的：不含任何令牌和 secret */
export function publicAccounts(home = DEFAULT_HOME) {
  const d = loadAccounts(home);
  const hint = (s?: string) => (s ? (s.length > 14 ? `${s.slice(0, 6)}…${s.slice(-6)}` : '…') : '');
  return {
    active: activeSource(home),
    primary: d.primary ?? '',
    accounts: liveAccounts(d).map((a) => ({
      id: a.id,
      provider: a.provider,
      email: a.email,
      name: a.name ?? '',
      connectedAt: a.connectedAt,
      needsReauth: Boolean(a.needsReauth),
      primary: a.id === d.primary,
    })),
    apps: Object.fromEntries(
      MAIL_PROVIDERS.map((p) => [p, { clientIdHint: hint(d.apps[p]?.clientId), hasSecret: Boolean(d.apps[p]?.clientSecret), tenant: d.apps[p]?.tenant ?? '' }]),
    ) as Record<MailProvider, { clientIdHint: string; hasSecret: boolean; tenant: string }>,
  };
}

// ---------- OAuth ----------

const b64url = (b: Buffer) => b.toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');

export function pkcePair(): { verifier: string; challenge: string } {
  const verifier = b64url(crypto.randomBytes(48));
  return { verifier, challenge: b64url(crypto.createHash('sha256').update(verifier).digest()) };
}

export const newState = () => b64url(crypto.randomBytes(24));

const tenantOf = (app: OAuthApp) => (app.tenant || 'common').replace(/[^A-Za-z0-9.-]/g, '') || 'common';

export function authUrl(provider: MailProvider, app: OAuthApp, o: { redirectUri: string; state: string; challenge: string; endpoints: Endpoints }): string {
  const u =
    provider === 'google'
      ? new URL(o.endpoints.googleAuth)
      : new URL(`${o.endpoints.msLogin}/${tenantOf(app)}/oauth2/v2.0/authorize`);
  const q = u.searchParams;
  q.set('client_id', app.clientId);
  q.set('response_type', 'code');
  q.set('redirect_uri', o.redirectUri);
  q.set('scope', SCOPES[provider].join(' '));
  q.set('state', o.state);
  q.set('code_challenge', o.challenge);
  q.set('code_challenge_method', 'S256');
  if (provider === 'google') {
    q.set('access_type', 'offline');
    // 每次都让老板选账号，才能连第二个、第三个 Google 账号
    q.set('prompt', 'select_account consent');
  } else {
    q.set('response_mode', 'query');
    q.set('prompt', 'select_account');
  }
  return u.toString();
}

interface TokenResponse {
  access_token: string;
  refresh_token?: string;
  expires_in?: number;
  scope?: string;
  error?: string;
  error_description?: string;
}

async function tokenRequest(provider: MailProvider, app: OAuthApp, params: Record<string, string>, endpoints: Endpoints): Promise<TokenResponse> {
  const url = provider === 'google' ? endpoints.googleToken : `${endpoints.msLogin}/${tenantOf(app)}/oauth2/v2.0/token`;
  const form = new URLSearchParams({ client_id: app.clientId, ...params });
  if (provider === 'google' && app.clientSecret) form.set('client_secret', app.clientSecret);
  if (provider === 'microsoft') form.set('scope', SCOPES.microsoft.join(' '));
  let res: Response;
  try {
    res = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded', Accept: 'application/json' }, body: form, signal: AbortSignal.timeout(30_000) });
  } catch (e) {
    throw new CodedError('mailNetwork', { msg: (e as Error).message });
  }
  const j = (await res.json().catch(() => ({}))) as TokenResponse;
  if (!res.ok || !j.access_token) {
    const why = [j.error, j.error_description].filter(Boolean).join(': ') || `HTTP ${res.status}`;
    if (j.error === 'invalid_grant') throw new CodedError('mailReauth', { msg: why });
    if (j.error === 'invalid_client' || j.error === 'unauthorized_client') throw new CodedError('mailBadClient', { msg: why });
    throw new CodedError('mailAuthFailed', { msg: why });
  }
  return j;
}

function checkScopes(provider: MailProvider, scope: string | undefined): void {
  if (!scope) return;
  const got = scope.split(/\s+/).map((s) => s.toLowerCase());
  const missing = REQUIRED[provider].filter((need) => !got.some((g) => g === need.toLowerCase() || g.endsWith('/' + need.toLowerCase())));
  if (missing.length) throw new CodedError('mailScopes', { list: missing.map((m) => m.replace(/^.*\//, '')).join(', ') });
}

/** 用授权码换令牌，再问一下这是谁的邮箱 */
export async function finishAuth(
  provider: MailProvider,
  app: OAuthApp,
  o: { code: string; verifier: string; redirectUri: string; endpoints: Endpoints },
): Promise<Omit<Account, 'id'>> {
  const tok = await tokenRequest(provider, app, { grant_type: 'authorization_code', code: o.code, code_verifier: o.verifier, redirect_uri: o.redirectUri }, o.endpoints);
  checkScopes(provider, tok.scope);
  if (!tok.refresh_token) throw new CodedError('mailAuthFailed', { msg: 'no refresh_token' });
  const who = await whoAmI(provider, tok.access_token, o.endpoints);
  return {
    provider,
    email: who.email,
    name: who.name,
    refreshToken: tok.refresh_token,
    accessToken: tok.access_token,
    expiresAt: Date.now() + (tok.expires_in ?? 3600) * 1000,
    scope: tok.scope,
    connectedAt: new Date().toISOString(),
  };
}

async function whoAmI(provider: MailProvider, token: string, endpoints: Endpoints): Promise<{ email: string; name?: string }> {
  const url = provider === 'google' ? `${endpoints.gmail}/profile` : `${endpoints.graph}/me?$select=displayName,mail,userPrincipalName`;
  const res = await fetch(url, { headers: { Authorization: `Bearer ${token}` }, signal: AbortSignal.timeout(30_000) });
  const j = (await res.json().catch(() => ({}))) as { emailAddress?: string; mail?: string; userPrincipalName?: string; displayName?: string; error?: { message?: string } };
  if (!res.ok) throw new CodedError('mailAuthFailed', { msg: j.error?.message ?? `HTTP ${res.status}` });
  const email = j.emailAddress ?? j.mail ?? j.userPrincipalName ?? '';
  if (!email) throw new CodedError('mailAuthFailed', { msg: 'no email address' });
  return { email, name: j.displayName };
}

/** 断开时顺手让 Google 作废令牌（Microsoft 没有对应接口，删掉本机令牌即可） */
export async function revokeAccount(a: Account, endpoints: Endpoints): Promise<void> {
  if (a.provider !== 'google') return;
  await fetch(endpoints.googleRevoke, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({ token: a.refreshToken }),
    signal: AbortSignal.timeout(15_000),
  }).catch(() => undefined);
}

/** 同一进程里，同一个账号同时只刷新一次令牌 */
const refreshing = new Map<string, Promise<string>>();

/** 取一个有效的访问令牌：快过期就用刷新令牌换新的，并写回本机 */
export class TokenSource {
  constructor(
    private home: string,
    readonly accountId: string,
    private endpoints: Endpoints,
  ) {}

  account(): Account {
    const a = loadAccounts(this.home).accounts[this.accountId];
    if (!a) throw new CodedError('mailNotConnected', { provider: this.accountId });
    return a;
  }

  async get(force = false): Promise<string> {
    const a = this.account();
    if (!force && a.accessToken && (a.expiresAt ?? 0) - 90_000 > Date.now()) return a.accessToken;
    const key = this.home + ':' + this.accountId;
    let p = refreshing.get(key);
    if (!p) {
      p = this.refresh(a).finally(() => refreshing.delete(key));
      refreshing.set(key, p);
    }
    return p;
  }

  private async refresh(a: Account): Promise<string> {
    const app = loadAccounts(this.home).apps[a.provider];
    if (!app) throw new CodedError('mailNotConnected', { provider: a.email });
    try {
      const tok = await tokenRequest(a.provider, app, { grant_type: 'refresh_token', refresh_token: a.refreshToken }, this.endpoints);
      updateAccounts(this.home, (d) => {
        const cur = d.accounts[this.accountId];
        if (!cur) return;
        cur.accessToken = tok.access_token;
        cur.expiresAt = Date.now() + (tok.expires_in ?? 3600) * 1000;
        if (tok.refresh_token) cur.refreshToken = tok.refresh_token;
        delete cur.needsReauth;
      });
      return tok.access_token;
    } catch (e) {
      if (e instanceof CodedError && e.code === 'mailReauth') {
        updateAccounts(this.home, (d) => {
          const cur = d.accounts[this.accountId];
          if (cur) cur.needsReauth = true;
        });
        throw new CodedError('mailReauth', { msg: `${a.email}: ${e.params.msg ?? ''}` });
      }
      throw e;
    }
  }
}
