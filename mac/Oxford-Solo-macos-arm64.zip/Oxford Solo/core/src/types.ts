// Oxford Solo 内核的共享类型

import type { Msg } from './i18n.js';

/** 可以开关的红线 */
export type RedlineRisk = 'external' | 'pay' | 'public';
/** decide = 需要老板拍板的事：不是红线，不能关，永远进决策台 */
export type Risk = RedlineRisk | 'decide';
export const RISKS: RedlineRisk[] = ['external', 'pay', 'public'];
export const RISK_LABEL: Record<Risk, string> = {
  external: '对外发送',
  pay: '付款与花钱',
  public: '公开发布',
  decide: '请老板拍板',
};

/** 一次模型调用的用量（字段与 Anthropic API 的 usage 一致） */
export interface Usage {
  input_tokens: number;
  output_tokens: number;
  cache_read_input_tokens?: number | null;
  cache_creation_input_tokens?: number | null;
  /** 哪个模型产生的用量，用来按价目表算钱；不填就是默认的 Claude 模型 */
  model?: string;
}

export interface Owner {
  name: string;
  company: string;
  /** 主邮箱 */
  email: string;
  /** 连接的全部邮箱（主邮箱在第一个）；只用示例数据时没有 */
  mailboxes?: string[];
  /** 某个邮箱属于另一家公司时，用它自己的署名（键是小写邮箱；没填的部分用上面的 name / company） */
  signatures?: Record<string, { name?: string; company?: string }>;
  /** 公司的工作语言：AI 的汇报、验收标准、MEMORY.md 都用它 */
  language?: string;
}

export interface Email {
  id: string;
  from: string;
  fromName: string;
  to: string;
  subject: string;
  date: string;
  body: string;
  labels: string[];
  unread: boolean;
  archived?: boolean;
  /** 收到这封邮件的是老板的哪个邮箱（连了好几个账号时才有） */
  account?: string;
}

export interface OutMail {
  id: string;
  to: string;
  subject: string;
  body: string;
  replyTo: string | null;
  createdAt: string;
  /** 通过哪个邮箱发出 / 存的草稿：local、google、microsoft */
  source?: string;
  /** 在 Gmail / Outlook 里的原始 ID */
  providerId?: string;
  /** 从老板哪个邮箱发出 */
  account?: string;
  /** 草稿被丢弃的时间（质检打回后删掉的半成品）。记录留着，编号不会被重复使用 */
  discarded?: string;
}

export interface Contact {
  id: string;
  name: string;
  company: string;
  email: string;
  stage: string;
  lastContact: string;
  lastProposal?: string | null;
  notes?: string;
}

export interface CalEvent {
  id: string;
  title: string;
  start: string;
  end: string;
  attendees: string[];
  location?: string;
  notes?: string;
  /** 全天日程（生日、休假等），不算时间冲突 */
  allDay?: boolean;
  /** 在老板哪个账号的日历上 */
  account?: string;
}

/** 总指挥开工前看到的公司现状 */
export interface Snapshot {
  today: string;
  owner: Owner;
  emails: Email[];
  contacts: Contact[];
  events: CalEvent[];
  /** 日历所在时区；读不到时没有 */
  timeZone?: string;
}

export interface BotDef {
  id: string;
  name: string;
  code: string;
  role: string;
  kinds: string[];
  tools: string[];
}

/** 拆解器产出的一个任务单元 */
export interface UnitPlan {
  id: string;
  bot: string;
  kind: string;
  title: string;
  detail: string;
  /** 这个单元针对的对象：邮件 ID、客户 ID 或日程 ID */
  ref: string | null;
  /** 只在需要上游单元的产出时填写；单元之间只传数据 */
  dependsOn: string[];
}

export type UnitState = 'queued' | 'running' | 'checking' | 'done' | 'awaiting' | 'failed' | 'skipped';

export interface Unit extends UnitPlan {
  state: UnitState;
  attempts: number;
  output: string;
  feedback: string[];
  approvals: string[];
  note?: string;
}

/** bot 调用一次工具的记录，交给质检看 */
export interface ActionRecord {
  tool: string;
  input: unknown;
  result: string;
  /** 动作产生的东西的编号，比如存下的草稿 d3；打回时用它把半成品删掉 */
  ref?: string;
  /** 碰到红线类别的动作不会马上执行，而是暂存；质检通过后才进决策台或自动执行 */
  staged?: { risk: Risk; summary: string; summaryMsg: Msg };
}

export interface Verdict {
  pass: boolean;
  reason: string;
  /** 打回时提炼的一条可复用规则；没有就是 null */
  rule: string | null;
}
