// 总指挥：一道指令从头到尾怎么跑
// 读现状 → 先写验收标准 → 拆成任务单元 → 每个单元派一个 bot，全部同时开工 → 质检逐个验收
// → 不合格的写成规则再重做（最多 3 次）→ 碰到红线的动作停在决策台 → 记账、存档
import { Approvals, type Approval } from './approvals.js';
import { BOTS } from './bots.js';
import { FIRST_ATTEMPT_ESTIMATE_USD, MAX_ATTEMPTS, MAX_PARALLEL, MAX_UNITS, todayISO } from './config.js';
import type { Endpoints } from './accounts.js';
import { makeDeps } from './connectors/index.js';
import { BrainError, type Brain } from './brain/types.js';
import { t, type Lang } from './i18n.js';
import { Ledger, type ActorCost } from './ledger.js';
import { Memory } from './memory.js';
import { buildSnapshot, snapshotText } from './snapshot.js';
import { TOOL_MAP, ToolBox } from './tools.js';
import type { ActionRecord, BotDef, Unit, UnitState } from './types.js';
import type { Workspace } from './workspace.js';

export type RunEvent =
  | { type: 'start'; runId: string; instruction: string; mode: string; model: string; budgetUsd: number }
  | { type: 'context'; emails: number; unread: number; contacts: number; events: number; rules: number }
  | { type: 'criteria'; criteria: string[] }
  | { type: 'split'; units: Unit[]; dropped: string[] }
  | { type: 'unit'; unit: Unit; state: UnitState; text?: string; spentUsd: number }
  | { type: 'rejected'; unit: Unit; reason: string; attempt: number }
  | { type: 'rule'; text: string }
  | { type: 'approval'; approval: Approval }
  | { type: 'budget'; spentUsd: number; budgetUsd: number }
  | { type: 'error'; unitId?: string; message: string }
  | { type: 'done'; report: RunReport };

export interface RunReport {
  runId: string;
  instruction: string;
  mode: string;
  lang: Lang;
  today: string;
  criteria: string[];
  units: Unit[];
  counts: Record<UnitState, number> & { rejections: number };
  costUsd: number;
  budgetUsd: number;
  stoppedByBudget: boolean;
  byActor: Record<string, ActorCost>;
  approvals: Approval[];
  rulesAdded: string[];
  /** 致命错误（例如 API key 无效）导致整次运行停下时的原因 */
  fatalError: string | null;
  /** 这次运行里最多有几个 bot 同时在干活 */
  peakParallel: number;
}

export interface RunOptions {
  instruction: string;
  brain: Brain;
  ws: Workspace;
  today?: string;
  /** 不填就用 MEMORY.md 里的预算 */
  budgetUsd?: number;
  bots?: BotDef[];
  /** 工作语言；不填就用 profile.json 里的 */
  lang?: Lang;
  onEvent?: (e: RunEvent) => void;
  /** 邮箱授权保存的目录（默认 ~/.oxford-solo）和接口地址（测试用） */
  home?: string;
  endpoints?: Endpoints;
  /** 同时开工的 bot 数，不填用 MAX_PARALLEL */
  parallel?: number;
}

/** 先到先得的名额：最多 n 个同时进行 */
class Slots {
  private used = 0;
  private waiters: Array<() => void> = [];
  peak = 0;
  constructor(private n: number) {}
  async run<T>(fn: () => Promise<T>): Promise<T> {
    if (this.used >= this.n) await new Promise<void>((r) => this.waiters.push(r));
    else this.used++;
    this.peak = Math.max(this.peak, this.used);
    try {
      return await fn();
    } finally {
      const next = this.waiters.shift();
      if (next) next();
      else this.used--;
    }
  }
}

/** 外发邮件“回的是哪一封”：回复看原邮件 ID，新邮件看收件人加主题。别的动作返回 undefined */
export function replyKey(a: { tool: string; input: unknown }): string | undefined {
  if (a.tool !== 'mail_send') return undefined;
  const i = (a.input ?? {}) as { replyTo?: string | null; to?: string; subject?: string };
  return i.replyTo ? `reply:${i.replyTo}` : `new:${String(i.to ?? '').toLowerCase()}|${i.subject ?? ''}`;
}

export async function runInstruction(o: RunOptions): Promise<RunReport> {
  const ws = o.ws.ensure();
  const today = o.today ?? todayISO();
  const lang: Lang = o.lang ?? ws.language();
  const bots = o.bots ?? BOTS;
  const botMap = new Map(bots.map((b) => [b.id, b]));
  const runId = 'R' + new Date().toISOString().replace(/\D/g, '').slice(0, 14) + '-' + Math.random().toString(36).slice(2, 6);
  // 模拟运行只用示例数据，不碰真实邮箱
  const deps = makeDeps(ws, today, { home: o.home, endpoints: o.endpoints, source: o.brain.mode === 'mock' ? 'local' : undefined });
  const memory = new Memory(ws);
  const approvals = new Approvals(ws);
  const ledger = new Ledger(ws, runId, o.brain.mode);
  const budgetUsd = o.budgetUsd ?? memory.data.budgetUsd;
  const events: RunEvent[] = [];
  const emit = (e: RunEvent) => {
    events.push(e);
    o.onEvent?.(e);
  };

  emit({ type: 'start', runId, instruction: o.instruction, mode: o.brain.mode, model: o.brain.label, budgetUsd });

  // 1. 读现状
  const snapshot = await buildSnapshot(deps);
  const text = snapshotText(snapshot);
  emit({
    type: 'context',
    emails: snapshot.emails.length,
    unread: snapshot.emails.filter((e) => e.unread).length,
    contacts: snapshot.contacts.length,
    events: snapshot.events.length,
    rules: memory.activeRules().length,
  });

  // 2. 先写验收标准，再动手
  const crit = await o.brain.writeCriteria({ lang, instruction: o.instruction, snapshotText: text, rules: memory.activeRules() });
  ledger.add('orchestrator', crit.usage);
  const criteria = crit.value;
  emit({ type: 'criteria', criteria });

  // 3. 拆成任务单元
  const plan = await o.brain.split({
    lang,
    instruction: o.instruction,
    snapshotText: text,
    rules: memory.activeRules(),
    criteria,
    snapshot,
    bots,
    maxUnits: MAX_UNITS,
  });
  ledger.add('orchestrator', plan.usage);
  const dropped: string[] = [];
  const units: Unit[] = [];
  const seen = new Set<string>();
  for (const p of plan.value.slice(0, MAX_UNITS)) {
    if (!botMap.has(p.bot)) {
      dropped.push(t(lang, 'note.dropped', { id: p.id, bot: p.bot }));
      continue;
    }
    const id = seen.has(p.id) ? `${p.id}-${units.length + 1}` : p.id;
    seen.add(id);
    units.push({ ...p, id, state: 'queued', attempts: 0, output: '', feedback: [], approvals: [] });
  }
  // 依赖只能指向排在前面的单元：这样按顺序执行永远不会互相卡死
  const order = new Map(units.map((u, i) => [u.id, i]));
  units.forEach((u, i) => {
    u.dependsOn = (u.dependsOn ?? []).filter((d) => (order.get(d) ?? Infinity) < i);
  });
  emit({ type: 'split', units, dropped });

  // 4. 每个单元派一个 bot，全部同时开工；有依赖的等上游做完再开始
  const byId = new Map(units.map((u) => [u.id, u]));
  const settle = new Map<string, () => void>();
  const finished = new Map(units.map((u) => [u.id, new Promise<void>((r) => settle.set(u.id, r))]));
  let rejections = 0;
  let stoppedByBudget = false;
  /** 这次运行里已经自动发出的邮件（红线关闭时）：回复对象 → 哪个单元发的 */
  const autoSent = new Map<string, string>();
  let fatal: string | null = null;
  const rulesAdded: string[] = [];
  // 预算：上百个 bot 同时开工时，先按「一次尝试的平均花费」预留，免得大家一起开工把预算冲破
  let reserved = 0;
  let attemptsDone = 0;
  let attemptsCost = 0;
  const estimate = () => (attemptsDone ? attemptsCost / attemptsDone : FIRST_ATTEMPT_ESTIMATE_USD);

  const setState = (u: Unit, state: UnitState, note?: string) => {
    u.state = state;
    if (note) u.note = note;
    emit({ type: 'unit', unit: u, state, text: note, spentUsd: ledger.total });
  };

  async function processUnit(u: Unit): Promise<void> {
    const bot = botMap.get(u.bot)!;
    const upstream = u.dependsOn.map((d) => byId.get(d)!);
    if (upstream.some((d) => d.state === 'failed' || d.state === 'skipped')) {
      setState(u, 'skipped', t(lang, 'note.upstream'));
      return;
    }
    for (let attempt = 1; attempt <= MAX_ATTEMPTS; attempt++) {
      if (fatal) return setState(u, 'skipped', fatal);
      const est = estimate();
      if (ledger.total >= budgetUsd || (reserved > 0 && ledger.total + reserved + est > budgetUsd)) {
        if (!stoppedByBudget) {
          stoppedByBudget = true;
          emit({ type: 'budget', spentUsd: ledger.total, budgetUsd });
        }
        return setState(u, 'skipped', t(lang, 'note.budget'));
      }
      u.attempts = attempt;
      reserved += est;
      let spent = 0;
      try {
      setState(u, 'running');
      const actions: ActionRecord[] = [];
      const tools = new ToolBox({ lang, deps, memory, unit: u, bot, actions });
      const exec = await o.brain.execute({
        lang,
        unit: u,
        bot,
        owner: deps.owner,
        today,
        criteria,
        rules: memory.activeRules(),
        depOutputs: upstream.map((d) => ({ id: d.id, title: d.title, output: d.output })),
        tools,
      });
      spent += ledger.add(bot.id, exec.usage);

      setState(u, 'checking');
      const v = await o.brain.verify({ lang, today, unit: u, bot, output: exec.value, actions, criteria, rules: memory.activeRules(), owner: deps.owner });
      spent += ledger.add('check', v.usage);
      if (v.value.pass) {
        // 质检通过，暂存的对外动作才往前走：红线打开的进决策台，关闭的自动执行
        const created: Approval[] = [];
        const executed: string[] = [];
        // 同一封邮件只回一次：别的单元（或之前的运行）已经有回复在决策台上、或这次已经自动发过，就不再提交
        const twins: string[] = [];
        for (const a of actions.filter((x) => x.staged)) {
          const staged = a.staged!;
          const key = replyKey(a);
          if (memory.redlineOn(staged.risk)) {
            const twin = key ? approvals.pending().find((p) => replyKey(p) === key) : undefined;
            if (twin) {
              twins.push(twin.id);
              continue;
            }
            created.push(
              approvals.create({ runId, unitId: u.id, bot: bot.id, source: deps.source, tool: a.tool, risk: staged.risk, input: a.input as Record<string, unknown>, summary: staged.summary, summaryMsg: staged.summaryMsg }),
            );
          } else {
            if (key && autoSent.has(key)) {
              twins.push(autoSent.get(key)!);
              continue;
            }
            if (key) autoSent.set(key, u.id);
            try {
              executed.push(`${staged.summary} → ${await TOOL_MAP[a.tool].run(a.input, deps)}`);
            } catch (e) {
              executed.push(`${staged.summary} → ${t(lang, 'note.execFailed', { msg: (e as Error).message })}`);
            }
          }
        }
        u.output = exec.value;
        u.approvals = created.map((a) => a.id);
        setState(
          u,
          created.length ? 'awaiting' : 'done',
          v.value.reason +
            (executed.length ? t(lang, 'note.autoExec', { list: executed.join(t(lang, 'sep.list')) }) : '') +
            (twins.length ? t(lang, 'note.dupReply', { id: twins.join(t(lang, 'sep.list')) }) : ''),
        );
        for (const ap of created) emit({ type: 'approval', approval: ap });
        return;
      }
      // 打回：暂存的对外动作直接丢弃，这次存进邮箱的草稿也删掉（免得老板邮箱里留一堆半成品），
      // 原因带进下一次，能复用的教训写进 MEMORY.md
      for (const a of actions) {
        if (a.tool === 'mail_draft' && a.ref) await deps.mailbox.discardDraft(a.ref).catch(() => undefined);
      }
      u.feedback.push(v.value.reason);
      rejections++;
      emit({ type: 'rejected', unit: u, reason: v.value.reason, attempt });
      if (v.value.rule && memory.addRule(v.value.rule, t(lang, 'src.check', { id: u.id, kind: u.kind }))) {
        rulesAdded.push(v.value.rule);
        emit({ type: 'rule', text: v.value.rule });
      }
      } finally {
        reserved -= est;
        attemptsDone++;
        attemptsCost += spent;
      }
    }
    setState(u, 'failed', t(lang, 'note.failed', { n: MAX_ATTEMPTS }));
  }

  // 先打样：每类 bot 的第一个单元先做，质检打回学到的规则写进 MEMORY.md 后，同类的其余单元再一起开工。
  // 不然上百个 bot 会同时犯同一个错，一起被打回重做，白花钱。
  const pilot = new Map<string, string>();
  for (const u of units) if (!pilot.has(u.bot)) pilot.set(u.bot, u.id);
  // 依赖和打样都只指向排在前面的单元，名额又是先到先得，所以不会互相卡死；等待中的单元不占名额
  const slots = new Slots(Math.max(1, o.parallel ?? MAX_PARALLEL));
  await Promise.all(
    units.map(async (u) => {
      try {
        const first = pilot.get(u.bot)!;
        await Promise.all([...u.dependsOn, ...(first === u.id ? [] : [first])].map((d) => finished.get(d)));
        await slots.run(() => processUnit(u));
      } catch (e) {
        const message = (e as Error).message;
        if (e instanceof BrainError && e.fatal) fatal = message;
        setState(u, 'failed', message);
        emit({ type: 'error', unitId: u.id, message });
      } finally {
        settle.get(u.id)!();
      }
    }),
  );

  // 5. 记账、存档
  ledger.persist();
  const counts = { queued: 0, running: 0, checking: 0, done: 0, awaiting: 0, failed: 0, skipped: 0, rejections };
  for (const u of units) counts[u.state]++;
  const report: RunReport = {
    runId,
    instruction: o.instruction,
    mode: o.brain.mode,
    lang,
    today,
    criteria,
    units,
    counts,
    costUsd: ledger.total,
    budgetUsd,
    stoppedByBudget,
    byActor: Object.fromEntries(ledger.byActor),
    approvals: units.flatMap((u) => u.approvals.map((id) => approvals.get(id))),
    rulesAdded,
    fatalError: fatal,
    peakParallel: slots.peak,
  };
  emit({ type: 'done', report });
  ws.writeJson(`runs/${runId}.json`, {
    report,
    events: events.map((e) => (e.type === 'unit' ? { type: e.type, unit: e.unit.id, state: e.state, text: e.text } : e.type === 'split' || e.type === 'done' ? { type: e.type } : e)),
  });
  return report;
}
