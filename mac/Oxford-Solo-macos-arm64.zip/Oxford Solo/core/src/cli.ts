// Oxford Solo 命令行：./solo <命令>
import { parseArgs } from 'node:util';
import { Approvals, type Approval } from './approvals.js';
import { BOT_MAP } from './bots.js';
import { makeBrain, resolveChoice } from './brain/pick.js';
import type { Brain } from './brain/types.js';
import { DEFAULT_PORT, DEFAULT_WORKSPACE, todayISO } from './config.js';
import { makeDeps } from './connectors/index.js';
import type { LedgerRun } from './ledger.js';
import { Memory } from './memory.js';
import { fmt, isLang, LANGS, normalizeLang, t, type Lang } from './i18n.js';
import { narrate, type LogKind } from './narrate.js';
import { runInstruction, type RunEvent, type RunReport } from './orchestrator.js';
import { startServer } from './server.js';
import { RISK_LABEL, RISKS, type RedlineRisk, type Risk } from './types.js';
import { Workspace, companyWorkspace } from './workspace.js';
import { activeSource } from './accounts.js';
import { DEFAULT_HOME } from './credentials.js';

const tty = process.stdout.isTTY && !process.env.NO_COLOR;
const paint = (code: string) => (s: string) => (tty ? `\x1b[${code}m${s}\x1b[0m` : s);
const c = { dim: paint('2'), bold: paint('1'), red: paint('31'), green: paint('32'), gold: paint('33'), blue: paint('34'), cyan: paint('36') };
const usd = (n: number) => '$' + n.toFixed(n < 0.01 && n > 0 ? 4 : 2);
const pad = (s: string, n: number) => s + ' '.repeat(Math.max(0, n - [...s].reduce((w, ch) => w + (ch.charCodeAt(0) > 0x2e80 ? 2 : 1), 0)));


const HELP = `${c.bold('Oxford Solo 内核')}  一人成军

用法：./solo <命令> [参数]

  serve                   打开网页界面（默认 http://localhost:${DEFAULT_PORT}），可加 --port
  run [指令]              下一道指令，让 AI 公司跑起来（不写指令就用默认的"把这周跑起来"）
      --mock              离线模拟模式：不联网、不花钱
      --real              强制用真实模型（需要 ANTHROPIC_API_KEY 或 OPENAI_API_KEY）
      --budget <美元>     这次运行的预算上限，默认读 MEMORY.md
  desk                    决策台：列出等你批准的事，含邮件全文
  approve <编号|all>      批准，例如 approve A001；可加 --body "改过的正文"
  reject <编号>           驳回；加 --rule "规则" 可顺手记成规则
  rules                   查看 MEMORY.md（红线、预算、规则）
  rule "<规则>"           手动加一条规则
  redline <类别> on|off   开关红线，类别：external（对外发送）、pay（付款）、public（公开发布）
  budget <美元>           设置每次运行的预算上限
  ledger                  账本：每次运行、每个 bot 花了多少钱
  mail                    看邮箱：已发出、草稿、收件箱标签
  lang <语言>             设置公司的工作语言：zh-CN zh-TW en ja ko vi（AI 汇报、验收标准、MEMORY.md 都跟着换）
  reset                   清空工作区，恢复成示例数据

  所有命令都可以加 --lang <语言>，只改这一次的日志语言

工作区：${DEFAULT_WORKSPACE}`;

function pickBrain(flags: { mock?: boolean; real?: boolean }): Brain {
  if (flags.mock) return makeBrain('mock');
  const choice = resolveChoice();
  if (choice.provider !== 'mock') return makeBrain(choice);
  if (flags.real) throw new Error('没有找到 API key。设置 ANTHROPIC_API_KEY（Claude）或 OPENAI_API_KEY（OpenAI）后再运行');
  console.log(c.gold('没有找到 API key，这次用离线模拟模式运行（不联网、不花钱）。'));
  console.log(c.dim('接入真实模型：运行 ./solo serve，在网页右上角点"连接模型"填入 key；或设置 ANTHROPIC_API_KEY / OPENAI_API_KEY。\n'));
  return makeBrain('mock');
}

const KIND_COLOR: Record<LogKind, (s: string) => string> = {
  you: c.gold,
  rule: c.gold,
  desk: c.gold,
  orch: c.bold,
  check: c.green,
  split: c.blue,
  bot: c.cyan,
  bad: c.red,
  dim: c.dim,
};

let LANG: Lang = 'zh-CN';
const sum = (a: Approval) => (a.summaryMsg ? fmt(LANG, a.summaryMsg) : a.summary);
const actorName = (k: string) => (BOT_MAP[k] ? t(LANG, 'bot.' + k) : k === 'orchestrator' ? t(LANG, 'log.who.orch') : k === 'check' ? t(LANG, 'log.who.check') : k);

function eventPrinter(): (e: RunEvent) => void {
  const t0 = Date.now();
  return (e) => {
    if (e.type === 'done') return; // 结尾由 printReport 汇总
    const s = Math.floor((Date.now() - t0) / 1000);
    const time = c.dim(`${String(Math.floor(s / 60)).padStart(2, '0')}:${String(s % 60).padStart(2, '0')}`);
    for (const l of narrate(e)) {
      console.log(`${time}  ${KIND_COLOR[l.kind](pad(fmt(LANG, l.who), 16))}${fmt(LANG, l.msg)}`);
      l.sub?.forEach((x, i) => console.log(c.dim(`${' '.repeat(23)}${i + 1}. `) + x));
    }
  };
}

function printReport(r: RunReport): void {
  const k = r.counts;
  console.log('\n' + c.bold('━━━━ 本次运行结束 ━━━━'));
  console.log(
    `完成 ${c.green(String(k.done))} · 等你批准 ${c.gold(String(k.awaiting))} · 失败 ${k.failed ? c.red(String(k.failed)) : 0} · 跳过 ${k.skipped} · 打回 ${k.rejections} 次 · 新规则 ${r.rulesAdded.length} 条`,
  );
  console.log(`花费 ${usd(r.costUsd)}${r.mode === 'mock' ? '（离线模拟，没有真实费用）' : r.mode === 'openai' ? '（OpenAI 按价目估算）' : ''} / 预算 ${usd(r.budgetUsd)}${r.stoppedByBudget ? c.red(' · 因预算停止派发') : ''}`);
  if (r.fatalError) console.log(c.red(`运行中止：${r.fatalError}`));
  const pending = r.approvals.filter((a) => a.status === 'pending');
  if (pending.length) {
    console.log('\n' + c.gold(`决策台有 ${pending.length} 件事等你拍板：`));
    pending.forEach((a) => console.log(`  ${c.bold(a.id)}  ${pad(t(LANG, 'risk.' + a.risk), 10)}${sum(a)}`));
    const id = pending[0].id;
    console.log(c.dim(`\n看全文：./solo desk    批准：./solo approve ${id}    驳回并记规则：./solo reject ${id} --rule "……"`));
  }
}

function printApproval(a: Approval): void {
  const b = BOT_MAP[a.bot];
  console.log(`${c.bold(a.id)}  ${c.gold(RISK_LABEL[a.risk])}  ${b ? b.name : a.bot} · ${a.unitId} · ${a.tool}`);
  console.log(`  ${sum(a)}`);
  if (typeof a.input.body === 'string') {
    console.log(c.dim('  ┌ 正文'));
    for (const l of a.input.body.split('\n')) console.log(c.dim('  │ ') + l);
    console.log(c.dim('  └'));
  }
}

async function main(): Promise<void> {
  const { values: flags, positionals } = parseArgs({
    allowPositionals: true,
    options: {
      mock: { type: 'boolean' },
      real: { type: 'boolean' },
      budget: { type: 'string' },
      body: { type: 'string' },
      rule: { type: 'string' },
      port: { type: 'string' },
      lang: { type: 'string' },
      help: { type: 'boolean', short: 'h' },
    },
  });
  const [cmd = 'help', ...rest] = positionals;
  // 用真实邮箱时，命令行也操作老板自己的公司；离线模拟（--mock）永远用示例公司
  const live = activeSource() === 'live' && !flags.mock;
  const ws = (live ? companyWorkspace(DEFAULT_HOME) : new Workspace(DEFAULT_WORKSPACE)).ensure();
  const today = todayISO();
  LANG = normalizeLang(flags.lang ?? process.env.SOLO_LANG) ?? ws.language();

  switch (cmd) {
    case 'serve': {
      const port = flags.port ? Number(flags.port) : DEFAULT_PORT;
      // 网页服务器自己在示例公司和真实公司之间切换，这里永远交给它示例公司；
      // 交成真实公司的话，断开最后一个邮箱、退回示例数据时会去真实公司里找示例邮件
      const sample = new Workspace(DEFAULT_WORKSPACE).ensure();
      const { url, mode, model } = await startServer({ ws: sample, today: process.env.SOLO_TODAY, port });
      console.log(`${c.bold('Oxford Solo')} 网页界面已打开：${c.cyan(url)}`);
      console.log(c.dim(mode === 'mock' ? '模式：离线模拟（没有找到 ANTHROPIC_API_KEY 或 OPENAI_API_KEY）' : `模式：${model}`));
      console.log(c.dim('只在本机可以访问。按 Ctrl+C 关闭。'));
      return;
    }
    case 'run': {
      const instruction = rest.join(' ').trim() || t(ws.language(), 'cmd.default');
      const brain = pickBrain(flags);
      const report = await runInstruction({
        instruction,
        brain,
        ws,
        today,
        budgetUsd: flags.budget ? Number(flags.budget) : undefined,
        onEvent: eventPrinter(),
      });
      printReport(report);
      if (report.fatalError) process.exitCode = 1;
      break;
    }
    case 'desk': {
      const list = new Approvals(ws).pending();
      if (!list.length) return console.log('决策台是空的：没有等你拍板的事。');
      console.log(c.gold(`决策台：${list.length} 件事等你拍板\n`));
      list.forEach((a) => {
        printApproval(a);
        console.log('');
      });
      const id = list[0].id;
      console.log(c.dim(`批准：./solo approve ${id}（可加 --body "改过的正文"）  全部批准：./solo approve all  驳回：./solo reject ${id} --rule "……"`));
      break;
    }
    case 'approve': {
      const approvals = new Approvals(ws);
      const ids = rest[0] === 'all' ? approvals.pending().map((a) => a.id) : rest;
      if (!ids.length) throw new Error('要批准哪一件？例如 ./solo approve A001');
      for (const id of ids) {
        const a = await approvals.approve(id, (source) => makeDeps(ws, today, { source }), { body: flags.body });
        console.log(`${c.green('已批准')} ${a.id}：${sum(a)} → ${a.result}`);
      }
      break;
    }
    case 'reject': {
      if (!rest[0]) throw new Error('要驳回哪一件？例如 ./solo reject A001 --rule "……"');
      const a = new Approvals(ws).reject(rest[0], { rule: flags.rule, memory: new Memory(ws), lang: ws.language() });
      console.log(`${c.red('已驳回')} ${a.id}：${sum(a)}${flags.rule ? `\n${c.gold('MEMORY.md')} 新规则：${flags.rule}` : ''}`);
      break;
    }
    case 'rules':
      console.log(ws.readText('MEMORY.md'));
      break;
    case 'rule': {
      const text = rest.join(' ').trim();
      if (!text) throw new Error('规则内容是空的，例如 ./solo rule "周一上午不发对外邮件"');
      console.log(new Memory(ws).addRule(text, t(ws.language(), 'src.cli')) ? `已写入 MEMORY.md：${text}` : '这条规则已经有了。');
      break;
    }
    case 'redline': {
      const [key, onoff] = rest as [RedlineRisk, string];
      if (!RISKS.includes(key) || !['on', 'off'].includes(onoff)) throw new Error('用法：./solo redline external|pay|public on|off');
      new Memory(ws).setRedline(key, onoff === 'on');
      console.log(`红线「${RISK_LABEL[key]}」已${onoff === 'on' ? '打开：这类动作会先停在决策台' : c.red('关闭：这类动作 AI 会直接执行')}`);
      break;
    }
    case 'budget': {
      const n = Number(rest[0]);
      if (!(n > 0)) throw new Error('用法：./solo budget 3（美元）');
      new Memory(ws).setBudget(n);
      console.log(`每次运行的预算上限已设为 ${usd(n)}`);
      break;
    }
    case 'ledger': {
      const runs = ws.readJson<{ runs: LedgerRun[] }>('ledger.json').runs;
      if (!runs.length) return console.log('账本是空的：还没有运行过。');
      let total = 0;
      for (const r of runs) {
        total += r.totalUsd;
        const parts = Object.entries(r.byActor).map(([k, v]) => `${actorName(k)} ${usd(v.usd)}`);
        console.log(`${r.at.slice(0, 16).replace('T', ' ')}  ${pad(r.mode === 'mock' ? '模拟' : r.mode === 'openai' ? 'OpenAI' : 'Claude', 8)}${pad(usd(r.totalUsd), 10)}${c.dim(parts.join(' · '))}`);
      }
      console.log(c.bold(`合计 ${usd(total)}，共 ${runs.length} 次运行`));
      break;
    }
    case 'mail': {
      const deps = makeDeps(ws, today);
      const sent = deps.outbox.sent();
      console.log(c.bold(`已发出（${sent.length}）`));
      sent.forEach((m) => console.log(`  ${m.id}  → ${m.to}  「${m.subject}」`));
      const drafts = deps.outbox.drafts();
      console.log(c.bold(`\n草稿（${drafts.length}）`));
      drafts.forEach((m) => console.log(`  ${m.id}  → ${m.to}  「${m.subject}」`));
      console.log(c.bold(`\n收件箱（${deps.source === 'local' ? '示例数据' : deps.owner.email}）`));
      (await deps.mailbox.list({ includeArchived: deps.source === 'local' })).forEach((e) =>
        console.log(`  ${e.id}  ${e.archived ? c.dim('已归档') : e.unread ? c.gold('未读  ') : '已读  '}  ${pad(e.labels.join(',') || '-', 22)}${e.subject}`),
      );
      break;
    }
    case 'lang': {
      const want = rest[0];
      if (!isLang(want)) throw new Error(`用法：./solo lang ${LANGS.join('|')}`);
      ws.setLanguage(want);
      new Memory(ws).setLanguage(want);
      console.log(`公司的工作语言已设为 ${t(want, '_lang.name')}。AI 的汇报、验收标准和 MEMORY.md 之后都用这种语言。`);
      break;
    }
    case 'reset':
      if (ws.kind === 'company') throw new Error('现在用的是真实邮箱：真实公司的数据不能一键清空。要恢复示例数据，先在网页的"连接邮箱"窗口改用示例数据。');
      ws.reset();
      console.log(`工作区已恢复成示例数据：${ws.dir}`);
      break;
    default:
      console.log(HELP);
  }
}

main().catch((e: Error) => {
  console.error(c.red('出错：') + e.message);
  process.exitCode = 1;
});
