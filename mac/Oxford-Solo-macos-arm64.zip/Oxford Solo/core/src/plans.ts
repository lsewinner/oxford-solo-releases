// 付费等级和授权凭证：桌面应用和账号服务器（server/）共用这一份，所以这里不能引用 Node 专有的模块。
//
// 等级只管两件事：能连几个邮箱、能用哪些功能。AI 的费用由老板自己的 API key 付，跟等级无关。
// 有效等级 = 管理员授权、Stripe 订阅、试用期里最高的那个；账号被停用时什么都没有。

export const PLAN_IDS = ['none', 'trial', 'personal', 'pro', 'team'] as const;
export type PlanId = (typeof PLAN_IDS)[number];
/** 能买、能被管理员授予的等级（试用由注册自动开始，none 表示没有可用等级） */
export const PAID_PLANS = ['personal', 'pro', 'team'] as const;
export type PaidPlan = (typeof PAID_PLANS)[number];
export const INTERVALS = ['month', 'year'] as const;
export type Interval = (typeof INTERVALS)[number];

export interface PlanLimits {
  /** 能连接的真实邮箱数量（Gmail / Outlook 合计） */
  mailboxes: number;
  /** 能不能用真实邮箱运行（none 只能用示例数据体验） */
  liveRuns: boolean;
  /** 会议准备 bot 能不能直接在日历上订会（有外部参会人时仍然先进决策台） */
  calendarBooking: boolean;
  /** 能管几家公司（多公司功能上线前只用到 1） */
  companies: number;
}

export const PLANS: Record<PlanId, PlanLimits & { rank: number }> = {
  none: { rank: 0, mailboxes: 0, liveRuns: false, calendarBooking: false, companies: 0 },
  trial: { rank: 1, mailboxes: 3, liveRuns: true, calendarBooking: true, companies: 1 },
  personal: { rank: 2, mailboxes: 1, liveRuns: true, calendarBooking: false, companies: 1 },
  pro: { rank: 3, mailboxes: 3, liveRuns: true, calendarBooking: true, companies: 1 },
  team: { rank: 4, mailboxes: 10, liveRuns: true, calendarBooking: true, companies: 5 },
};

export const TRIAL_DAYS = 14;
/** Stripe 扣款失败后，付费等级还保留几天（Stripe 会自动重试扣款） */
export const PAST_DUE_GRACE_DAYS = 7;
/** 桌面应用离线时，上次拿到的授权凭证还能用几天 */
export const ENTITLEMENT_OFFLINE_DAYS = 7;

export const isPlan = (v: unknown): v is PlanId => typeof v === 'string' && (PLAN_IDS as readonly string[]).includes(v);
export const isPaidPlan = (v: unknown): v is PaidPlan => typeof v === 'string' && (PAID_PLANS as readonly string[]).includes(v);

/** 算有效等级要用到的账号字段（服务器数据库里的一行） */
export interface PlanFacts {
  status: 'active' | 'suspended';
  trialEndsAt: string | null;
  subPlan: string | null;
  subStatus: string | null;
  subPeriodEnd: string | null;
  grantPlan: string | null;
  /** 管理员授权到哪天为止；null 表示长期有效 */
  grantUntil: string | null;
}

export type PlanSource = 'grant' | 'subscription' | 'trial' | 'none' | 'suspended';
export interface Effective {
  plan: PlanId;
  source: PlanSource;
  /** 这个等级到什么时候为止（长期授权为 null） */
  until: string | null;
}

const DAY = 86_400_000;
const LIVE_SUB = ['active', 'trialing', 'past_due'];

export function effectivePlan(f: PlanFacts, now = new Date()): Effective {
  if (f.status === 'suspended') return { plan: 'none', source: 'suspended', until: null };
  const t = now.getTime();
  const after = (iso: string | null, graceDays = 0) => !!iso && Date.parse(iso) + graceDays * DAY > t;
  const options: Effective[] = [];
  if (isPaidPlan(f.grantPlan) && (f.grantUntil === null || after(f.grantUntil))) options.push({ plan: f.grantPlan, source: 'grant', until: f.grantUntil });
  if (isPaidPlan(f.subPlan) && LIVE_SUB.includes(f.subStatus ?? '') && after(f.subPeriodEnd, f.subStatus === 'past_due' ? PAST_DUE_GRACE_DAYS : 1))
    options.push({ plan: f.subPlan, source: 'subscription', until: f.subPeriodEnd });
  if (after(f.trialEndsAt)) options.push({ plan: 'trial', source: 'trial', until: f.trialEndsAt });
  options.sort((a, b) => PLANS[b.plan].rank - PLANS[a.plan].rank);
  return options[0] ?? { plan: 'none', source: 'none', until: null };
}

// ---------- 授权凭证：服务器用私钥签名，桌面应用用公钥验证，离线时也能用几天 ----------

/** 账号服务器签名用的 Ed25519 公钥（SPKI，base64）。私钥在 ~/.oxford-solo/admin/entitlement-key.json（只给 Cloudflare secret 用） */
export const ENTITLEMENT_PUBLIC_KEY = 'MCowBQYDK2VwAyEAIVbZOu3vn1MF6kV/SbVpWG2BTE8wW0njs6EhwUIRXEc=';

export interface EntitlementPayload {
  v: 1;
  /** 账号 ID 和登录邮箱 */
  sub: string;
  email: string;
  plan: PlanId;
  source: PlanSource;
  until: string | null;
  /** 签发时间和凭证过期时间（毫秒） */
  iat: number;
  exp: number;
}
export interface SignedEntitlement {
  payload: string;
  sig: string;
}

const enc = new TextEncoder();
export function b64urlEncode(bytes: Uint8Array): string {
  let s = '';
  for (const b of bytes) s += String.fromCharCode(b);
  return btoa(s).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}
export function b64urlDecode(s: string): Uint8Array<ArrayBuffer> {
  const b = atob(s.replace(/-/g, '+').replace(/_/g, '/') + '='.repeat((4 - (s.length % 4)) % 4));
  return Uint8Array.from(b, (c) => c.charCodeAt(0));
}
const b64Decode = (s: string): Uint8Array<ArrayBuffer> => Uint8Array.from(atob(s), (c) => c.charCodeAt(0));

export async function signEntitlement(p: EntitlementPayload, privateKeyPkcs8B64: string): Promise<SignedEntitlement> {
  const key = await crypto.subtle.importKey('pkcs8', b64Decode(privateKeyPkcs8B64), { name: 'Ed25519' }, false, ['sign']);
  const payload = b64urlEncode(enc.encode(JSON.stringify(p)));
  const sig = new Uint8Array(await crypto.subtle.sign('Ed25519', key, enc.encode(payload)));
  return { payload, sig: b64urlEncode(sig) };
}

/** 验签并检查是否过期；不对就返回 null（当成没有授权） */
export async function verifyEntitlement(e: SignedEntitlement | null | undefined, publicKeySpkiB64 = ENTITLEMENT_PUBLIC_KEY, now = Date.now()): Promise<EntitlementPayload | null> {
  if (!e?.payload || !e.sig) return null;
  try {
    const key = await crypto.subtle.importKey('spki', b64Decode(publicKeySpkiB64), { name: 'Ed25519' }, false, ['verify']);
    const ok = await crypto.subtle.verify('Ed25519', key, b64urlDecode(e.sig), enc.encode(e.payload));
    if (!ok) return null;
    const p = JSON.parse(new TextDecoder().decode(b64urlDecode(e.payload))) as EntitlementPayload;
    if (p.v !== 1 || !isPlan(p.plan) || !(p.exp > now)) return null;
    return p;
  } catch {
    return null;
  }
}
