// Oxford Solo 账号：登录（邮箱验证码）、付费等级、升级付款。和账号服务（server/，api.oxfordsolo.com）通信。
//
// 只把老板自己填的登录邮箱和验证码发给账号服务；邮件、日历、Google / Microsoft 令牌、API key 都不发。
// 账号服务返回签了名的授权凭证，存在 ~/.oxford-solo/account.json，离线时也能用 7 天。
import fs from 'node:fs';
import path from 'node:path';
import { ROOT } from './config.js';
import { DEFAULT_HOME } from './credentials.js';
import { BOTS } from './bots.js';
import { ENTITLEMENT_PUBLIC_KEY, PLANS, isPaidPlan, verifyEntitlement, type Interval, type PlanId, type PlanLimits, type PlanSource, type SignedEntitlement } from './plans.js';
import type { BotDef } from './types.js';

export const DEFAULT_ACCOUNT_API = 'https://api.oxfordsolo.com';

/**
 * 付费等级开关。上线前关着：不显示账号、不限制任何功能，和以前完全一样。
 * 打包时 `python3 tools/package.py --licensing` 会写 core/edition.json 打开它；开发时可以用 SOLO_LICENSING=on / off 覆盖。
 */
export function licensingOn(env: NodeJS.ProcessEnv = process.env): boolean {
  const v = String(env.SOLO_LICENSING ?? '').toLowerCase();
  if (['on', '1', 'true'].includes(v)) return true;
  if (['off', '0', 'false'].includes(v)) return false;
  try {
    return JSON.parse(fs.readFileSync(path.join(ROOT, 'edition.json'), 'utf8')).licensing === true;
  } catch {
    return false;
  }
}

/** 账号服务返回的账号信息（只用来显示） */
export interface AccountInfo {
  id: string;
  email: string;
  status: string;
  trialEndsAt: string | null;
  subscription: { plan: string; interval: string | null; status: string | null; periodEnd: string | null; cancelAtPeriodEnd: boolean } | null;
  grant: { plan: string; until: string | null } | null;
  effective: { plan: PlanId; source: PlanSource; until: string | null };
}

interface AccountFile {
  token: string;
  email: string;
  entitlement?: SignedEntitlement;
  account?: AccountInfo;
  fetchedAt?: string;
}

export interface PlanState {
  signedIn: boolean;
  email: string | null;
  plan: PlanId;
  source: PlanSource;
  until: string | null;
  limits: PlanLimits;
  account: AccountInfo | null;
  fetchedAt: string | null;
}

/** 账号服务报的错误代码，界面按 err.acct.<代码> 翻译 */
export class AccountError extends Error {
  constructor(
    readonly code: string,
    readonly status = 400,
  ) {
    super(code);
  }
}

const file = (home: string) => path.join(home, 'account.json');

export class AccountClient {
  private verified: PlanState | null = null;

  constructor(
    readonly home = DEFAULT_HOME,
    readonly api = process.env.SOLO_ACCOUNT_API || DEFAULT_ACCOUNT_API,
    private readonly fetchImpl: typeof fetch = (...a) => fetch(...a),
    private readonly publicKey = process.env.SOLO_ENTITLEMENT_PUBLIC_KEY || ENTITLEMENT_PUBLIC_KEY,
    private readonly now: () => number = () => Date.now(),
  ) {}

  private read(): AccountFile | null {
    try {
      const v = JSON.parse(fs.readFileSync(file(this.home), 'utf8')) as AccountFile;
      return v?.token ? v : null;
    } catch {
      return null;
    }
  }
  private write(v: AccountFile | null): void {
    if (!v) {
      fs.rmSync(file(this.home), { force: true });
      return;
    }
    fs.mkdirSync(this.home, { recursive: true, mode: 0o700 });
    const tmp = file(this.home) + '.tmp';
    fs.writeFileSync(tmp, JSON.stringify(v, null, 2) + '\n', { mode: 0o600 });
    fs.renameSync(tmp, file(this.home));
    fs.chmodSync(file(this.home), 0o600);
  }

  private async call<T>(method: 'GET' | 'POST', p: string, body?: unknown, token?: string): Promise<T> {
    let r: Response;
    try {
      r = await this.fetchImpl(this.api + p, {
        method,
        headers: { 'Content-Type': 'application/json', 'User-Agent': 'OxfordSolo-Desktop', ...(token ? { Authorization: `Bearer ${token}` } : {}) },
        body: body === undefined ? undefined : JSON.stringify(body),
        signal: AbortSignal.timeout(15_000),
      });
    } catch {
      throw new AccountError('network', 503);
    }
    const j = (await r.json().catch(() => ({}))) as T & { error?: string };
    if (!r.ok) throw new AccountError(j.error || 'server', r.status);
    return j;
  }

  /** 现在的等级（同步，界面每次刷新都会读）；第一次用之前先 await load() */
  state(): PlanState {
    return this.verified ?? this.empty(this.read());
  }
  private empty(f: AccountFile | null): PlanState {
    return { signedIn: !!f, email: f?.email ?? null, plan: 'none', source: 'none', until: null, limits: PLANS.none, account: f?.account ?? null, fetchedAt: f?.fetchedAt ?? null };
  }

  /** 读本机保存的凭证并验签；签名不对、过期、等级已到期都当成没有等级 */
  async load(): Promise<PlanState> {
    const f = this.read();
    const p = await verifyEntitlement(f?.entitlement, this.publicKey, this.now());
    if (!f || !p || p.email !== f.email) return (this.verified = this.empty(f));
    const ended = p.until !== null && Date.parse(p.until) <= this.now();
    const plan: PlanId = ended ? 'none' : p.plan;
    return (this.verified = {
      signedIn: true,
      email: f.email,
      plan,
      source: ended ? 'none' : p.source,
      until: p.until,
      limits: PLANS[plan],
      account: f.account ?? null,
      fetchedAt: f.fetchedAt ?? null,
    });
  }

  async start(email: string, lang: string): Promise<void> {
    await this.call('POST', '/v1/auth/start', { email, lang });
  }

  async verify(email: string, code: string): Promise<PlanState> {
    const r = await this.call<{ token: string; account: AccountInfo }>('POST', '/v1/auth/verify', { email, code, client: 'app' });
    this.write({ token: r.token, email: r.account.email, account: r.account });
    return this.refresh();
  }

  /** 去账号服务拿最新的等级；联不上网时保留旧凭证（7 天内照常用） */
  async refresh(): Promise<PlanState> {
    const f = this.read();
    if (!f) return this.load();
    try {
      const r = await this.call<{ account: AccountInfo; entitlement: SignedEntitlement }>('GET', '/v1/account', undefined, f.token);
      this.write({ ...f, email: r.account.email, account: r.account, entitlement: r.entitlement, fetchedAt: new Date(this.now()).toISOString() });
    } catch (e) {
      if (e instanceof AccountError && e.status === 401) this.write(null);
      else if (!(e instanceof AccountError && e.code === 'network')) throw e;
    }
    return this.load();
  }

  async logout(): Promise<void> {
    const f = this.read();
    if (f) await this.call('POST', '/v1/auth/logout', {}, f.token).catch(() => undefined);
    this.write(null);
    await this.load();
  }

  async checkout(plan: string, interval: string): Promise<{ url: string; portal: boolean }> {
    const f = this.read();
    if (!f) throw new AccountError('signedOut', 401);
    if (!isPaidPlan(plan) || (interval !== 'month' && interval !== 'year')) throw new AccountError('badPlan');
    return this.call('POST', '/v1/billing/checkout', { plan, interval: interval as Interval }, f.token);
  }

  async portal(): Promise<{ url: string }> {
    const f = this.read();
    if (!f) throw new AccountError('signedOut', 401);
    return this.call('POST', '/v1/billing/portal', {}, f.token);
  }
}

/** 按等级给 bot：不能直接订会的等级，会议准备 bot 没有 calendar_book，约时间改成交给老板定 */
export function botsForPlan(limits: PlanLimits, bots: BotDef[] = BOTS): BotDef[] {
  if (limits.calendarBooking) return bots;
  return bots.map((b) =>
    b.tools.includes('calendar_book')
      ? {
          ...b,
          kinds: b.kinds.filter((k) => k !== 'cal.book'),
          tools: b.tools.filter((x) => x !== 'calendar_book'),
          role: b.role.replace(/也负责订新会议[\s\S]*$/, '现在的等级不能直接在日历上订会：客户来信要约时间时，先查日历找出空闲时段，用 desk_ask 把可选时段交给老板定。'),
        }
      : b,
  );
}
