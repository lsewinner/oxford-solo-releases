// 模型连接（服务商、API key、模型、价格）保存在本机用户目录 ~/.oxford-solo/connection.json，
// 文件权限 600（只有你自己能读），不在项目文件夹里，也永远不会发给浏览器。
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

export type ConnProvider = 'openai' | 'claude';

export interface Connection {
  provider: ConnProvider;
  apiKey: string;
  model: string;
  /** 走代理或兼容 OpenAI 接口的服务时填写 */
  baseURL?: string;
  /** 美元 / 每百万 token；不填就按估计值 */
  priceInput?: number;
  priceOutput?: number;
  savedAt: string;
}

export const DEFAULT_HOME = process.env.SOLO_HOME ? path.resolve(process.env.SOLO_HOME) : path.join(os.homedir(), '.oxford-solo');

const file = (home: string) => path.join(home, 'connection.json');

export function loadConnection(home = DEFAULT_HOME): Connection | null {
  try {
    const c = JSON.parse(fs.readFileSync(file(home), 'utf8')) as Connection;
    return c && c.apiKey && c.model && (c.provider === 'openai' || c.provider === 'claude') ? c : null;
  } catch {
    return null;
  }
}

export function saveConnection(c: Connection, home = DEFAULT_HOME): void {
  fs.mkdirSync(home, { recursive: true, mode: 0o700 });
  const tmp = file(home) + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(c, null, 2) + '\n', { mode: 0o600 });
  fs.renameSync(tmp, file(home));
  fs.chmodSync(file(home), 0o600);
}

export function clearConnection(home = DEFAULT_HOME): void {
  fs.rmSync(file(home), { force: true });
}

/** 给人看的 key 提示：只露出开头和最后 4 位 */
export function keyHint(key: string): string {
  return key.length > 12 ? `${key.slice(0, 3)}…${key.slice(-4)}` : '…';
}
