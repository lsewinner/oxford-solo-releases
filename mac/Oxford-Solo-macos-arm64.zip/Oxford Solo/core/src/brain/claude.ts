// 用 Claude 驱动总指挥、bot 和质检
import Anthropic from '@anthropic-ai/sdk';
import { betaZodOutputFormat, betaZodTool } from '@anthropic-ai/sdk/helpers/beta/zod';
import { MODEL } from '../config.js';
import type { UnitPlan, Usage, Verdict } from '../types.js';
import {
  CHECK_SYSTEM,
  CriteriaSchema,
  ORCH_SYSTEM,
  VerdictSchema,
  botSystem,
  criteriaPrompt,
  langNote,
  splitPrompt,
  splitSchema,
  unitPrompt,
  verifyPrompt,
} from './prompts.js';
import { Throttle } from './throttle.js';
import { BrainError, type Brain, type BrainResult, type CriteriaInput, type ExecuteInput, type SplitInput, type VerifyInput } from './types.js';

// 服务端兜底：模型因安全分类拒绝时，由 API 自动换用合适的模型重跑
const FALLBACK_BETA = 'server-side-fallback-2026-07-01';

export class ClaudeBrain implements Brain {
  readonly mode = 'claude' as const;
  readonly label: string;
  readonly model: string;
  private client: Anthropic;
  readonly throttle = new Throttle();

  /** 不填就用环境变量里的 key 和默认模型 Claude Opus 5.5 */
  constructor(opts: { apiKey?: string; model?: string } = {}) {
    this.model = opts.model || MODEL;
    this.label = this.model === MODEL ? 'Claude Opus 5.5' : `Claude ${this.model}`;
    // 上百个 bot 同时调用：统一由 throttle 排队、限流、重试，SDK 自己不再重试
    this.client = new Anthropic({ ...(opts.apiKey ? { apiKey: opts.apiKey } : {}), maxRetries: 0, fetch: this.throttle.fetch() });
  }

  /** 把认证、权限、模型不存在这类"重试也没用"的错误转成致命错误，让整次运行停下 */
  private async guard<T>(fn: () => Promise<T>): Promise<T> {
    try {
      return await fn();
    } catch (e) {
      if (e instanceof Anthropic.AuthenticationError) throw new BrainError('Claude API 认证失败：请检查 ANTHROPIC_API_KEY 是否正确', true);
      if (e instanceof Anthropic.PermissionDeniedError) throw new BrainError('这个 API key 没有调用该模型的权限', true);
      if (e instanceof Anthropic.NotFoundError) throw new BrainError(`找不到模型 ${this.model}`, true);
      throw e;
    }
  }

  private ensureAnswered(stop: string | null): void {
    if (stop === 'refusal') throw new BrainError('模型拒绝了这个请求');
    if (stop === 'max_tokens') throw new BrainError('模型输出被截断（max_tokens）');
  }

  async writeCriteria(i: CriteriaInput): Promise<BrainResult<string[]>> {
    return this.guard(async () => {
      const res = await this.client.beta.messages.parse({
        model: this.model,
        max_tokens: 6000,
        betas: [FALLBACK_BETA],
        fallbacks: 'default',
        output_config: { effort: 'high', format: betaZodOutputFormat(CriteriaSchema) },
        system: ORCH_SYSTEM + langNote(i.lang),
        messages: [{ role: 'user', content: criteriaPrompt(i) }],
      });
      this.ensureAnswered(res.stop_reason);
      if (!res.parsed_output) throw new BrainError('验收标准的输出无法解析');
      return { value: res.parsed_output.criteria, usage: [{ ...res.usage, model: this.model }] };
    });
  }

  async split(i: SplitInput): Promise<BrainResult<UnitPlan[]>> {
    return this.guard(async () => {
      const res = await this.client.beta.messages.parse({
        model: this.model,
        max_tokens: 12000,
        betas: [FALLBACK_BETA],
        fallbacks: 'default',
        output_config: { effort: 'high', format: betaZodOutputFormat(splitSchema(i.bots.map((b) => b.id))) },
        system: ORCH_SYSTEM + langNote(i.lang),
        messages: [{ role: 'user', content: splitPrompt(i) }],
      });
      this.ensureAnswered(res.stop_reason);
      if (!res.parsed_output) throw new BrainError('拆解结果无法解析');
      return { value: res.parsed_output.units, usage: [{ ...res.usage, model: this.model }] };
    });
  }

  async execute(i: ExecuteInput): Promise<BrainResult<string>> {
    return this.guard(async () => {
      const tools = i.tools.tools.map((t) =>
        betaZodTool({ name: t.name, description: t.description, inputSchema: t.schema, run: (input) => i.tools.call(t.name, input) }),
      );
      const runner = this.client.beta.messages.toolRunner({
        model: this.model,
        max_tokens: 16000,
        max_iterations: 15,
        betas: [FALLBACK_BETA],
        fallbacks: 'default',
        output_config: { effort: 'medium' },
        system: [{ type: 'text', text: botSystem(i.bot, i.owner) + langNote(i.lang), cache_control: { type: 'ephemeral' } }],
        tools,
        messages: [{ role: 'user', content: unitPrompt(i) }],
      });
      const usage: Usage[] = [];
      let last: Anthropic.Beta.BetaMessage | undefined;
      for await (const message of runner) {
        usage.push({ ...message.usage, model: this.model });
        last = message;
      }
      if (!last) throw new BrainError('bot 没有返回任何结果');
      this.ensureAnswered(last.stop_reason);
      const text = last.content
        .filter((b): b is Anthropic.Beta.BetaTextBlock => b.type === 'text')
        .map((b) => b.text)
        .join('\n')
        .trim();
      return { value: text || '（bot 没有写汇报）', usage };
    });
  }

  async verify(i: VerifyInput): Promise<BrainResult<Verdict>> {
    return this.guard(async () => {
      const res = await this.client.beta.messages.parse({
        model: this.model,
        max_tokens: 6000,
        betas: [FALLBACK_BETA],
        fallbacks: 'default',
        output_config: { effort: 'medium', format: betaZodOutputFormat(VerdictSchema) },
        system: CHECK_SYSTEM + langNote(i.lang),
        messages: [{ role: 'user', content: verifyPrompt(i) }],
      });
      this.ensureAnswered(res.stop_reason);
      if (!res.parsed_output) throw new BrainError('质检结果无法解析');
      return { value: res.parsed_output, usage: [{ ...res.usage, model: this.model }] };
    });
  }
}
