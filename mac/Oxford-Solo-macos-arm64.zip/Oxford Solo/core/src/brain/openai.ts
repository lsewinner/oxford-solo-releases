// 用 OpenAI 驱动总指挥、bot 和质检（和 Claude 大脑共用同一套提示词、工具和红线）
import OpenAI from 'openai';
import { zodResponseFormat } from 'openai/helpers/zod';
import { z } from 'zod';
import type { UnitPlan, Usage, Verdict } from '../types.js';
import {
  CHECK_SYSTEM,
  CriteriaSchema,
  ORCH_SYSTEM,
  VerdictSchema,
  botSystem,
  criteriaPrompt,
  langNote,
  splitPrompt,
  splitSchema,
  unitPrompt,
  verifyPrompt,
} from './prompts.js';
import { Throttle } from './throttle.js';
import { BrainError, type Brain, type BrainResult, type CriteriaInput, type ExecuteInput, type SplitInput, type VerifyInput } from './types.js';

/** 默认的 OpenAI 模型：可以在"连接模型"里换，或设置 OPENAI_MODEL */
export const OPENAI_MODEL = process.env.OPENAI_MODEL ?? 'gpt-6.1-sol';
const MAX_TOOL_ROUNDS = 15;


export class OpenAIBrain implements Brain {
  readonly mode = 'openai' as const;
  readonly label: string;
  readonly model: string;
  private client: OpenAI;
  readonly throttle = new Throttle();

  /** opts 可以指定 apiKey、baseURL（走代理或兼容 OpenAI 接口的服务）和 model；不填就读环境变量 */
  constructor(opts: ConstructorParameters<typeof OpenAI>[0] & { model?: string } = {}) {
    const { model, ...client } = opts;
    this.model = model || OPENAI_MODEL;
    this.label = `OpenAI ${this.model}`;
    // 上百个 bot 同时调用：统一由 throttle 排队、限流、重试，SDK 自己不再重试
    this.client = new OpenAI({ maxRetries: 0, fetch: this.throttle.fetch(), ...client });
  }

  private async guard<T>(fn: () => Promise<T>): Promise<T> {
    try {
      return await fn();
    } catch (e) {
      if (e instanceof OpenAI.AuthenticationError) throw new BrainError('OpenAI API 认证失败：请检查 OPENAI_API_KEY 是否正确', true);
      if (e instanceof OpenAI.PermissionDeniedError) throw new BrainError('这个 OpenAI key 没有调用该模型的权限', true);
      if (e instanceof OpenAI.BadRequestError) throw new BrainError(`OpenAI 拒绝了请求：${e.message}`, true);
      if (e instanceof OpenAI.NotFoundError) throw new BrainError(`找不到模型 ${this.model}，或者这个 key 没有权限使用它`, true);
      throw e;
    }
  }

  private usageOf(u: OpenAI.Completions.CompletionUsage | undefined): Usage {
    const cached = u?.prompt_tokens_details?.cached_tokens ?? 0;
    return { input_tokens: (u?.prompt_tokens ?? 0) - cached, output_tokens: u?.completion_tokens ?? 0, cache_read_input_tokens: cached, model: this.model };
  }

  /** 结构化输出：让模型按 zod 结构回答 */
  private async parse<S extends z.ZodType>(system: string, user: string, schema: S, name: string): Promise<BrainResult<z.infer<S>>> {
    const res = await this.client.chat.completions.parse({
      model: this.model,
      messages: [
        { role: 'system', content: system },
        { role: 'user', content: user },
      ],
      response_format: zodResponseFormat(schema, name),
    });
    const choice = res.choices[0];
    if (!choice) throw new BrainError('模型没有返回结果');
    if (choice.message.refusal) throw new BrainError('模型拒绝了这个请求');
    if (choice.finish_reason === 'length') throw new BrainError('模型输出被截断');
    if (choice.message.parsed == null) throw new BrainError('模型输出无法解析');
    return { value: choice.message.parsed as z.infer<S>, usage: [this.usageOf(res.usage)] };
  }

  async writeCriteria(i: CriteriaInput): Promise<BrainResult<string[]>> {
    return this.guard(async () => {
      const r = await this.parse(ORCH_SYSTEM + langNote(i.lang), criteriaPrompt(i), CriteriaSchema, 'criteria');
      return { value: r.value.criteria, usage: r.usage };
    });
  }

  async split(i: SplitInput): Promise<BrainResult<UnitPlan[]>> {
    return this.guard(async () => {
      const r = await this.parse(ORCH_SYSTEM + langNote(i.lang), splitPrompt(i), splitSchema(i.bots.map((b) => b.id)), 'split');
      return { value: r.value.units, usage: r.usage };
    });
  }

  private usageOfResponse(u: OpenAI.Responses.ResponseUsage | undefined): Usage {
    const cached = u?.input_tokens_details?.cached_tokens ?? 0;
    return { input_tokens: (u?.input_tokens ?? 0) - cached, output_tokens: u?.output_tokens ?? 0, cache_read_input_tokens: cached, model: this.model };
  }

  /**
   * bot 干活：模型调用工具 → 我们的工具箱执行（红线在工具箱里暂存）→ 结果交回模型，直到它写出汇报。
   * 用 Responses 接口（新模型的工具调用只支持它）；store: false，对话不保存在 OpenAI 那边，
   * 推理内容以加密形式随请求带回。
   */
  async execute(i: ExecuteInput): Promise<BrainResult<string>> {
    return this.guard(async () => {
      const tools: OpenAI.Responses.FunctionTool[] = i.tools.tools.map((t) => {
        const { $schema: _drop, ...parameters } = z.toJSONSchema(t.schema) as Record<string, unknown>;
        return { type: 'function', name: t.name, description: t.description, parameters, strict: false };
      });
      const input: OpenAI.Responses.ResponseInputItem[] = [{ role: 'user', content: unitPrompt(i) }];
      const usage: Usage[] = [];
      for (let round = 0; round < MAX_TOOL_ROUNDS; round++) {
        const res = await this.client.responses.create({
          model: this.model,
          instructions: botSystem(i.bot, i.owner) + langNote(i.lang),
          input,
          tools,
          store: false,
          include: ['reasoning.encrypted_content'],
        });
        usage.push(this.usageOfResponse(res.usage));
        if (res.status === 'incomplete') throw new BrainError(`模型输出不完整：${res.incomplete_details?.reason ?? ''}`);
        if (res.output.some((o) => o.type === 'message' && o.content.some((c) => c.type === 'refusal'))) throw new BrainError('模型拒绝了这个请求');
        const calls = res.output.filter((o): o is OpenAI.Responses.ResponseFunctionToolCall => o.type === 'function_call');
        if (!calls.length) return { value: res.output_text.trim() || '（bot 没有写汇报）', usage };
        input.push(...(res.output as OpenAI.Responses.ResponseInputItem[]));
        for (const call of calls) {
          let args: unknown = {};
          try {
            args = JSON.parse(call.arguments || '{}');
          } catch {
            /* 参数不是合法 JSON：交给工具箱报"输入不合法"，模型会重试 */
          }
          input.push({ type: 'function_call_output', call_id: call.call_id, output: await i.tools.call(call.name, args) });
        }
      }
      throw new BrainError(`bot 调用工具超过 ${MAX_TOOL_ROUNDS} 轮还没完成`);
    });
  }

  async verify(i: VerifyInput): Promise<BrainResult<Verdict>> {
    return this.guard(() => this.parse(CHECK_SYSTEM + langNote(i.lang), verifyPrompt(i), VerdictSchema, 'verdict'));
  }
}
