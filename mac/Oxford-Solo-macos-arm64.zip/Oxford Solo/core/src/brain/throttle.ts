// 给模型 API 用的 fetch：上百个 bot 同时干活时，统一在这里排队、限流、重试。
//
// - 同时在途的请求数自动调节（加性增、乘性减）：一直顺利就慢慢放开，碰到 429 立刻减半，
//   这样不管用户的 key 是哪一档限额，都能尽量跑满又不被封。
// - 429、529（过载）、5xx 和网络错误自动重试，按服务商给的 retry-after 等待，没给就指数退避加抖动。
//   429 会让所有请求一起暂停，免得一群 bot 同时去撞限额。
// - 只重试请求体能原样重放的请求（JSON 字符串），流式上传之类的不重试。
// SDK 自己的重试要关掉（maxRetries: 0），否则会重试两遍。

export interface ThrottleOptions {
  /** 起始的同时在途请求数 */
  start?: number;
  min?: number;
  max?: number;
  /** 一个请求最多尝试几次（含第一次） */
  maxAttempts?: number;
  /** 退避的基础时长和上限（毫秒） */
  baseDelayMs?: number;
  maxDelayMs?: number;
  /** 测试用 */
  sleep?: (ms: number) => Promise<void>;
  random?: () => number;
}

type Fetch = (input: string | URL | Request, init?: RequestInit) => Promise<Response>;

const realSleep = (ms: number) => new Promise<void>((r) => setTimeout(r, ms));

export function retryAfterMs(h: Headers | undefined | null): number | undefined {
  if (!h) return undefined;
  const ms = Number(h.get('retry-after-ms'));
  if (ms > 0) return ms;
  const raw = h.get('retry-after');
  if (!raw) return undefined;
  const s = Number(raw);
  if (s > 0) return s * 1000;
  const at = Date.parse(raw);
  return Number.isNaN(at) ? undefined : Math.max(0, at - Date.now());
}

export class Throttle {
  limit: number;
  inFlight = 0;
  /** 观察用：同时在途的最大请求数、因限流暂停的次数 */
  peak = 0;
  throttled = 0;
  private waiters: Array<() => void> = [];
  private pausedUntil = 0;
  private okStreak = 0;
  private o: Required<ThrottleOptions>;

  constructor(opts: ThrottleOptions = {}) {
    this.o = {
      start: opts.start ?? 12,
      min: opts.min ?? 2,
      max: opts.max ?? 64,
      maxAttempts: opts.maxAttempts ?? 8,
      baseDelayMs: opts.baseDelayMs ?? 1000,
      maxDelayMs: opts.maxDelayMs ?? 60_000,
      sleep: opts.sleep ?? realSleep,
      random: opts.random ?? Math.random,
    };
    this.limit = this.o.start;
  }

  private async acquire(): Promise<void> {
    for (;;) {
      const wait = this.pausedUntil - Date.now();
      if (wait > 0) {
        await this.o.sleep(wait);
        continue;
      }
      if (this.inFlight < this.limit) {
        this.inFlight++;
        this.peak = Math.max(this.peak, this.inFlight);
        return;
      }
      await new Promise<void>((r) => this.waiters.push(r));
    }
  }

  private release(): void {
    this.inFlight--;
    this.wake();
  }

  private wake(): void {
    let free = this.limit - this.inFlight;
    while (free-- > 0 && this.waiters.length) this.waiters.shift()!();
  }

  private ok(): void {
    if (++this.okStreak >= this.limit && this.limit < this.o.max) {
      this.limit++;
      this.okStreak = 0;
      this.wake();
    }
  }

  private limited(delayMs: number): void {
    this.throttled++;
    this.okStreak = 0;
    this.limit = Math.max(this.o.min, Math.floor(this.limit / 2));
    this.pausedUntil = Math.max(this.pausedUntil, Date.now() + delayMs);
  }

  /** 包一层 fetch：交给 Anthropic / OpenAI SDK 的 fetch 选项 */
  fetch(base: Fetch = (i, n) => fetch(i, n)): Fetch {
    return async (input, init) => {
      const replayable = init?.body == null || typeof init.body === 'string';
      for (let attempt = 1; ; attempt++) {
        await this.acquire();
        let res: Response | undefined;
        let err: unknown;
        try {
          res = await base(input, init);
        } catch (e) {
          err = e;
        } finally {
          this.release();
        }
        const aborted = !!init?.signal?.aborted;
        const status = res?.status ?? 0;
        const retryable = !aborted && (err ? true : status === 429 || status === 529 || (status >= 500 && status !== 501));
        if (!retryable || !replayable || attempt >= this.o.maxAttempts) {
          if (err) throw err;
          if (status < 400) this.ok();
          return res!;
        }
        const backoff = Math.min(this.o.maxDelayMs, this.o.baseDelayMs * 2 ** (attempt - 1)) * (0.5 + this.o.random());
        const delay = Math.min(this.o.maxDelayMs, retryAfterMs(res?.headers) ?? backoff);
        if (status === 429 || status === 529) this.limited(delay);
        await res?.body?.cancel().catch(() => undefined);
        await this.o.sleep(delay);
      }
    };
  }
}
