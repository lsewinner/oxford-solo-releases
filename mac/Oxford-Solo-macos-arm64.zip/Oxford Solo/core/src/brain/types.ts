import type { Lang } from '../i18n.js';
import type { ToolBox } from '../tools.js';
import type { ActionRecord, BotDef, Owner, Snapshot, Unit, UnitPlan, Usage, Verdict } from '../types.js';

export interface BrainResult<T> {
  value: T;
  usage: Usage[];
}

export interface CriteriaInput {
  lang: Lang;
  instruction: string;
  snapshotText: string;
  rules: string[];
}

export interface SplitInput extends CriteriaInput {
  criteria: string[];
  snapshot: Snapshot;
  bots: BotDef[];
  maxUnits: number;
}

export interface ExecuteInput {
  lang: Lang;
  unit: Unit;
  bot: BotDef;
  owner: Owner;
  today: string;
  criteria: string[];
  rules: string[];
  depOutputs: Array<{ id: string; title: string; output: string }>;
  tools: ToolBox;
}

export interface VerifyInput {
  lang: Lang;
  /** 老板所在时区的今天，质检以它为准 */
  today: string;
  unit: Unit;
  bot: BotDef;
  output: string;
  actions: ActionRecord[];
  criteria: string[];
  rules: string[];
  /** 老板资料：质检靠它判断署名里的名字、公司是不是对的 */
  owner?: Owner;
}

/** 总指挥、bot 和质检背后的"大脑"。ClaudeBrain 调真实模型，MockBrain 离线模拟 */
export interface Brain {
  readonly mode: 'claude' | 'openai' | 'mock';
  /** 给人看的模型名，例如 Claude Opus 5.5、OpenAI gpt-5.5 */
  readonly label: string;
  writeCriteria(i: CriteriaInput): Promise<BrainResult<string[]>>;
  split(i: SplitInput): Promise<BrainResult<UnitPlan[]>>;
  execute(i: ExecuteInput): Promise<BrainResult<string>>;
  verify(i: VerifyInput): Promise<BrainResult<Verdict>>;
}

/** fatal = 继续跑其他单元也没有意义（例如 API key 无效），整次运行应当停下 */
export class BrainError extends Error {
  constructor(
    message: string,
    readonly fatal = false,
  ) {
    super(message);
  }
}
