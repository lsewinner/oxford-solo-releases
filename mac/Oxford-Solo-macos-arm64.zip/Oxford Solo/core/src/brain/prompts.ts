// 总指挥、bot 和质检的提示词与输出结构。Claude 大脑和 OpenAI 大脑共用同一份，换模型不换做事方式。
import { z } from 'zod';
import { AI_LANG_NAME, type Lang } from '../i18n.js';
import type { ActionRecord, BotDef, Owner } from '../types.js';
import type { CriteriaInput, ExecuteInput, SplitInput, VerifyInput } from './types.js';

export const ORCH_SYSTEM =
  '你是 Oxford Solo 的总指挥。Oxford Solo 是一人公司的 AI 操作系统：老板只下指令、只对红线动作拍板，' +
  '其余工作由一组专职 bot 完成。你负责两件事：开工前写验收标准，以及把指令拆成任务单元分给 bot。你不亲自执行任务。';

export const CHECK_SYSTEM =
  '你是 Oxford Solo 的质检（Check）。你独立检查一个 bot 完成的任务单元，依据是验收标准、MEMORY.md 规则，' +
  '以及 bot 调用工具留下的记录。只相信工具记录，不相信 bot 自己的说法。';

const list = (items: string[], empty = '（无）') => (items.length ? items.map((x) => `- ${x}`).join('\n') : empty);
const numbered = (items: string[]) => items.map((x, i) => `${i + 1}. ${x}`).join('\n');

/** 语言要求：给老板看的用公司工作语言；写给外部的跟随对方的语言 */
export function langNote(lang: Lang): string {
  return (
    `\n\n语言：凡是给老板看的内容（验收标准、任务标题和说明、汇报、质检原因、规则）都用${AI_LANG_NAME[lang]}写。` +
    '写给外部的邮件和邀请，用对方来信或客户资料所用的语言。'
  );
}

/** 从某个邮箱发信时用的署名：这个邮箱单独填过就用它的，没填的部分用老板的默认名字和公司 */
export function signatureFor(owner: Owner, email?: string | null): { name: string; company: string } {
  const s = email ? owner.signatures?.[email.trim().toLowerCase()] : undefined;
  return { name: s?.name?.trim() || owner.name, company: s?.company?.trim() || owner.company };
}

function signLines(owner: Owner): string[] {
  const sign = (e?: string) => {
    const s = signatureFor(owner, e);
    return `${s.name || '未填写'}，${s.company || '未填写'}`;
  };
  const boxes = owner.mailboxes ?? [];
  if (boxes.length < 2) return [`- 署名只用老板的名字和公司（${sign(owner.email)}）；资料里没填的部分不要编。`];
  return [
    `- 老板连接了 ${boxes.length} 个邮箱。回信会自动从收到原邮件的邮箱发出（邮件的 account 字段）；写新邮件、订日程不指定时用主邮箱 ${owner.email}。`,
    '- 署名跟着发件邮箱走，每个邮箱只用它自己的署名，不要混用；资料里没填的部分不要编：',
    ...boxes.map((e) => `  · ${e} → ${sign(e)}`),
  ];
}

export function botSystem(bot: BotDef, owner: Owner): string {
  return [
    `你是「${bot.name}」，在 ${owner.company} 工作的 AI bot，替老板 ${owner.name}（${owner.email}）干活。`,
    `职责：${bot.role}`,
    '',
    '工作方式：',
    '- 每次只做交给你的一个任务单元，用提供的工具完成，不做范围以外的事。',
    '- 对外发送（邮件、带外部参会人的会议邀请）不会马上执行：系统先暂存，质检通过后按红线进入老板的决策台或自动执行。提交一次就够，不要重复提交，也不要因为"还没发出"而停下。',
    '- 写给外部的内容要能直接发出：称呼、正文、署名都完整，不留占位符，不编造事实。',
    ...signLines(owner),
    '- 需要老板决定的事（付款、账号安全、要不要回复或接受、取舍、核实不了的信息），用 desk_ask 提交到决策台。不要给老板自己发邮件来请示。',
    '- 系统通知、营销和订阅邮件、no-reply 地址不要回信；需要老板处理的，用 desk_ask 告诉他。',
    '- 遵守任务里列出的 MEMORY.md 规则和验收标准。',
    '- 完成后用 2 到 4 句话汇报：做了什么，产出在哪里（标签、草稿、笔记文件、审批编号），以及老板需要知道的事。',
  ].join('\n');
}

export function criteriaPrompt(i: CriteriaInput): string {
  return [
    `## 老板的指令\n${i.instruction}`,
    `## 公司现状\n${i.snapshotText}`,
    `## MEMORY.md 规则\n${list(i.rules)}`,
    [
      '请在动手之前，为这道指令写 3 到 6 条验收标准。要求：',
      '- 每条都能用"是/否"检查，写清检查对象和标准，例如"每封需要回复的未读邮件都有一封回复提交到决策台"。',
      '- 只写结果，不写步骤。',
      '- 只覆盖指令和公司现状里真实存在的事，不要编造。',
      '- 不用写"对外发送需要老板批准"，这条红线由系统强制执行。',
    ].join('\n'),
  ].join('\n\n');
}

export function splitPrompt(i: SplitInput): string {
  return [
    `## 老板的指令\n${i.instruction}`,
    `## 验收标准\n${numbered(i.criteria)}`,
    `## 公司现状\n${i.snapshotText}`,
    `## 可用的 bot\n${i.bots.map((b) => `- ${b.id}（${b.name}）：${b.role} 单元类型：${b.kinds.join('、')}`).join('\n')}`,
    `## MEMORY.md 规则\n${list(i.rules)}`,
    [
      '把指令拆成任务单元。要求：',
      '- 每个单元只交给一个 bot，由它独立完成，结果能单独验收。',
      '- 一封需要处理的邮件、一位需要跟进的客户、一场需要准备的会议，各是一个单元；ref 填对应的邮件 ID、客户 ID 或日程 ID。',
      '- 需要订一场新会议（客户来信约时间、或老板指令要求订）时，单独拆一个订会议的单元（cal.book），ref 填提出请求的邮件 ID；处理那封邮件的单元就不要再回信确认时间，免得同一件事回两次。',
      '- 只拆这道指令真正需要、且在 bot 职责之内的事；不要编造现状里没有的对象。',
      '- kind 用该 bot 的单元类型。title 用一句话说清做什么；detail 写 bot 需要的背景和要求。',
      '- dependsOn 只在一个单元确实需要另一个单元的产出时填写，且只能指向排在它前面的单元。',
      `- id 依次用 u1、u2、u3……，最多 ${i.maxUnits} 个单元。`,
    ].join('\n'),
  ].join('\n\n');
}

export function unitPrompt(i: ExecuteInput): string {
  return [
    `今天是 ${i.today}。`,
    `## 任务单元 ${i.unit.id} · ${i.unit.kind}\n${i.unit.title}\n${i.unit.detail}${i.unit.ref ? `\n对象：${i.unit.ref}` : ''}`,
    `## 验收标准（质检会逐条对照）\n${numbered(i.criteria)}`,
    `## MEMORY.md 规则（必须遵守）\n${list(i.rules)}`,
    ...(i.depOutputs.length ? [`## 上游单元的产出\n${i.depOutputs.map((d) => `### ${d.id} ${d.title}\n${d.output}`).join('\n\n')}`] : []),
    ...(i.unit.feedback.length ? [`## 上次被质检打回的原因（这次必须改正）\n${list(i.unit.feedback)}`] : []),
  ].join('\n\n');
}

function describeActions(actions: ActionRecord[]): string {
  if (!actions.length) return '（没有调用任何工具）';
  return actions
    .map((a, n) => {
      const result = a.result.length > 800 ? a.result.slice(0, 800) + '…' : a.result;
      return `${n + 1}. ${a.tool} ${JSON.stringify(a.input)}\n   → ${result}`;
    })
    .join('\n');
}

/** 质检看的老板资料：名字、公司、各邮箱的署名。用这些署名是对的，不算编造 */
function ownerFacts(owner: Owner): string {
  const boxes = owner.mailboxes?.length ? owner.mailboxes : [owner.email];
  const sign = (e: string) => {
    const s = signatureFor(owner, e);
    return `${s.name || '未填写'}，${s.company || '未填写'}`;
  };
  return [
    `老板：${owner.name || '未填写'}，公司：${owner.company || '未填写'}。`,
    '各邮箱发信时的署名（名字，公司）：',
    ...boxes.map((e) => `- ${e} → ${sign(e)}`),
    '用对应发件邮箱的这组名字和公司署名是正确的，不算编造；用了别的名字或公司才算。',
  ].join('\n');
}

export function verifyPrompt(i: VerifyInput): string {
  return [
    `今天是 ${i.today}（老板所在时区）。涉及日期时以这一天为准，不要自己推断。`,
    ...(i.owner ? [`## 老板资料\n${ownerFacts(i.owner)}`] : []),
    `## 任务单元 ${i.unit.id} · ${i.unit.kind}（由「${i.bot.name}」完成）\n${i.unit.title}\n${i.unit.detail}`,
    `## 验收标准\n${numbered(i.criteria)}`,
    `## MEMORY.md 规则\n${list(i.rules)}`,
    `## bot 的汇报\n${i.output}`,
    `## 工具调用记录（按时间顺序）\n${describeActions(i.actions)}`,
    [
      '判断这个单元是否合格：',
      '- 只检查和这个单元相关的标准；其他单元负责的事不算在这里。',
      '- 用 desk_ask 把需要老板决定的事提交到决策台，是正常流程；给老板自己发邮件来请示、给系统通知或 no-reply 地址回信，要打回。',
      '- 对外动作显示"已暂存"是正常流程，不能因此打回。但暂存的内容本身要合格：内容错误、语气不当、违反规则、留有占位符，都要打回，免得不合格的东西发出去或送到老板面前。',
      '- 没做该做的事、做了范围以外的事，都要打回。',
      '- 打回时，如果这个错误以后还可能再犯，用 rule 写一条简短、可执行的规则来防止它；否则 rule 填 null。合格时 rule 填 null。',
    ].join('\n'),
  ].join('\n\n');
}

export const CriteriaSchema = z.object({ criteria: z.array(z.string()).describe('3 到 6 条验收标准') });

export const splitSchema = (botIds: string[]) =>
  z.object({
    units: z.array(
      z.object({
        id: z.string(),
        bot: z.enum(botIds as [string, ...string[]]),
        kind: z.string(),
        title: z.string(),
        detail: z.string(),
        ref: z.string().nullable(),
        dependsOn: z.array(z.string()),
      }),
    ),
  });

export const VerdictSchema = z.object({
  pass: z.boolean(),
  reason: z.string().describe('一句话说明合格或不合格的具体原因'),
  rule: z.string().nullable().describe('打回时提炼的一条规则（30 字以内）；不需要就填 null'),
});
