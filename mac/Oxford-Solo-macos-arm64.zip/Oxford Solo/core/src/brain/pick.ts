// 选大脑。顺序：
//   1. 老板在"连接模型"里保存的连接（~/.oxford-solo/connection.json）
//   2. 环境变量：ANTHROPIC_API_KEY → Claude，OPENAI_API_KEY → OpenAI
//   3. 都没有就离线模拟
// 设置 SOLO_BRAIN=claude|openai|mock 可以强制指定。
import Anthropic from '@anthropic-ai/sdk';
import OpenAI from 'openai';
import { MODEL, setPrice } from '../config.js';
import { DEFAULT_HOME, loadConnection, type Connection } from '../credentials.js';
import { CodedError } from '../i18n.js';
import { ClaudeBrain } from './claude.js';
import { MockBrain } from './mock.js';
import { OpenAIBrain, OPENAI_MODEL } from './openai.js';
import type { Brain } from './types.js';

export type Provider = 'claude' | 'openai' | 'mock';

export interface BrainChoice {
  provider: Provider;
  model: string;
  apiKey?: string;
  baseURL?: string;
  /** saved = 连接窗口里保存的；env = 环境变量；none = 离线模拟 */
  source: 'saved' | 'env' | 'none';
}

export function detectProvider(env: NodeJS.ProcessEnv = process.env): Provider {
  const forced = env.SOLO_BRAIN?.toLowerCase();
  if (forced === 'claude' || forced === 'openai' || forced === 'mock') return forced;
  if (env.ANTHROPIC_API_KEY || env.ANTHROPIC_AUTH_TOKEN) return 'claude';
  if (env.OPENAI_API_KEY) return 'openai';
  return 'mock';
}

export function resolveChoice(env: NodeJS.ProcessEnv = process.env, home = DEFAULT_HOME): BrainChoice {
  const saved = env.SOLO_BRAIN?.toLowerCase() === 'mock' ? null : loadConnection(home);
  if (saved) {
    if (saved.priceInput && saved.priceOutput) setPrice(saved.model, saved.priceInput, saved.priceOutput);
    return { provider: saved.provider, model: saved.model, apiKey: saved.apiKey, baseURL: saved.baseURL, source: 'saved' };
  }
  const p = detectProvider(env);
  if (p === 'claude') return { provider: p, model: MODEL, source: 'env' };
  if (p === 'openai') return { provider: p, model: OPENAI_MODEL, source: 'env' };
  return { provider: 'mock', model: '', source: 'none' };
}

export function choiceLabel(c: BrainChoice): string {
  if (c.provider === 'claude') return c.model === MODEL ? 'Claude Opus 5.5' : `Claude ${c.model}`;
  if (c.provider === 'openai') return `OpenAI ${c.model}`;
  return '';
}

/** 兼容旧写法：只给服务商时用默认模型 */
export function providerLabel(p: Provider): string {
  return p === 'mock' ? '' : choiceLabel({ provider: p, model: p === 'claude' ? MODEL : OPENAI_MODEL, source: 'env' });
}

export function makeBrain(choice: BrainChoice | Provider, mockOpts: ConstructorParameters<typeof MockBrain>[0] = {}): Brain {
  const c: BrainChoice = typeof choice === 'string' ? { provider: choice, model: choice === 'claude' ? MODEL : OPENAI_MODEL, source: 'env' } : choice;
  if (c.provider === 'claude') return new ClaudeBrain({ apiKey: c.apiKey, model: c.model });
  if (c.provider === 'openai') return new OpenAIBrain({ apiKey: c.apiKey, baseURL: c.baseURL, model: c.model });
  return new MockBrain(mockOpts);
}

/**
 * 保存之前先验证：查询一次这个模型的信息。查询模型不消耗 token、不花钱，
 * 但能确认 key 有效、模型存在、这个 key 有权使用它。
 */
export async function verifyConnection(c: Pick<Connection, 'provider' | 'apiKey' | 'model' | 'baseURL'>): Promise<void> {
  try {
    if (c.provider === 'openai') await new OpenAI({ apiKey: c.apiKey, baseURL: c.baseURL || undefined, maxRetries: 1, timeout: 20_000 }).models.retrieve(c.model);
    else await new Anthropic({ apiKey: c.apiKey, maxRetries: 1, timeout: 20_000 }).models.retrieve(c.model);
  } catch (e) {
    if (e instanceof OpenAI.AuthenticationError || e instanceof Anthropic.AuthenticationError) throw new CodedError('keyInvalid');
    if (e instanceof OpenAI.NotFoundError || e instanceof Anthropic.NotFoundError || e instanceof OpenAI.PermissionDeniedError || e instanceof Anthropic.PermissionDeniedError) {
      throw new CodedError('modelNotFound', { model: c.model });
    }
    throw new CodedError('connectFailed', { msg: (e as Error).message });
  }
}
