// 离线模拟大脑：不联网、不花钱，行为固定，用来演示和测试整条流水线。
// 它和真实大脑走同一套工具箱和红线，所以审批、规则、账本都是真的在工作。输出语言跟随公司的工作语言。
import { LANGS, t, type Lang } from '../i18n.js';
import { addDays, daysBetween } from '../snapshot.js';
import type { Contact, Email, UnitPlan, Usage, Verdict } from '../types.js';
import type { Brain, BrainResult, CriteriaInput, ExecuteInput, SplitInput, VerifyInput } from './types.js';

/** 规则可能是任何语言写的：用所有语言的写法来认 */
const anyLang = (key: string) => LANGS.map((l) => t(l, key));
const ATTACH_RULES = anyLang('mock.v.attachRule');
const SIGN_WORDS = [...new Set(anyLang('mock.closing'))];

export class MockBrain implements Brain {
  readonly mode = 'mock' as const;
  readonly label = '';

  /**
   * usagePerCall：给每次"调用"记一笔假用量，用来测试预算
   * paceMs：每次"调用"停顿的毫秒范围，让界面能看到进度；不填就不停顿
   */
  constructor(private opts: { usagePerCall?: Usage; paceMs?: [number, number] } = {}) {}

  private u(): Usage[] {
    return this.opts.usagePerCall ? [this.opts.usagePerCall] : [];
  }

  private async pace(scale = 1): Promise<void> {
    const p = this.opts.paceMs;
    if (!p) return;
    await new Promise((r) => setTimeout(r, (p[0] + Math.random() * (p[1] - p[0])) * scale));
  }

  private signRule(rules: string[]): boolean {
    return rules.some((r) => SIGN_WORDS.some((w) => r.includes(w)));
  }

  async writeCriteria(i: CriteriaInput): Promise<BrainResult<string[]>> {
    await this.pace(1.5);
    return { value: ['mock.c1', 'mock.c2', 'mock.c3', 'mock.c4'].map((k) => t(i.lang, k)), usage: this.u() };
  }

  async split(i: SplitInput): Promise<BrainResult<UnitPlan[]>> {
    await this.pace(1.5);
    const s = i.snapshot, L = i.lang;
    const plans: Omit<UnitPlan, 'id'>[] = [];
    for (const e of s.emails.filter((x) => x.unread)) {
      plans.push({ bot: 'inbox', kind: 'inbox.sort', title: t(L, 'mock.title.inbox', { subject: e.subject }), detail: t(L, 'mock.detail.inbox', { from: e.fromName }), ref: e.id, dependsOn: [] });
    }
    for (const c of s.contacts.filter((x) => x.stage === '方案已发' && daysBetween(x.lastContact, s.today) > 7)) {
      plans.push({
        bot: 'follow',
        kind: 'followup.send',
        title: t(L, 'mock.title.follow', { name: c.name, company: c.company }),
        detail: t(L, 'mock.detail.follow', { days: daysBetween(c.lastContact, s.today), proposal: c.lastProposal ?? '' }),
        ref: c.id,
        dependsOn: [],
      });
    }
    for (const ev of s.events.filter((x) => x.attendees.length)) {
      plans.push({ bot: 'meet', kind: 'notes.prep', title: t(L, 'mock.title.meet', { title: ev.title }), detail: ev.start.replace('T', ' '), ref: ev.id, dependsOn: [] });
    }
    return { value: plans.slice(0, i.maxUnits).map((p, n) => ({ id: `u${n + 1}`, ...p })), usage: this.u() };
  }

  async execute(i: ExecuteInput): Promise<BrainResult<string>> {
    await this.pace(2);
    const { unit, tools, owner, rules } = i;
    const L: Lang = i.lang;
    const sign = this.signRule(rules) ? `${t(L, 'mock.closing')}\n${owner.company} ${owner.name}` : owner.name;
    const parse = <T>(s: string): T | null => {
      try {
        return JSON.parse(s) as T;
      } catch {
        return null;
      }
    };
    const done = (key: string, p?: Record<string, string>) => ({ value: t(L, key, p), usage: this.u() });

    if (unit.kind === 'inbox.sort' && unit.ref) {
      const e = parse<Email>(await tools.call('mail_read', { id: unit.ref }));
      if (!e) return done('mock.rep.noMail', { id: unit.ref });
      if (/newsletter|noreply/.test(e.from)) {
        await tools.call('mail_label', { id: e.id, label: e.from.includes('bank') ? 'finance' : 'newsletter' });
        await tools.call('mail_archive', { id: e.id });
        return done('mock.rep.archived', { id: e.id });
      }
      if (/[？?]|请/.test(e.body)) {
        await tools.call('mail_label', { id: e.id, label: 'needs-reply' });
        const r = await tools.call('mail_send', {
          to: e.from,
          subject: `Re: ${e.subject}`,
          body: `${t(L, 'mock.greet', { name: e.fromName.split('（')[0] })}\n\n${t(L, 'mock.replyBody')}\n\n${sign}`,
          replyTo: e.id,
        });
        return done('mock.rep.replied', { id: e.id, r });
      }
      await tools.call('mail_label', { id: e.id, label: 'fyi' });
      return done('mock.rep.fyi', { id: e.id });
    }

    if (unit.kind === 'followup.send' && unit.ref) {
      const c = parse<Contact[]>(await tools.call('contacts_find', { query: unit.ref }))?.[0];
      if (!c) return done('mock.rep.noContact', { id: unit.ref });
      const proposal = c.lastProposal ?? '';
      const attach = rules.some((r) => ATTACH_RULES.includes(r)) ? `\n\n${t(L, 'mock.attach', { proposal })}` : '';
      const r = await tools.call('mail_send', {
        to: c.email,
        subject: t(L, 'mock.followSubject', { proposal }),
        body: `${t(L, 'mock.greet', { name: c.name })}\n\n${t(L, 'mock.followBody', { proposal })}${attach}\n\n${sign}`,
        replyTo: null,
      });
      return done('mock.rep.follow', { r });
    }

    if (unit.kind === 'notes.prep' && unit.ref) {
      const evs = parse<{ events: Array<{ id: string; title: string; start: string; end: string; attendees: string[] }> }>(
        await tools.call('calendar_list', { from: i.today, to: addDays(i.today, 7) }),
      )?.events;
      const ev = evs?.find((x) => x.id === unit.ref);
      if (!ev) return done('mock.rep.noEvent', { id: unit.ref });
      const c = parse<Contact[]>(await tools.call('contacts_find', { query: ev.attendees[0] ?? '' }))?.[0];
      const r = await tools.call('notes_write', {
        title: t(L, 'mock.notes.title', { title: ev.title }),
        content: [
          '- ' + t(L, 'mock.notes.time', { start: ev.start.replace('T', ' '), end: ev.end.slice(11) }),
          '- ' + t(L, 'mock.notes.who', { who: c ? `${c.name}, ${c.company} (${c.stage})` : ev.attendees.join(', ') }),
          '- ' + t(L, 'mock.notes.recent', { recent: c ? t(L, 'mock.notes.contacted', { date: c.lastContact, notes: c.notes ?? '' }) : t(L, 'mock.notes.none') }),
          '- ' + t(L, 'mock.notes.bring', { x: c?.lastProposal ?? t(L, 'mock.notes.bringDefault') }),
          '- ' + t(L, 'mock.notes.ask'),
        ].join('\n'),
      });
      return done('mock.rep.notes', { r });
    }

    return done('mock.rep.unknown');
  }

  async verify(i: VerifyInput): Promise<BrainResult<Verdict>> {
    await this.pace(0.6);
    const L = i.lang;
    const sends = i.actions.filter((a) => a.tool === 'mail_send').map((a) => a.input as { body: string });
    const fail = (reason: string, rule: string | null): BrainResult<Verdict> => ({ value: { pass: false, reason, rule }, usage: this.u() });
    if (!i.actions.length) return fail(t(L, 'mock.v.noActions'), null);
    if (i.unit.kind === 'followup.send' && !sends.some((s) => s.body.includes(t(L, 'mock.attachLabel')))) {
      return fail(t(L, 'mock.v.noAttach'), t(L, 'mock.v.attachRule'));
    }
    if (this.signRule(i.rules) && sends.some((s) => !s.body.includes(t(L, 'mock.closing')))) {
      return fail(t(L, 'mock.v.sign'), null);
    }
    return { value: { pass: true, reason: t(L, 'mock.v.pass'), rule: null }, usage: this.u() };
  }
}
