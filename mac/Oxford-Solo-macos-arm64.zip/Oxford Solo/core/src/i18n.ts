// 内核的多语言：和网页界面共用 Oxford-OPC/i18n/*.json 文案表
import fs from 'node:fs';
import path from 'node:path';
import { ROOT } from './config.js';

export const LANGS = ['zh-CN', 'zh-TW', 'en', 'ja', 'ko', 'vi'] as const;
export type Lang = (typeof LANGS)[number];
export const DEFAULT_LANG: Lang = 'zh-CN';
export const I18N_DIR = path.join(ROOT, '..', 'i18n');

/** 结构化消息：内核产生的日志和摘要都用它，界面再按查看者的语言翻译 */
export interface Msg {
  k: string;
  p?: Record<string, MsgParam>;
}
export type MsgParam = string | number | Msg;

const cache = new Map<Lang, Record<string, string>>();

export function catalog(lang: Lang): Record<string, string> {
  let c = cache.get(lang);
  if (!c) {
    c = JSON.parse(fs.readFileSync(path.join(I18N_DIR, `${lang}.json`), 'utf8')) as Record<string, string>;
    cache.set(lang, c);
  }
  return c;
}

export function isLang(x: unknown): x is Lang {
  return typeof x === 'string' && (LANGS as readonly string[]).includes(x);
}

/** 把 zh-Hant、zh-HK、ja-JP、vi-VN 这类写法归到支持的六种语言；不认识的返回 null */
export function normalizeLang(x?: string | null): Lang | null {
  if (!x) return null;
  const c = x.toLowerCase();
  if (c === 'zh-tw' || c === 'zh-hk' || c === 'zh-mo' || c.startsWith('zh-hant')) return 'zh-TW';
  if (c.startsWith('zh')) return 'zh-CN';
  if (c.startsWith('ja')) return 'ja';
  if (c.startsWith('ko')) return 'ko';
  if (c.startsWith('vi')) return 'vi';
  if (c.startsWith('en')) return 'en';
  return null;
}

export const msg = (k: string, p?: Msg['p']): Msg => (p ? { k, p } : { k });

export function t(lang: Lang, key: string, p?: Msg['p']): string {
  const s = catalog(lang)[key] ?? catalog(DEFAULT_LANG)[key] ?? key;
  if (!p) return s;
  return s.replace(/\{(\w+)\}/g, (m, k: string) => (k in p ? fmtParam(lang, p[k]) : m));
}

function fmtParam(lang: Lang, v: MsgParam): string {
  return typeof v === 'object' ? fmt(lang, v) : String(v);
}

export function fmt(lang: Lang, m: Msg | string | null | undefined): string {
  if (m == null) return '';
  return typeof m === 'string' ? m : t(lang, m.k, m.p);
}

/** 写给模型的提示词是中文，这里是目标语言在中文里的叫法 */
export const AI_LANG_NAME: Record<Lang, string> = {
  'zh-CN': '简体中文',
  'zh-TW': '繁体中文（台湾用语）',
  en: '英语',
  ja: '日语',
  ko: '韩语',
  vi: '越南语',
};

/** 带错误代码的错误：界面按代码翻译，命令行直接显示中文 */
export class CodedError extends Error {
  constructor(
    readonly code: string,
    readonly params: Record<string, string | number> = {},
  ) {
    super(t(DEFAULT_LANG, 'err.' + code, params));
  }
}
