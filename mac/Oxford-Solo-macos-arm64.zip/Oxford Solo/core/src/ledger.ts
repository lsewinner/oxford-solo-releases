import { MODEL, PRICES, PRICE_OVERRIDES, openaiPrice } from './config.js';
import type { Usage } from './types.js';
import type { Workspace } from './workspace.js';

export function costUsd(u: Usage, model = u.model ?? MODEL): number {
  // 不认识的 OpenAI 模型按偏高的估计价，不认识的 Claude 模型按 Opus 价：预算上限只会提前停，不会失效
  const p = PRICE_OVERRIDES.get(model) ?? PRICES[model] ?? (/^claude/.test(model) ? PRICES[MODEL] : /^(gpt|o\d)/.test(model) ? openaiPrice() : undefined);
  if (!p) return 0;
  return (
    (u.input_tokens * p.input +
      u.output_tokens * p.output +
      (u.cache_read_input_tokens ?? 0) * p.cacheRead +
      (u.cache_creation_input_tokens ?? 0) * p.cacheWrite) /
    1e6
  );
}

export interface ActorCost {
  usd: number;
  calls: number;
  inputTokens: number;
  outputTokens: number;
}

export interface LedgerRun {
  runId: string;
  mode: string;
  at: string;
  totalUsd: number;
  byActor: Record<string, ActorCost>;
}

/** 记下每次模型调用花了多少钱，按 bot 分账 */
export class Ledger {
  readonly byActor = new Map<string, ActorCost>();
  total = 0;

  constructor(
    private ws: Workspace,
    readonly runId: string,
    readonly mode: string,
  ) {}

  add(actor: string, usage: Usage[]): number {
    let usd = 0;
    const row = this.byActor.get(actor) ?? { usd: 0, calls: 0, inputTokens: 0, outputTokens: 0 };
    for (const u of usage) {
      const c = costUsd(u);
      usd += c;
      row.calls += 1;
      row.inputTokens += u.input_tokens + (u.cache_read_input_tokens ?? 0) + (u.cache_creation_input_tokens ?? 0);
      row.outputTokens += u.output_tokens;
    }
    row.usd += usd;
    this.byActor.set(actor, row);
    this.total += usd;
    return usd;
  }

  persist(): void {
    const book = this.ws.readJson<{ runs: LedgerRun[] }>('ledger.json');
    book.runs.push({
      runId: this.runId,
      mode: this.mode,
      at: new Date().toISOString(),
      totalUsd: this.total,
      byActor: Object.fromEntries(this.byActor),
    });
    this.ws.writeJson('ledger.json', book);
  }
}
