// Oxford Solo 界面的多语言运行库。构建时和各语言文案一起内联进页面（见 tools/build.py）。
(function () {
  'use strict';
  var LANGS = [
    { code: 'zh-CN', name: '简体中文' },
    { code: 'zh-TW', name: '繁體中文' },
    { code: 'en', name: 'English' },
    { code: 'ja', name: '日本語' },
    { code: 'ko', name: '한국어' },
    { code: 'vi', name: 'Tiếng Việt' }
  ];
  var CODES = LANGS.map(function (l) { return l.code; });
  var DATA = window.SOLO_I18N_DATA || {};
  // 标题字体按语言加载：简繁日韩各用对应的 Noto Serif，英文和越南文用 Cormorant Garamond（含越南文字母）
  var FONTS = {
    'zh-CN': 'Noto+Serif+SC:wght@600;700',
    'zh-TW': 'Noto+Serif+TC:wght@600;700',
    ja: 'Noto+Serif+JP:wght@600;700',
    ko: 'Noto+Serif+KR:wght@600;700'
  };
  var lang = 'zh-CN';
  var listeners = [];
  var moneyFmt = function (n) { return String(n); };

  function normalize(code) {
    if (!code) return null;
    var c = String(code).toLowerCase();
    if (c === 'zh-tw' || c === 'zh-hk' || c === 'zh-mo' || c.indexOf('zh-hant') === 0) return 'zh-TW';
    if (c.indexOf('zh') === 0) return 'zh-CN';
    if (c.indexOf('ja') === 0) return 'ja';
    if (c.indexOf('ko') === 0) return 'ko';
    if (c.indexOf('vi') === 0) return 'vi';
    if (c.indexOf('en') === 0) return 'en';
    return null;
  }
  function stored() {
    try { return localStorage.getItem('oxsolo:lang'); } catch (e) { return null; }
  }
  function detect() {
    var s = normalize(stored());
    if (s) return s;
    var list = (navigator.languages && navigator.languages.length ? navigator.languages : [navigator.language]) || [];
    for (var i = 0; i < list.length; i++) { var n = normalize(list[i]); if (n) return n; }
    return 'en';
  }
  function raw(key) {
    var a = DATA[lang], b = DATA['zh-CN'];
    if (a && Object.prototype.hasOwnProperty.call(a, key)) return a[key];
    if (b && Object.prototype.hasOwnProperty.call(b, key)) return b[key];
    return key;
  }
  function fmt(v) {
    if (v && typeof v === 'object') {
      if ('k' in v) return msg(v);
      if ('cur' in v) return moneyFmt(v.cur);
    }
    return v == null ? '' : String(v);
  }
  function t(key, params) {
    var s = raw(key);
    if (!params) return s;
    return s.replace(/\{(\w+)\}/g, function (m, k) { return Object.prototype.hasOwnProperty.call(params, k) ? fmt(params[k]) : m; });
  }
  /** 结构化消息 {k, p}：内核发来的日志和摘要用它，切换语言后能重新翻译 */
  function msg(m) {
    if (m == null) return '';
    if (typeof m === 'string') return m;
    return t(m.k, m.p);
  }
  function list(items) { return items.join(t('sep.list')); }
  function apply(root) {
    root = root || document;
    root.querySelectorAll('[data-i18n]').forEach(function (el) {
      var p = el.getAttribute('data-i18n-params');
      el.textContent = t(el.getAttribute('data-i18n'), p ? JSON.parse(p) : undefined);
    });
    [['data-i18n-placeholder', 'placeholder'], ['data-i18n-title', 'title'], ['data-i18n-aria', 'aria-label']].forEach(function (pair) {
      root.querySelectorAll('[' + pair[0] + ']').forEach(function (el) { el.setAttribute(pair[1], t(el.getAttribute(pair[0]))); });
    });
  }
  function ensureFont(code) {
    var fam = FONTS[code];
    if (!fam || document.getElementById('font-' + code)) return;
    var link = document.createElement('link');
    link.id = 'font-' + code;
    link.rel = 'stylesheet';
    link.href = 'https://fonts.googleapis.com/css2?family=' + fam + '&display=swap';
    document.head.appendChild(link);
  }
  function set(code, opts) {
    lang = normalize(code) || 'zh-CN';
    if (!opts || opts.remember !== false) { try { localStorage.setItem('oxsolo:lang', lang); } catch (e) { /* 存不了就算了 */ } }
    document.documentElement.lang = lang;
    ensureFont(lang);
    apply(document);
    document.querySelectorAll('select[data-lang-picker]').forEach(function (sel) { sel.value = lang; });
    listeners.forEach(function (fn) { fn(lang); });
  }
  function picker(sel) {
    sel.setAttribute('data-lang-picker', '');
    sel.innerHTML = LANGS.map(function (l) { return '<option value="' + l.code + '" lang="' + l.code + '">' + l.name + '</option>'; }).join('');
    sel.value = lang;
    sel.addEventListener('change', function () { set(sel.value); });
  }
  function init() {
    lang = detect();
    document.documentElement.lang = lang;
    ensureFont(lang);
    apply(document);
    return lang;
  }

  window.SoloI18n = {
    LANGS: LANGS,
    CODES: CODES,
    t: t,
    msg: msg,
    list: list,
    apply: apply,
    set: set,
    init: init,
    picker: picker,
    normalize: normalize,
    get lang() { return lang; },
    onChange: function (fn) { listeners.push(fn); },
    setMoney: function (fn) { moneyFmt = fn; }
  };
})();
