#!/bin/bash
# Oxford Solo launcher. Starts the local app and opens it in your browser.
# The app only listens on this computer (localhost). Close this window or press Ctrl+C to stop it.
DIR="$(cd "$(dirname "$0")" && pwd)"

# Files unzipped from a download carry macOS's quarantine flag, which blocks the bundled
# Node runtime. You have already allowed this launcher to run, so clear the flag for this folder.
xattr -dr com.apple.quarantine "$DIR" 2>/dev/null

PORT="${SOLO_PORT:-4610}"
cd "$DIR/core" || { echo "Cannot find the core folder next to this launcher."; read -r; exit 1; }

if curl -s -o /dev/null "http://localhost:$PORT/"; then
  echo "Oxford Solo is already running. Opening http://localhost:$PORT/"
  open "http://localhost:$PORT/"
  exit 0
fi

# Open the browser once the server answers (up to 30 seconds).
( for _ in $(seq 1 30); do
    sleep 1
    if curl -s -o /dev/null "http://localhost:$PORT/"; then open "http://localhost:$PORT/"; exit 0; fi
  done ) &

exec ./solo serve --port "$PORT"
